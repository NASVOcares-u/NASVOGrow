# Android app (Capacitor) — what changed

See **ANDROID.md** for setup, what was and wasn't tested, and the on-device checklist.

* New: `native-bridge.js` (rewritten), `native-app.js`, `native/` (Java plugin, widget, resources, `setup-android.mjs`),
  `capacitor.config.json`, `.github/workflows/android.yml`, `qa/native-bridge.test.mjs`, `qa/native-e2e.py`.
* `build.mjs --native` → `dist-native/`. `npm run build` (Netlify) is unchanged except for the items below.
* Small native-only branches in `app.js`, `safety.js`, `auto-backup.js`, `streak-card.js`, `sync.js` (all no-ops in a browser).
* **Also affects the web build:** `styles.css` `.toast.toast-flex[hidden]{display:none}`. A dismissed toast used to leave an
  invisible box over the top-right corner that blocked taps on Settings. Service-worker cache bumped to `nasvogrow-v5.6`.
* `.well-known/security.txt` added to the source (it was only in the uploaded `dist`); `build.mjs` no longer copies
  `.well-known/appspecific` (a Chrome DevTools probe file).

# Lighthouse fixes — what changed and how to deploy

## Deploy
* **Drag-and-drop:** upload the *contents* of `dist/` (or the `nasvogrow-dist.zip`) to Netlify.
* **Git deploy:** build command `npm install && npm run build`, publish directory `dist`.
* If you keep response headers in a `netlify.toml` as well as `_headers`, mirror the new
  `/assets/img/*` (1 year, immutable) and `/assets/icons/*` (7 days) rules there.
* The service-worker cache is now `nasvogrow-v5.3`; returning users pick up the new files on
  their next visit after the new worker activates.

The repo root remains the readable source and still runs as-is from any static server.
`npm run build` produces the optimized site in `dist/`. `npm run build -- --bundle` additionally
concatenates all scripts into one file (faster LCP, ~0.7 s vs ~1.1 s in my runs) but Lighthouse then
reports "Reduce unused JavaScript" for that file, so it is **off by default**.

## Lighthouse items from your four reports
| Report item | Fix |
|---|---|
| Color contrast (`.zr-log-meta`, and more) | `--muted-dim`, `--danger`, `--accent-text`, `--gold-text`, `--muted` retuned in 14 spots so every text token is ≥ 4.5:1 on every surface in all 5 themes. Also fixed: Growth branch tabs, "Grow" wordmark, journal mood tag. |
| ARIA toggle has no accessible name | `.habit-check` now has `aria-label` (habit name); Space no longer scrolls the page. Same fix for the `disguiseToggle` switch. |
| Forced reflow (`skilltree.js`) | Theme colours read lazily; canvas sized by `ResizeObserver`; `ctx.font` set only on change; animation now only runs while Growth is visible. |
| Minify CSS / JavaScript | `build.mjs` |
| Unused CSS, render-blocking CSS, network dependency chain | `styles.css` (Home + shell) is inlined; `styles-extra.css` loads on first need (interaction, section switch, modal, overlay). `app.js: ZG.ensureExtraCss`. |
| Image delivery | `logo.png` (12.6 KB) → lossless WebP (1.4 KB) + 1.5 KB favicon, in `assets/img/` |
| Cache lifetimes | `/assets/img/*` is content-hashed → 1 year immutable |
| LCP / Speed Index | Hero text restored from `zg_hero_cache` before first paint; no-op text rewrites skipped |
| Also found by axe (not in your reports) | unlabeled `<select>` in Recovery, heading-level skip in Settings |

## Follow-up fixes (UI)
* **"Track what this is costing you"** (`recovery.js`): the free-typed 3-character currency box is now a labelled
  dropdown of 31 currencies (symbol, name, ISO code) plus "Other…" for a custom symbol. Existing saved symbols still
  work (an unknown one reopens as "Other…"). First-time default follows the browser locale (en-IN -> ₹). Letter-style
  symbols get a space ("CHF 1,200"). The header icon follows the Money/Time toggle.
* **Input "out of style":** the global input rule only matched `type="text"`, so every `type="number"` field rendered
  with browser defaults. `input[type="number"]` now shares the text-input styling (`styles.css`). The Money/Time pill
  icons had no size rule and rendered huge; fixed (`styles-extra.css`).
* **"Feeling it right now? Ride it out" doesn't fit:** `.celebrate-wrap` centred its card with `align-items:center`
  and the card had no height limit, so on screens shorter than ~830 px the title and buttons were cut off and
  unreachable (measured: card spanned -83..750 px on a 667 px viewport). The overlay now scrolls, centres only when it
  fits, respects safe-area insets, and tightens spacing on short screens. This fixes every dialog built on the same
  classes (savings, relapse, check-in, plans...).

## Polish pass (Phases 1–4)
**Phase 1 — hierarchy & structure**
* **Home:** new *Today* card right under the hero: progress ring, your habits as one-tap rows, "all done" and
  first-habit states. It is cached (`zg_today_cache`) and restored before first paint, so it adds no layout shift (CLS 0.001).
  Hero is two-column on desktop (no dead space) and puts the streak ring beside its legend on phones so Today sits above the fold.
  The four identical stat boxes became one quiet strip with hairline dividers; the tier name uses the display font and wraps cleanly.
* **Habits:** today's checklist first. Adding a habit is a bottom sheet opened by a floating button (phones) / header button
  (desktop) / Today card; suggestions collapse into an accordion; progress bar on the summary; 16-week consistency heatmap;
  proper empty state.
* **Design tokens:** fluid type scale (`--fs-*`), spacing scale (`--sp-*`), `--ease-out`; tabular numerals on all counters.

**Phase 2 — motion & feedback** (all disabled by `prefers-reduced-motion` and Calm mode)
* Habit check: pop + drawn check mark + glow, confetti burst (bigger when every habit is done), haptics.
* Rings animate from their previous value; numbers count up/down; sections slide in from the side their tab sits on.
* Haptic feedback has its own switch in Settings (hidden where the Vibration API doesn't exist, e.g. iOS Safari).
* I deliberately did **not** use the View Transitions API: it makes the DOM swap asynchronous and existing callers
  (`showSection()` followed by `focus()`) rely on it being synchronous.

**Phase 3 — native feel**
* Every modal gets a grab handle; form-style dialogs (check-in, savings, relapse…) become bottom sheets on phones;
  swipe down to dismiss (long drag or a real flick, only from the top of the sheet so scrolling is never hijacked).
* 44 px touch targets (visually unchanged) on habit checkboxes and coarse-pointer controls.
* "Install app" row in Settings (Chrome/Edge/Android prompt; Share-menu hint on iOS Safari). Per-theme `theme-color` already existed.
* Fixed a hole in the earlier CSS split: Calm mode's Home rules lived in the on-demand sheet (now in core).

**Phase 4 — guardrails**: `qa/` toolkit (see `qa/README.md`), 16 committed baseline screenshots, `gallery.html` component gallery.

## Not done / known limits
* iOS launch (splash) images are not generated; Android uses the manifest colours + icon.
* The Growth screen only inherits the global changes (tokens, motion, sheets, empty-state style); it was not individually redesigned.
* The crisis-line box at the top of Recovery was deliberately left as it was (safety-critical); it still pushes the first counter
  towards the bottom of a phone's first screen until a country is chosen.
* Verified in headless Chromium only — no real-device testing, so the feel of haptics and swipe gestures is unproven.
* Lighthouse's forced-reflow insight flagged a 60 ms *unattributed* reflow in roughly 1 of 8 runs on my slow sandbox;
  traces show no layout work inside your scripts, so I believe it is load-related, but I could not prove that.
* Stored data is local-only by design (no backend); export/backup features remain the way to move data between devices.

## Recovery, Journal & Challenges pass
* **Three tabs instead of one 5,374 px scroll** (phone): Trackers / Journal / Challenges, with proper tab semantics
  (arrow keys, Home/End, roving tabindex). The last tab is remembered (`zg_rec_tab`); Home's "journal" and "urge" quick
  actions switch to the right tab first. The Trackers tab is ~2,070 px.
* **Tracker card:** the day counter and milestone come first, then **Ride it out**, "I resisted an urge" / "Start over",
  then a quiet "Something better to do". Safety notes and professional-help resources stay visible on the card. Everything
  else (why, savings, coping plans, timeline, stats, recent activity) is behind "Details & history"; its open/closed state
  survives the 60-second refresh and every log action.
* Compact summary (streak + chips + "Add tracker" on one row); the "How dopamine…" learning panel moved below the trackers;
  Challenges become two columns on wide screens; Journal entries use the display typeface and larger dates.
* Hardening: the "Common trigger" label no longer prints `undefined` if it meets an unexpected code.

## Maintenance rules
* **Styles:** anything visible on Home, or any "hidden until opened" element, belongs in `styles.css`;
  feature UI goes in `styles-extra.css`. A Home widget styled only in the extra sheet will flash unstyled.
* **Images:** never overwrite a file in `assets/img/`; add a new hashed name and update references,
  because it is cached for a year.

## Verified (local, headless Chromium)
* Lighthouse desktop on `dist/`: performance 91–96 across runs (the untouched original scored 90–92 in the
  same sandbox; LCP 1.8 s -> 1.1–1.4 s), accessibility/SEO/agentic 100; every audit you reported scores 1.0.
  Total Blocking Time reads higher (100–190 ms vs ~40 ms) because first paint now happens earlier, so script
  start-up falls inside the measured window; it is not extra work. (`errors-in-console` only appears in my sandbox, where Google Fonts is blocked.)
* axe-core across Home/Habits/Recovery/Growth tabs/Settings/habit modal/celebration overlay, 5 themes × 2
  widths with seeded data: 46 distinct violations before → 4 after; the 4 are axe best-practice rules
  Lighthouse does not run (`page-has-heading-one` while Home is hidden, `region` on the overlay).
* 150 screenshots (5 themes × 3 widths × sections, Growth tabs, 4 modals): source vs `dist/` pixel-identical.
* Not covered: real-device testing, PIN-lock startup flow, offline/service-worker update path.

## Responsive & publish-readiness pass
* **Tiny screens (< 320 px, e.g. Galaxy Z Fold cover display):** Home quick actions stack to one column, the Recovery
  and Growth tab bars shrink/wrap instead of overflowing, the streak legend wraps inside its card. No horizontal
  overflow at 280 px (was 314 px wide). Rules are scoped to `max-width:319px` so normal phones are pixel-identical.
* **Touch targets (`pointer:coarse` only):** icon buttons (`.habit-del` Edit/Remove/Dismiss, `.veil-toggle`,
  `.zr-card-rm`) keep their look but get an invisible ::after hit area. Edit and Remove sit 12 px apart, so they grow
  only 6 px sideways (no overlap) and 10 px vertically. Text buttons/tabs (`.btn-quiet`, `.btn-secondary`,
  `.growth-tab`, `.streak-theme-btn`, `.zr-btn-u/r`, `.today-cta`, Add tracker) get `min-height:44px`.
* **Privacy policy is now linked** from Settings and from the first onboarding screen (opens in a new tab so onboarding
  progress is not lost); new i18n key `privacy_policy_link` (en/es/hi). `privacy.html` is also precached by the service worker.
* **Text scales with the browser's font-size setting:** every `font-size` (CSS, inline styles, privacy/404/gallery pages)
  converted from px to rem (1 rem = 16 px, so the default look is unchanged; verified pixel-identical against baselines).
* **Sharing/installing:** absolute `og:image`/`twitter:image` URLs, `rel=canonical`, a real 180x180 apple-touch-icon,
  manifest `orientation` is now `any` (was locked to portrait), and manifest `screenshots` (3 phone + 2 desktop).
* Service-worker cache bumped to `nasvogrow-v5.4`.
* New `qa/screenshots.py` regenerates the manifest screenshots. **Re-run it on a machine with internet** before
  publishing: the bundled ones were rendered in a sandbox without Google Fonts, so they use fallback fonts.

## Self-hosted fonts, wide screens & 11 px floor (cache `nasvogrow-v5.5`)
* **Fonts are self-hosted.** Fraunces (opsz+wght variable), Work Sans (wght variable) and Space Mono 400/700, Latin subset, from the
  `@fontsource` packages (SIL OFL 1.1; licences in `assets/fonts/`). `fonts.css` is inlined with the core CSS, Fraunces/Work Sans/Space Mono
  Bold are `preload`ed on Home, all four files are precached by the service worker and cached for a year (`/assets/fonts/*` in `_headers`,
  hashed names - never overwrite one). Google preconnects/stylesheets are gone from `index`, `privacy`, `404`, `gallery`; the CSP no longer
  allows Google (`font-src 'self'`) - mirror that in `netlify.toml` if you keep one. The app now makes **zero** third-party requests and works
  fully offline, fonts included (verified with the network switched off). Devanagari still falls back to the system font, as before.
  Preloading Space Mono Bold matters: without it CLS rose to 0.029 and Lighthouse flagged a font dependency chain.
* **Wide monitors (1920 px+):** the content column is centred in the space beside the sidebar (it was pinned to the sidebar's edge,
  leaving all the slack on the right). Unchanged up to ~1400 px, where the column fills the space anyway.
* **No text under 11 px.** New `qa/small-text.py` (`npm run qa:text`, part of `npm run qa`) measures rendered size including SVG scaling.
  It found 26 offenders (7.2-10.5 px): the `--fs-2xs` token and ~30 rules were raised to 11 px (`0.6875rem`). The streak-ring caption is
  now an 11 px lowercase "day streak" that fits the inner ring at all three ring sizes; the radar chart canvas is wider (its side labels
  were clipped); the usage heatmap has taller rows. Chart labels are 12-12.5 px in the drawing so they stay >= 11 px down to a 360 px phone.
  Left alone on purpose: the print stylesheet (`.print-*`, 10-10.5 px on paper).
* **Manifest screenshots regenerated** with the real fonts and **without the demo profile** (`qa/screenshots.py` now removes the seeded
  name/username/motto). Run it again whenever Home changes visibly.
* **Privacy contact** now links to the address it shows: `nasvocares.u@gmail.com`.
* QA baselines re-accepted (24 screenshots); parity source vs `dist/` 0 mismatches; axe 0 WCAG violations; Lighthouse desktop 91-96 with
  accessibility/best-practices/SEO 100 and CLS 0.001 (the original `dist/` scored 85-94 in the same sandbox). The only audit that ever fails
  is the known, unattributed `forced-reflow-insight` in about 1 of 8 runs.

### Still open
* Phones below ~340 px: SVG chart labels (heatmap, radar) shrink with their card and drop to ~9.5-10.8 px at 320-340 px.
* Not tested in Safari/WebKit, Firefox or on real devices (only headless Chromium). The PIN-lock flow and the offline *update* path are untested.
* No iOS splash images; the Growth screen was not individually redesigned.
