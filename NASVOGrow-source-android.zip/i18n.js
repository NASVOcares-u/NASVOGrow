"use strict";
/* ═══════════════════════════════════════════════════════════════
   I18N — runtime UI language switching, no build step, no server.

   Scope, honestly stated: this translates every purely static piece
   of chrome — navigation, section headers, Settings, the habit-edit
   drawer, and the onboarding flow. It deliberately does NOT (yet)
   translate the much larger surface of copy that habits.js,
   recovery.js, journal.js, challenges.js, insights.js, safety.js,
   and skilltree.js generate at runtime — toasts, card text, prompts,
   achievement labels, and so on. That's a genuinely large amount of
   text, some of it recovery- and crisis-sensitive, and machine
   pretranslating all of it in one pass risked exactly the kind of
   sloppy or subtly-wrong wording that matters most to get right in
   this app. ZG.t(key, vars) below is the extension point: any module
   can wrap a string in it and add the key to DICT to join the system
   incrementally, without needing to touch this file's structure.

   How it works:
     • DICT holds one flat key → string map per language.
     • Static HTML opts in via data-i18n (textContent), data-i18n-
       placeholder, data-i18n-aria-label, or data-i18n-title — see
       index.html for examples. Elements that mix translatable text
       with an icon/nested element put data-i18n on a plain inner
       <span> instead of the element itself, so translating never
       clobbers markup.
     • Language preference is stored locally (zg_lang) same as every
       other setting; first run guesses from navigator.language, same
       spirit as (but independent from) the crisis-line country guess
       in safety.js.
═══════════════════════════════════════════════════════════════ */
const I18N = (() => {
  const KEY = "zg_lang";
  const LANGS = {
    en: { name: "English" },
    es: { name: "Español" },
    hi: { name: "हिन्दी" },
  };

  const DICT = {
    en: {
      brand_tagline: "Become who you keep choosing to be.",
      nav_home: "Home", nav_habits: "Habits", nav_recovery: "Recovery", nav_growth: "Growth",
      ground_yourself: "Ground yourself", settings: "Settings",

      home_right_now: "Right now",
      qa_check_habit: "Check off a habit",
      qa_write_line: "Write today's line",
      qa_log_urge: "Log a resisted urge",
      qa_view_challenges: "View challenges",
      qa_see_patterns: "See your patterns",
      stat_level: "Level", stat_total_xp: "Total XP", stat_actions: "Actions logged", stat_tier: "Identity tier",

      habits_section_title: "Habits & Insights",
      habits_section_sub: "Small, repeated choices — and what your own data says about them.",
      habit_input_placeholder: "Add a habit — e.g. Read 10 pages",
      add_button: "Add",
      your_habits: "Your habits",
      insights_label: "Insights",

      recovery_section_title: "Recovery, Journal & Challenges",
      recovery_section_sub: "A private, judgment-free counter for whatever you're walking away from — and a line a day to go with it.",
      active_trackers: "Active trackers",
      journal_label: "Journal",
      challenges_label: "Challenges",

      growth_section_title: "Growth",
      growth_section_sub: "What consistency unlocks — skills, badges, and the shape of your streak.",
      tab_overview: "Overview", tab_skills: "Skills", tab_achievements: "Achievements",

      settings_title: "Settings",
      name_label: "What should we call you?",
      name_placeholder: "Your name (optional)",
      theme_label: "Theme",
      theme_dusk: "Dusk", theme_paper: "Paper", theme_forest: "Forest", theme_dune: "Dune", theme_slate: "Slate",
      language_label: "Language",
      weekly_goal_label: "Weekly rhythm goal — active days per week",
      blur_recovery_label: "Blur Recovery numbers",
      blur_recovery_sub: "Hide day counts by default — tap the eye on any card to peek",
      local_reminders_label: "Local reminders",
      local_reminders_sub: "A gentle evening nudge if today's still open — only while this tab is open, nothing sent from a server",
      calm_mode_label: "Calm mode",
      calm_mode_sub: "Hide XP, levels, the skill tree, and achievements — streaks and recovery milestones keep working exactly the same underneath",
      context_tracking_label: "Sleep & context tracking",
      context_tracking_sub: "Optional daily sleep + self-reported weather log, used only to power a couple of extra Insights correlations — nothing leaves your device, and no weather service is ever contacted",
      privacy_lock_label: "Privacy lock",
      crisis_line_label: "Crisis line",
      trusted_contacts_label: "Trusted contacts",
      buddy_code_label: "Buddy code",
      buddies_label: "Buddies",
      sync_label: "Sync with another device",
      get_sync_code: "Get sync code",
      enter_sync_code: "Enter a code",
      export_format_label: "Export format",
      export_opt_json: "Full backup (.json) — for restore",
      export_opt_habits_csv: "Habit log (.csv)",
      export_opt_journal_csv: "Journal entries (.csv)",
      export_opt_journal_md: "Journal entries (.md)",
      export_opt_recovery_csv: "Recovery log (.csv)",
      export_opt_vitals_csv: "Weekly check-ins (.csv)",
      export_button: "Export",
      import_backup_button: "Import backup (.json)",
      printable_summary_label: "Printable monthly summary",
      export_summary_button: "Export summary",
      bulk_import_label: "Bulk-add habits from a list",
      import_habits_button: "Import habits (.csv/.txt)",
      reset_data_button: "Reset all data",
      device_only_note: "Everything lives only on this device, in your browser's storage. Nothing is uploaded, no account required.",
      privacy_policy_link: "Privacy policy",
      close_button: "Close",
      dialog_are_you_sure: "Are you sure?", dialog_confirm: "Confirm", dialog_cancel: "Cancel", dialog_save: "Save",

      edit_habit_title: "Edit habit",
      name_field_label: "Name",
      habit_name_placeholder: "e.g. Read 10 pages",
      why_label: "Why does this matter to you? (optional)",
      why_placeholder: "Shown as a quiet reminder",
      category_label: "Category",
      freq_label: "How many days a week?",
      anchor_label: "Stack after another habit? (optional)",
      no_anchor_option: "No anchor — stands on its own",
      save_changes: "Save changes",
      delete_habit: "Delete habit",

      recovery_options_title: "What are you working on?",

      welcome_title: "NASVOGrow",
      welcome_body: "This isn't a timer. It's a place to prove — to yourself, in small repeated ways — that you follow through. Track habits, break something that's had a grip on you, write a line most days, and watch the shape of your consistency change.",
      get_started: "Get started",
      intent_title: "What brings you here?",
      intent_sub: "Just shapes what we set up first — you'll have full access to everything either way.",
      intent_habits: "Build habits", intent_recovery: "Break something", intent_both: "Both",
      habit_step_title: "Pick one habit to start with",
      habit_step_sub: "Something small — start smaller than feels necessary. You can always add more later.",
      onb_habit_placeholder: "e.g. Drink water first thing",
      chip_water: "Drink water", chip_move: "Move", chip_read: "Read",
      recovery_step_title: "What are you working on?",
      recovery_step_sub: "Pick one to start tracking — add more anytime from Recovery. This stays on your device only.",
      goal_step_title: "Weekly rhythm goal",
      goal_step_sub: "How many days a week are you aiming to show up? You can change this anytime in Settings.",
      back_button: "Back", next_button: "Next", start_button: "Start",
      cat_health: "Health", cat_mind: "Mind", cat_productivity: "Productivity", cat_social: "Social", cat_boost: "Boosts", cat_general: "General",
      risk_reminder_label: "Risk-window check-ins",
      risk_reminder_sub: "A local reminder timed to your own highest-risk hour, based on urges & resets you've logged — recalculated as you log more. Needs Local reminders on too, and a little history before it can find a window.",
      mindful_checkins_label: "Mindful check-ins",
      mindful_checkins_sub: "If you open Growth's stats several times in a few minutes, a short skippable pause shows before the numbers do. Only applies to Growth — never to Recovery, Journal, or the crisis line.",
      mindful_pause_label: "Mindful pause before a reset",
      mindful_pause_sub: "Before \"Start over\" logs, a brief reflection shows your why and any coping plans. \"Continue — log it\" is always right there, immediately — this never blocks or delays logging a reset.",
      focus_goal_label: "Focus-time goal (optional)", focus_goal_none: "No goal — a plain checkbox",
      edit_profile: "Edit profile", add_your_name: "Add your name",
      choose_photo: "Choose photo", remove_photo: "Remove",
      username_label: "Username", username_placeholder: "e.g. quietbuilder (optional)",
      motto_label: "Your personal line (optional)", motto_placeholder: "Replaces the rotating daily line on Home with your own words",
      bio_label: "Your why (optional)", bio_placeholder: "A private reminder of why you're doing this — shown only to you",
      save_profile: "Save profile", building_since: "Building since {{date}}.",

      // ── Journal (runtime strings — see journal.js) ──
      jr_mood_good: "Good", jr_mood_okay: "Okay", jr_mood_heavy: "Heavy", jr_mood_rough: "Rough",
      jr_prompt_0: "What did you protect today, even in a small way?",
      jr_prompt_1: "Where did you show up even though it would've been easier not to?",
      jr_prompt_2: "What's one thing you're doing more of than you used to?",
      jr_prompt_3: "What resistance showed up today — and what was under it?",
      jr_prompt_4: "What would the person you're becoming thank you for today?",
      jr_prompt_5: "What's true about you now that wasn't true a month ago?",
      jr_prompt_6: "What are you tired of tolerating?",
      jr_prompt_7: "Name one thing that went quietly right today.",
      jr_write_line_first: "Write even one line first",
      jr_entry_updated: "Entry updated",
      jr_delete_title: "Delete this entry?",
      jr_delete_body: "You'll get a chance to undo right after.",
      jr_delete_label: "Delete",
      jr_entry_deleted: "Entry deleted",
      action_undo: "Undo",
      jr_write_reflection_first: "Write a line first",
      jr_already_reflected_toast: "Already reflected this week",
      jr_editing_past_entry: "Editing a past entry",
      jr_todays_prompt: "Today's prompt",
      jr_entry_placeholder: "Write anything — this is for you…",
      jr_mood_field_label: "How's this one feel? (optional)",
      jr_satisfaction_label: "How satisfying did today actually feel? (optional)",
      jr_save_changes: "Save changes",
      jr_update_entry: "Update entry",
      jr_save_entry: "Save entry",
      jr_weekly_reflection_sunday: "Weekly reflection · Sunday",
      jr_already_reflected_full: "Already reflected this week — see you next Sunday.",
      jr_reflection_placeholder: "One honest line about this week…",
      jr_save_reflection_xp: "Save reflection (+{{xp}} XP)",
      jr_search_placeholder: "Search your entries…",
      jr_search_aria: "Search your journal entries",
      jr_past_entries: "Past entries",
      jr_empty_entries: "Your entries will build up here, one line at a time.",
      jr_no_entries_plain: "No entries found.",
      jr_no_entries_matching: "No entries matching \"{{query}}\".",
      jr_no_entries_tagged: "No entries tagged {{mood}}.",
      jr_no_entries_matching_tagged: "No entries matching \"{{query}}\" tagged {{mood}}.",
      jr_edit_label: "Edit",
      jr_xp_reason_entry: "Journal entry", jr_xp_reason_reflection: "Weekly reflection",

      // ── Growth (runtime strings — see skilltree.js; skill-node and
      // achievement CONTENT itself is left for a dedicated follow-up
      // pass, same treatment as challenge content in content/ — see
      // the i18n gap-closing summary for why) ──
      gr_actions_to: "{{n}} actions to {{tier}}",
      gr_max_tier: "Maximum tier reached",
      gr_level: "Level {{n}}",
      gr_xp_of_100: "{{n}}/100 XP",
      gr_xp_to_unlock: "{{n}} XP to unlock · {{pct}}%",
      gr_unlocked_count: "Unlocked ({{n}})",
      gr_locked_count: "Locked ({{n}})",
      gr_none_unlocked: "None unlocked yet — keep going.",
      gr_all_unlocked: "Everything is unlocked. Well earned.",
      gr_ember: "Ember",
      gr_grove: "Grove",
      gr_download_streak_card: "Download streak card",
      gr_streak_card_fine_print: "A shareable image with your streak and tier — generated on this device, nothing sent anywhere. Never includes anything from Recovery.",
      gr_calm_skills_hidden: "Calm mode is on — the skill tree is hidden. It's still tracking underneath exactly as before; turn this off anytime in Settings to see it again.",
      gr_calm_achievements_hidden: "Calm mode is on — achievements are hidden. They're still tracking underneath exactly as before; turn this off anytime in Settings to see them again.",
    },

    es: {
      brand_tagline: "Conviértete en quien sigues eligiendo ser.",
      nav_home: "Inicio", nav_habits: "Hábitos", nav_recovery: "Recuperación", nav_growth: "Progreso",
      ground_yourself: "Recentrarte", settings: "Ajustes",

      home_right_now: "Ahora mismo",
      qa_check_habit: "Marcar un hábito",
      qa_write_line: "Escribir la línea de hoy",
      qa_log_urge: "Registrar un impulso resistido",
      qa_view_challenges: "Ver retos",
      qa_see_patterns: "Ver tus patrones",
      stat_level: "Nivel", stat_total_xp: "XP total", stat_actions: "Acciones registradas", stat_tier: "Nivel de identidad",

      habits_section_title: "Hábitos y Estadísticas",
      habits_section_sub: "Pequeñas decisiones repetidas — y lo que dicen tus propios datos sobre ellas.",
      habit_input_placeholder: "Añade un hábito — p. ej. Leer 10 páginas",
      add_button: "Añadir",
      your_habits: "Tus hábitos",
      insights_label: "Estadísticas",

      recovery_section_title: "Recuperación, Diario y Retos",
      recovery_section_sub: "Un contador privado y sin juicios para eso de lo que te estás alejando — y una línea al día para acompañarlo.",
      active_trackers: "Seguimientos activos",
      journal_label: "Diario",
      challenges_label: "Retos",

      growth_section_title: "Progreso",
      growth_section_sub: "Lo que desbloquea la constancia — habilidades, logros y la forma de tu racha.",
      tab_overview: "Resumen", tab_skills: "Habilidades", tab_achievements: "Logros",

      settings_title: "Ajustes",
      name_label: "¿Cómo deberíamos llamarte?",
      name_placeholder: "Tu nombre (opcional)",
      theme_label: "Tema",
      theme_dusk: "Ocaso", theme_paper: "Papel", theme_forest: "Bosque", theme_dune: "Duna", theme_slate: "Pizarra",
      language_label: "Idioma",
      weekly_goal_label: "Meta semanal — días activos por semana",
      blur_recovery_label: "Difuminar números de Recuperación",
      blur_recovery_sub: "Oculta los conteos por defecto — toca el ojo en cualquier tarjeta para verlos",
      local_reminders_label: "Recordatorios locales",
      local_reminders_sub: "Un aviso suave por la noche si hoy sigue pendiente — solo mientras esta pestaña esté abierta, nada se envía desde un servidor",
      calm_mode_label: "Modo calma",
      calm_mode_sub: "Oculta XP, niveles, el árbol de habilidades y los logros — las rachas y los hitos de recuperación siguen funcionando igual por debajo",
      context_tracking_label: "Seguimiento de sueño y contexto",
      context_tracking_sub: "Registro diario opcional de sueño + clima autoinformado, usado solo para potenciar algunas correlaciones extra en Estadísticas — nada sale de tu dispositivo, y nunca se contacta ningún servicio meteorológico",
      privacy_lock_label: "Bloqueo de privacidad",
      crisis_line_label: "Línea de crisis",
      trusted_contacts_label: "Contactos de confianza",
      buddy_code_label: "Código de compañero",
      buddies_label: "Compañeros",
      sync_label: "Sincronizar con otro dispositivo",
      get_sync_code: "Obtener código de sincronización",
      enter_sync_code: "Introducir un código",
      export_format_label: "Formato de exportación",
      export_opt_json: "Copia completa (.json) — para restaurar",
      export_opt_habits_csv: "Registro de hábitos (.csv)",
      export_opt_journal_csv: "Entradas del diario (.csv)",
      export_opt_journal_md: "Entradas del diario (.md)",
      export_opt_recovery_csv: "Registro de recuperación (.csv)",
      export_opt_vitals_csv: "Chequeos semanales (.csv)",
      export_button: "Exportar",
      import_backup_button: "Importar copia (.json)",
      printable_summary_label: "Resumen mensual imprimible",
      export_summary_button: "Exportar resumen",
      bulk_import_label: "Añadir hábitos en lote desde una lista",
      import_habits_button: "Importar hábitos (.csv/.txt)",
      reset_data_button: "Restablecer todos los datos",
      device_only_note: "Todo vive únicamente en este dispositivo, en el almacenamiento de tu navegador. Nada se sube, no se requiere cuenta.",
      privacy_policy_link: "Política de privacidad",
      close_button: "Cerrar",
      dialog_are_you_sure: "¿Estás seguro?", dialog_confirm: "Confirmar", dialog_cancel: "Cancelar", dialog_save: "Guardar",

      edit_habit_title: "Editar hábito",
      name_field_label: "Nombre",
      habit_name_placeholder: "p. ej. Leer 10 páginas",
      why_label: "¿Por qué te importa esto? (opcional)",
      why_placeholder: "Se muestra como un recordatorio discreto",
      category_label: "Categoría",
      freq_label: "¿Cuántos días a la semana?",
      anchor_label: "¿Encadenar después de otro hábito? (opcional)",
      no_anchor_option: "Sin ancla — funciona por sí solo",
      save_changes: "Guardar cambios",
      delete_habit: "Eliminar hábito",

      recovery_options_title: "¿En qué estás trabajando?",

      welcome_title: "NASVOGrow",
      welcome_body: "Esto no es un temporizador. Es un lugar para demostrarte a ti mismo, en pequeños gestos repetidos, que cumples lo que empiezas. Registra hábitos, deja atrás algo que te tenía atrapado, escribe una línea casi todos los días, y observa cómo cambia la forma de tu constancia.",
      get_started: "Empezar",
      intent_title: "¿Qué te trae por aquí?",
      intent_sub: "Solo define qué configuramos primero — tendrás acceso completo a todo de cualquier forma.",
      intent_habits: "Construir hábitos", intent_recovery: "Dejar algo atrás", intent_both: "Ambos",
      habit_step_title: "Elige un hábito para empezar",
      habit_step_sub: "Algo pequeño — empieza más pequeño de lo que parece necesario. Siempre puedes añadir más después.",
      onb_habit_placeholder: "p. ej. Beber agua al despertar",
      chip_water: "Beber agua", chip_move: "Moverte", chip_read: "Leer",
      recovery_step_title: "¿En qué estás trabajando?",
      recovery_step_sub: "Elige uno para empezar a hacer seguimiento — añade más cuando quieras desde Recuperación. Esto se queda solo en tu dispositivo.",
      goal_step_title: "Meta de ritmo semanal",
      goal_step_sub: "¿Cuántos días a la semana quieres estar activo? Puedes cambiarlo cuando quieras en Ajustes.",
      back_button: "Atrás", next_button: "Siguiente", start_button: "Empezar",
      cat_health: "Salud", cat_mind: "Mente", cat_productivity: "Productividad", cat_social: "Social", cat_boost: "Impulsos", cat_general: "General",
      risk_reminder_label: "Avisos de tu franja de riesgo",
      risk_reminder_sub: "Un recordatorio local ajustado a tu hora de mayor riesgo, según los impulsos y reinicios que has registrado — se recalcula a medida que registras más. También necesita que los recordatorios locales estén activados, y un poco de historial antes de poder encontrar una franja.",
      mindful_checkins_label: "Chequeos conscientes",
      mindful_checkins_sub: "Si abres las estadísticas de Progreso varias veces en pocos minutos, aparece una breve pausa que puedes omitir antes de ver los números. Solo afecta a Progreso — nunca a Recuperación, Diario, ni a la línea de crisis.",
      mindful_pause_label: "Pausa consciente antes de un reinicio",
      mindful_pause_sub: "Antes de que \"Empezar de nuevo\" se registre, una breve reflexión muestra tu motivo y tus planes de afrontamiento. \"Continuar — registrarlo\" siempre está ahí, de inmediato — esto nunca bloquea ni retrasa el registro de un reinicio.",
      focus_goal_label: "Meta de tiempo de enfoque (opcional)", focus_goal_none: "Sin meta — una casilla simple",
      edit_profile: "Editar perfil", add_your_name: "Añade tu nombre",
      choose_photo: "Elegir foto", remove_photo: "Quitar",
      username_label: "Nombre de usuario", username_placeholder: "p. ej. constructor_calmo (opcional)",
      motto_label: "Tu frase personal (opcional)", motto_placeholder: "Reemplaza la línea diaria rotativa en Inicio con tus propias palabras",
      bio_label: "Tu motivo (opcional)", bio_placeholder: "Un recordatorio privado de por qué haces esto — solo lo ves tú",
      save_profile: "Guardar perfil", building_since: "Construyendo esto desde {{date}}.",

      // ── Diario (cadenas en tiempo de ejecución — ver journal.js) ──
      jr_mood_good: "Bien", jr_mood_okay: "Normal", jr_mood_heavy: "Pesado", jr_mood_rough: "Difícil",
      jr_prompt_0: "¿Qué protegiste hoy, aunque fuera de forma pequeña?",
      jr_prompt_1: "¿Dónde diste la cara aunque habría sido más fácil no hacerlo?",
      jr_prompt_2: "¿Qué es algo que haces más ahora que antes?",
      jr_prompt_3: "¿Qué resistencia apareció hoy — y qué había detrás de ella?",
      jr_prompt_4: "¿Por qué te daría las gracias hoy la persona en quien te estás convirtiendo?",
      jr_prompt_5: "¿Qué es verdad sobre ti ahora que no lo era hace un mes?",
      jr_prompt_6: "¿De qué estás cansado de tolerar?",
      jr_prompt_7: "Nombra algo que hoy salió bien, en silencio.",
      jr_write_line_first: "Escribe al menos una línea primero",
      jr_entry_updated: "Entrada actualizada",
      jr_delete_title: "¿Eliminar esta entrada?",
      jr_delete_body: "Podrás deshacerlo justo después.",
      jr_delete_label: "Eliminar",
      jr_entry_deleted: "Entrada eliminada",
      action_undo: "Deshacer",
      jr_write_reflection_first: "Escribe una línea primero",
      jr_already_reflected_toast: "Ya reflexionaste esta semana",
      jr_editing_past_entry: "Editando una entrada anterior",
      jr_todays_prompt: "Pregunta de hoy",
      jr_entry_placeholder: "Escribe lo que sea — esto es para ti…",
      jr_mood_field_label: "¿Cómo se siente esta vez? (opcional)",
      jr_satisfaction_label: "¿Qué tan satisfactorio se sintió hoy realmente? (opcional)",
      jr_save_changes: "Guardar cambios",
      jr_update_entry: "Actualizar entrada",
      jr_save_entry: "Guardar entrada",
      jr_weekly_reflection_sunday: "Reflexión semanal · Domingo",
      jr_already_reflected_full: "Ya reflexionaste esta semana — nos vemos el próximo domingo.",
      jr_reflection_placeholder: "Una línea honesta sobre esta semana…",
      jr_save_reflection_xp: "Guardar reflexión (+{{xp}} XP)",
      jr_search_placeholder: "Buscar en tus entradas…",
      jr_search_aria: "Buscar en tus entradas del diario",
      jr_past_entries: "Entradas anteriores",
      jr_empty_entries: "Tus entradas se irán acumulando aquí, una línea a la vez.",
      jr_no_entries_plain: "No se encontraron entradas.",
      jr_no_entries_matching: "No hay entradas que coincidan con \"{{query}}\".",
      jr_no_entries_tagged: "No hay entradas etiquetadas como {{mood}}.",
      jr_no_entries_matching_tagged: "No hay entradas que coincidan con \"{{query}}\" etiquetadas como {{mood}}.",
      jr_edit_label: "Editar",
      jr_xp_reason_entry: "Entrada de diario", jr_xp_reason_reflection: "Reflexión semanal",

      // ── Progreso (cadenas en tiempo de ejecución — ver skilltree.js;
      // el CONTENIDO de nodos de habilidad y logros se deja para un
      // pase dedicado posterior, igual que el contenido de retos en
      // content/) ──
      gr_actions_to: "{{n}} acciones para {{tier}}",
      gr_max_tier: "Nivel máximo alcanzado",
      gr_level: "Nivel {{n}}",
      gr_xp_of_100: "{{n}}/100 XP",
      gr_xp_to_unlock: "{{n}} XP para desbloquear · {{pct}}%",
      gr_unlocked_count: "Desbloqueados ({{n}})",
      gr_locked_count: "Bloqueados ({{n}})",
      gr_none_unlocked: "Todavía no has desbloqueado ninguno — sigue así.",
      gr_all_unlocked: "Lo has desbloqueado todo. Bien merecido.",
      gr_ember: "Brasa",
      gr_grove: "Arboleda",
      gr_download_streak_card: "Descargar tarjeta de racha",
      gr_streak_card_fine_print: "Una imagen para compartir con tu racha y nivel — generada en este dispositivo, nada se envía a ningún sitio. Nunca incluye nada de Recuperación.",
      gr_calm_skills_hidden: "El modo calma está activado — el árbol de habilidades está oculto. Sigue funcionando exactamente igual por debajo; desactívalo cuando quieras en Ajustes para volver a verlo.",
      gr_calm_achievements_hidden: "El modo calma está activado — los logros están ocultos. Siguen registrándose exactamente igual por debajo; desactívalo cuando quieras en Ajustes para volver a verlos.",
    },

    hi: {
      brand_tagline: "आप जो बनना चुनते रहते हैं, वही बनें।",
      nav_home: "होम", nav_habits: "आदतें", nav_recovery: "रिकवरी", nav_growth: "ग्रोथ",
      ground_yourself: "खुद को स्थिर करें", settings: "सेटिंग्स",

      home_right_now: "अभी",
      qa_check_habit: "एक आदत पूरी करें",
      qa_write_line: "आज की लाइन लिखें",
      qa_log_urge: "रोकी गई इच्छा दर्ज करें",
      qa_view_challenges: "चैलेंज देखें",
      qa_see_patterns: "अपने पैटर्न देखें",
      stat_level: "लेवल", stat_total_xp: "कुल XP", stat_actions: "दर्ज की गई क्रियाएँ", stat_tier: "पहचान स्तर",

      habits_section_title: "आदतें और इनसाइट्स",
      habits_section_sub: "छोटे, दोहराए जाने वाले फैसले — और आपका अपना डेटा उनके बारे में क्या कहता है।",
      habit_input_placeholder: "एक आदत जोड़ें — जैसे 10 पन्ने पढ़ना",
      add_button: "जोड़ें",
      your_habits: "आपकी आदतें",
      insights_label: "इनसाइट्स",

      recovery_section_title: "रिकवरी, डायरी और चैलेंज",
      recovery_section_sub: "जिससे आप दूर हो रहे हैं, उसके लिए एक निजी, बिना जज किए गिनने वाला काउंटर — और साथ में हर दिन की एक लाइन।",
      active_trackers: "सक्रिय ट्रैकर",
      journal_label: "डायरी",
      challenges_label: "चैलेंज",

      growth_section_title: "ग्रोथ",
      growth_section_sub: "निरंतरता से क्या खुलता है — स्किल्स, बैज, और आपकी स्ट्रीक का आकार।",
      tab_overview: "ओवरव्यू", tab_skills: "स्किल्स", tab_achievements: "अचीवमेंट्स",

      settings_title: "सेटिंग्स",
      name_label: "आपको क्या कहकर बुलाएँ?",
      name_placeholder: "आपका नाम (वैकल्पिक)",
      theme_label: "थीम",
      theme_dusk: "डस्क", theme_paper: "पेपर", theme_forest: "फॉरेस्ट", theme_dune: "ड्यून", theme_slate: "स्लेट",
      language_label: "भाषा",
      weekly_goal_label: "साप्ताहिक लक्ष्य — हफ्ते में सक्रिय दिन",
      blur_recovery_label: "रिकवरी नंबर धुंधले करें",
      blur_recovery_sub: "दिनों की गिनती डिफ़ॉल्ट रूप से छिपाएँ — देखने के लिए किसी भी कार्ड पर आँख वाले आइकन पर टैप करें",
      local_reminders_label: "लोकल रिमाइंडर",
      local_reminders_sub: "अगर आज अभी भी बाकी है तो शाम को एक हल्का रिमाइंडर — सिर्फ़ तब जब यह टैब खुला हो, सर्वर से कुछ नहीं भेजा जाता",
      calm_mode_label: "शांत मोड",
      calm_mode_sub: "XP, लेवल, स्किल ट्री और अचीवमेंट्स छिपाएँ — स्ट्रीक और रिकवरी माइलस्टोन नीचे बिल्कुल पहले जैसे काम करते रहते हैं",
      context_tracking_label: "नींद और संदर्भ ट्रैकिंग",
      context_tracking_sub: "रोज़ाना नींद + खुद बताया गया मौसम का वैकल्पिक लॉग, जो सिर्फ़ इनसाइट्स में कुछ अतिरिक्त सहसंबंध दिखाने के लिए इस्तेमाल होता है — कुछ भी आपकी डिवाइस से बाहर नहीं जाता, और किसी मौसम सेवा से कभी संपर्क नहीं किया जाता",
      privacy_lock_label: "प्राइवेसी लॉक",
      crisis_line_label: "क्राइसिस लाइन",
      trusted_contacts_label: "भरोसेमंद संपर्क",
      buddy_code_label: "बडी कोड",
      buddies_label: "बडीज़",
      sync_label: "किसी और डिवाइस के साथ सिंक करें",
      get_sync_code: "सिंक कोड लें",
      enter_sync_code: "कोड डालें",
      export_format_label: "एक्सपोर्ट फ़ॉर्मेट",
      export_opt_json: "पूरा बैकअप (.json) — रीस्टोर के लिए",
      export_opt_habits_csv: "आदतों का लॉग (.csv)",
      export_opt_journal_csv: "डायरी एंट्रीज़ (.csv)",
      export_opt_journal_md: "डायरी एंट्रीज़ (.md)",
      export_opt_recovery_csv: "रिकवरी लॉग (.csv)",
      export_opt_vitals_csv: "साप्ताहिक चेक-इन (.csv)",
      export_button: "एक्सपोर्ट करें",
      import_backup_button: "बैकअप इम्पोर्ट करें (.json)",
      printable_summary_label: "प्रिंट करने योग्य मासिक सारांश",
      export_summary_button: "सारांश एक्सपोर्ट करें",
      bulk_import_label: "सूची से एक साथ कई आदतें जोड़ें",
      import_habits_button: "आदतें इम्पोर्ट करें (.csv/.txt)",
      reset_data_button: "सारा डेटा रीसेट करें",
      device_only_note: "सब कुछ सिर्फ़ इसी डिवाइस पर, आपके ब्राउज़र के स्टोरेज में रहता है। कुछ भी अपलोड नहीं होता, किसी अकाउंट की ज़रूरत नहीं।",
      privacy_policy_link: "गोपनीयता नीति",
      close_button: "बंद करें",
      dialog_are_you_sure: "क्या आप वाकई करना चाहते हैं?", dialog_confirm: "पुष्टि करें", dialog_cancel: "रद्द करें", dialog_save: "सेव करें",

      edit_habit_title: "आदत संपादित करें",
      name_field_label: "नाम",
      habit_name_placeholder: "जैसे 10 पन्ने पढ़ना",
      why_label: "यह आपके लिए क्यों मायने रखता है? (वैकल्पिक)",
      why_placeholder: "एक शांत रिमाइंडर के रूप में दिखेगा",
      category_label: "श्रेणी",
      freq_label: "हफ्ते में कितने दिन?",
      anchor_label: "किसी और आदत के बाद जोड़ें? (वैकल्पिक)",
      no_anchor_option: "कोई एंकर नहीं — अपने आप खड़ी रहती है",
      save_changes: "बदलाव सेव करें",
      delete_habit: "आदत हटाएँ",

      recovery_options_title: "आप किस पर काम कर रहे हैं?",

      welcome_title: "NASVOGrow",
      welcome_body: "यह कोई टाइमर नहीं है। यह खुद को, छोटे-छोटे दोहराए गए तरीकों से, यह साबित करने की जगह है कि आप जो शुरू करते हैं उसे पूरा करते हैं। आदतें ट्रैक करें, किसी ऐसी चीज़ से बाहर निकलें जिसने आपको जकड़ रखा था, ज़्यादातर दिन एक लाइन लिखें, और देखें कि आपकी निरंतरता का आकार कैसे बदलता है।",
      get_started: "शुरू करें",
      intent_title: "आप यहाँ क्यों आए हैं?",
      intent_sub: "इससे बस यह तय होता है कि हम पहले क्या सेट करें — हर हाल में आपको सब कुछ पूरी तरह मिलेगा।",
      intent_habits: "आदतें बनाना", intent_recovery: "किसी चीज़ से बाहर निकलना", intent_both: "दोनों",
      habit_step_title: "शुरू करने के लिए एक आदत चुनें",
      habit_step_sub: "कुछ छोटा — जितना ज़रूरी लगे उससे भी छोटा शुरू करें। बाद में और भी जोड़ सकते हैं।",
      onb_habit_placeholder: "जैसे सुबह उठते ही पानी पीना",
      chip_water: "पानी पीना", chip_move: "शरीर हिलाना", chip_read: "पढ़ना",
      recovery_step_title: "आप किस पर काम कर रहे हैं?",
      recovery_step_sub: "ट्रैक करना शुरू करने के लिए एक चुनें — बाद में रिकवरी से और जोड़ सकते हैं। यह सिर्फ़ आपकी डिवाइस पर रहता है।",
      goal_step_title: "साप्ताहिक लय का लक्ष्य",
      goal_step_sub: "आप हफ्ते में कितने दिन सक्रिय रहना चाहते हैं? इसे कभी भी सेटिंग्स में बदल सकते हैं।",
      back_button: "पीछे", next_button: "आगे", start_button: "शुरू करें",
      cat_health: "स्वास्थ्य", cat_mind: "मन", cat_productivity: "उत्पादकता", cat_social: "सामाजिक", cat_boost: "बूस्ट", cat_general: "सामान्य",
      risk_reminder_label: "जोखिम-समय चेक-इन",
      risk_reminder_sub: "आपके दर्ज किए गए इच्छाओं और रीसेट के आधार पर, आपके सबसे ज़्यादा जोखिम वाले समय पर लगाया गया एक लोकल रिमाइंडर — जैसे-जैसे आप और दर्ज करते हैं, यह फिर से गणना होता है। इसके लिए लोकल रिमाइंडर भी चालू होने चाहिए, और एक समय-सीमा खोजने के लिए थोड़ा इतिहास चाहिए।",
      mindful_checkins_label: "सचेत चेक-इन",
      mindful_checkins_sub: "अगर आप कुछ ही मिनटों में ग्रोथ के आँकड़े कई बार खोलते हैं, तो नंबर दिखने से पहले एक छोटा, छोड़ा जा सकने वाला विराम दिखेगा। यह सिर्फ़ ग्रोथ पर लागू होता है — रिकवरी, डायरी, या क्राइसिस लाइन पर कभी नहीं।",
      mindful_pause_label: "रीसेट से पहले सचेत विराम",
      mindful_pause_sub: "\"फिर से शुरू करें\" दर्ज होने से पहले, एक संक्षिप्त चिंतन आपकी वजह और कोई भी कॉपिंग प्लान दिखाता है। \"जारी रखें — दर्ज करें\" हमेशा तुरंत वहीं मौजूद रहता है — यह रीसेट दर्ज करने को कभी नहीं रोकता या टालता।",
      focus_goal_label: "फोकस-टाइम लक्ष्य (वैकल्पिक)", focus_goal_none: "कोई लक्ष्य नहीं — एक सामान्य चेकबॉक्स",
      edit_profile: "प्रोफ़ाइल संपादित करें", add_your_name: "अपना नाम जोड़ें",
      choose_photo: "फ़ोटो चुनें", remove_photo: "हटाएँ",
      username_label: "यूज़रनेम", username_placeholder: "जैसे quietbuilder (वैकल्पिक)",
      motto_label: "आपकी निजी लाइन (वैकल्पिक)", motto_placeholder: "यह होम पर घूमने वाली रोज़ाना लाइन की जगह आपके अपने शब्द दिखाएगा",
      bio_label: "आपकी वजह (वैकल्पिक)", bio_placeholder: "यह क्यों कर रहे हैं, इसका एक निजी रिमाइंडर — सिर्फ़ आपको दिखेगा",
      save_profile: "प्रोफ़ाइल सेव करें", building_since: "{{date}} से निर्माण जारी।",

      // ── डायरी (रनटाइम स्ट्रिंग्स — journal.js देखें) ──
      jr_mood_good: "अच्छा", jr_mood_okay: "ठीक-ठाक", jr_mood_heavy: "भारी", jr_mood_rough: "मुश्किल",
      jr_prompt_0: "आज आपने किसे बचाया, भले ही छोटे तरीके से?",
      jr_prompt_1: "आप कहाँ डटे रहे, भले ही न करना आसान होता?",
      jr_prompt_2: "एक चीज़ बताएं जो आप पहले से ज़्यादा कर रहे हैं?",
      jr_prompt_3: "आज कौन सा प्रतिरोध सामने आया — और उसके पीछे क्या था?",
      jr_prompt_4: "जो इंसान आप बनते जा रहे हैं, वह आज आपको किस बात के लिए धन्यवाद देगा?",
      jr_prompt_5: "आपके बारे में अभी क्या सच है जो एक महीने पहले सच नहीं था?",
      jr_prompt_6: "आप किस चीज़ को बर्दाश्त करते-करते थक गए हैं?",
      jr_prompt_7: "एक चीज़ बताएं जो आज चुपचाप सही हुई।",
      jr_write_line_first: "पहले कम से कम एक लाइन लिखें",
      jr_entry_updated: "एंट्री अपडेट हुई",
      jr_delete_title: "यह एंट्री हटाएं?",
      jr_delete_body: "इसके तुरंत बाद आप इसे वापस ला सकेंगे।",
      jr_delete_label: "हटाएं",
      jr_entry_deleted: "एंट्री हटाई गई",
      action_undo: "वापस लाएं",
      jr_write_reflection_first: "पहले एक लाइन लिखें",
      jr_already_reflected_toast: "इस हफ़्ते पहले ही चिंतन कर लिया है",
      jr_editing_past_entry: "पुरानी एंट्री संपादित कर रहे हैं",
      jr_todays_prompt: "आज का सवाल",
      jr_entry_placeholder: "कुछ भी लिखें — यह आपके लिए है…",
      jr_mood_field_label: "यह कैसा महसूस हुआ? (वैकल्पिक)",
      jr_satisfaction_label: "आज असल में कितना संतोषजनक लगा? (वैकल्पिक)",
      jr_save_changes: "बदलाव सेव करें",
      jr_update_entry: "एंट्री अपडेट करें",
      jr_save_entry: "एंट्री सेव करें",
      jr_weekly_reflection_sunday: "साप्ताहिक चिंतन · रविवार",
      jr_already_reflected_full: "इस हफ़्ते पहले ही चिंतन कर लिया है — अगले रविवार मिलते हैं।",
      jr_reflection_placeholder: "इस हफ़्ते के बारे में एक ईमानदार लाइन…",
      jr_save_reflection_xp: "चिंतन सेव करें (+{{xp}} XP)",
      jr_search_placeholder: "अपनी एंट्रीज़ में खोजें…",
      jr_search_aria: "अपनी डायरी एंट्रीज़ में खोजें",
      jr_past_entries: "पुरानी एंट्रीज़",
      jr_empty_entries: "आपकी एंट्रीज़ यहाँ धीरे-धीरे जमा होंगी, एक बार में एक लाइन।",
      jr_no_entries_plain: "कोई एंट्री नहीं मिली।",
      jr_no_entries_matching: "\"{{query}}\" से मेल खाती कोई एंट्री नहीं मिली।",
      jr_no_entries_tagged: "{{mood}} टैग वाली कोई एंट्री नहीं मिली।",
      jr_no_entries_matching_tagged: "\"{{query}}\" से मेल खाती और {{mood}} टैग वाली कोई एंट्री नहीं मिली।",
      jr_edit_label: "संपादित करें",
      jr_xp_reason_entry: "डायरी एंट्री", jr_xp_reason_reflection: "साप्ताहिक चिंतन",

      // ── ग्रोथ (रनटाइम स्ट्रिंग्स — skilltree.js देखें; स्किल-नोड और
      // अचीवमेंट का असल कंटेंट बाद के एक अलग पास के लिए छोड़ा गया है,
      // वैसे ही जैसे content/ में चैलेंज कंटेंट के साथ किया गया) ──
      gr_actions_to: "{{tier}} तक {{n}} क्रियाएँ बाकी",
      gr_max_tier: "अधिकतम स्तर तक पहुँच गए",
      gr_level: "लेवल {{n}}",
      gr_xp_of_100: "{{n}}/100 XP",
      gr_xp_to_unlock: "अनलॉक होने में {{n}} XP बाकी · {{pct}}%",
      gr_unlocked_count: "अनलॉक ({{n}})",
      gr_locked_count: "लॉक्ड ({{n}})",
      gr_none_unlocked: "अभी तक कुछ भी अनलॉक नहीं हुआ — लगे रहें।",
      gr_all_unlocked: "सब कुछ अनलॉक हो चुका है। पूरी तरह से कमाया हुआ।",
      gr_ember: "अंगारा",
      gr_grove: "बगिया",
      gr_download_streak_card: "स्ट्रीक कार्ड डाउनलोड करें",
      gr_streak_card_fine_print: "आपकी स्ट्रीक और स्तर वाली एक शेयर करने लायक इमेज — इसी डिवाइस पर बनाई गई, कहीं कुछ नहीं भेजा जाता। इसमें रिकवरी की कोई जानकारी कभी शामिल नहीं होती।",
      gr_calm_skills_hidden: "शांत मोड चालू है — स्किल ट्री छिपा हुआ है। यह अभी भी बिल्कुल पहले जैसे नीचे काम कर रहा है; इसे दोबारा देखने के लिए सेटिंग्स में कभी भी बंद करें।",
      gr_calm_achievements_hidden: "शांत मोड चालू है — अचीवमेंट्स छिपे हुए हैं। ये अभी भी बिल्कुल पहले जैसे दर्ज हो रहे हैं; इन्हें दोबारा देखने के लिए सेटिंग्स में कभी भी बंद करें।",
    },
  };

  function _detect() {
    const tags = [...(navigator.languages || []), navigator.language].filter(Boolean);
    for (const tag of tags) {
      const short = String(tag).slice(0, 2).toLowerCase();
      if (LANGS[short]) return short;
    }
    return "en";
  }

  function getLang() {
    const stored = Store.get(KEY, null);
    return stored && LANGS[stored] ? stored : _detect();
  }

  function setLang(code) {
    if (!LANGS[code]) return;
    Store.set(KEY, code);
    applyAll();
  }

  function t(key, vars) {
    const lang = getLang();
    let str = (DICT[lang] && DICT[lang][key]) ?? DICT.en[key] ?? key;
    if (vars) Object.entries(vars).forEach(([k, v]) => { str = str.replace(new RegExp(`\\{\\{${k}\\}\\}`, "g"), v); });
    return str;
  }

  /** Pluralized lookup: `key` must have both `${key}_one` and
   *  `${key}_other` entries in DICT (see e.g. toast_habit_unmarked_one/
   *  _other). English, Spanish, and Hindi all use the same simple
   *  singular(1)/plural(else) split for every string this app actually
   *  needs pluralized — this isn't a full CLDR plural-rules engine, just
   *  enough for the languages this app supports today. `count` is
   *  automatically available as {{count}} inside the string alongside
   *  any other `vars`. */
  function tn(key, count, vars) {
    const suffix = count === 1 ? "_one" : "_other";
    return t(key + suffix, { count, ...(vars || {}) });
  }

  function applyStatic() {
    document.documentElement.lang = getLang();
    document.querySelectorAll("[data-i18n]").forEach(el => { el.textContent = t(el.getAttribute("data-i18n")); });
    document.querySelectorAll("[data-i18n-placeholder]").forEach(el => el.setAttribute("placeholder", t(el.getAttribute("data-i18n-placeholder"))));
    document.querySelectorAll("[data-i18n-aria-label]").forEach(el => el.setAttribute("aria-label", t(el.getAttribute("data-i18n-aria-label"))));
    document.querySelectorAll("[data-i18n-title]").forEach(el => el.setAttribute("title", t(el.getAttribute("data-i18n-title"))));
  }

  function _populateLanguageSelect() {
    const sel = document.getElementById("languageSelect");
    if (!sel) return;
    sel.innerHTML = Object.entries(LANGS).map(([code, l]) => `<option value="${code}">${l.name}</option>`).join("");
    sel.value = getLang();
  }

  function applyAll() {
    applyStatic();
    _populateLanguageSelect();
    // Re-render whatever's on screen so anything already routed through
    // ZG.t() elsewhere picks the change up immediately too, not just chrome.
    ZG.refreshChrome?.();
    window.Profile?.render?.(); // its "Add your name" fallback etc. route through ZG.t() too, but live outside sectionRenderers
    const activeId = document.querySelector(".app-section.active")?.id?.replace("Section", "");
    if (activeId) ZG.sectionRenderers?.[activeId]?.();
  }

  document.addEventListener("DOMContentLoaded", () => {
    applyAll();
    document.getElementById("languageSelect")?.addEventListener("change", e => setLang(e.target.value));
  });

  return { t, tn, getLang, setLang, LANGS, applyStatic, applyAll };
})();
window.I18N = I18N;
ZG.t = I18N.t; // shorthand other modules can adopt incrementally, same pattern as ZG.esc
ZG.tn = I18N.tn;
