"use strict";
/* ═══════════════════════════════════════════════════════════════
   JOURNAL — rotating prompts, daily entry, weekly reflection.
   Each entry can optionally carry one mood tag — plain words, no
   emoji, same restraint as the rest of the app — which doubles as
   a light filter once entries pile up, alongside a plain-text search.
═══════════════════════════════════════════════════════════════ */
const Journal = (() => {
  const KEY = "zg_journal";
  const REFLECT_KEY = "zg_reflections";

  const MOODS = {
    good:  { label: "Good",  colorVar: "--accent" },
    okay:  { label: "Okay",  colorVar: "--gold" },
    heavy: { label: "Heavy", colorVar: "--clay" },
    rough: { label: "Rough", colorVar: "--danger" },
  };
  // MOODS.label stays fixed English — it's read by export.js's print
  // summary (a separate, lower-frequency surface not yet part of this i18n
  // pass) and used as key material elsewhere. Anywhere the LIVE in-app UI
  // shows a mood word, it goes through _moodLabel() below instead, which
  // is what actually changes with the active language.
  function _moodLabel(key) { return ZG.t ? ZG.t("jr_mood_" + key) : (MOODS[key]?.label || key); }

  const PROMPT_KEYS = ["jr_prompt_0", "jr_prompt_1", "jr_prompt_2", "jr_prompt_3", "jr_prompt_4", "jr_prompt_5", "jr_prompt_6", "jr_prompt_7"];

  function today() { return new Date().toDateString(); }
  function todayPrompt() {
    const dayNum = Math.floor(Date.now() / 86400000);
    const key = PROMPT_KEYS[dayNum % PROMPT_KEYS.length];
    return ZG.t ? ZG.t(key) : key;
  }

  function load() { return Store.get(KEY, []); }
  function save(arr) { Store.set(KEY, arr); }
  function loadReflections() { return Store.get(REFLECT_KEY, []); }
  function saveReflections(arr) { Store.set(REFLECT_KEY, arr); }

  let _editingId = null;
  let _searchQuery = "";
  let _moodFilter = null;

  function _selectedMood() {
    return document.querySelector("#jrMoodRow .halt-chip.on")?.dataset.mood || null;
  }

  function _selectedSatisfaction() {
    const input = document.getElementById("jrSatisfactionInput");
    return input && input.dataset.touched === "1" ? parseInt(input.value, 10) : null;
  }

  function saveEntry() {
    const ta = document.getElementById("jrEntryInput");
    const text = ta?.value.trim();
    if (!text) { ZG.toast(ZG.t ? ZG.t("jr_write_line_first") : "Write even one line first"); return; }
    const entries = load();
    const mood = _selectedMood();
    const satisfaction = _selectedSatisfaction();

    if (_editingId) {
      const e = entries.find(x => x.id === _editingId);
      if (e) { e.text = text; e.mood = mood; e.satisfaction = satisfaction; }
      _editingId = null;
      save(entries);
      ZG.toast(ZG.t ? ZG.t("jr_entry_updated") : "Entry updated");
      render();
      return;
    }

    const t = today();
    const existing = entries.find(e => e.date === t);
    const isNew = !existing;
    if (existing) { existing.text = text; existing.prompt = todayPrompt(); existing.mood = mood; existing.satisfaction = satisfaction; }
    else entries.unshift({ id: Date.now(), date: t, ts: Date.now(), prompt: todayPrompt(), text, mood, satisfaction });
    save(entries.slice(0, 500));
    if (isNew) { ZG.addXP(8, ZG.t ? ZG.t("jr_xp_reason_entry") : "Journal entry"); window.Challenges?.notify?.("journal"); }
    else { ZG.toast(ZG.t ? ZG.t("jr_entry_updated") : "Entry updated"); ZG.markActiveToday(); }
    render();
  }

  function startEdit(id) {
    const e = load().find(x => x.id === id);
    if (!e) return;
    _editingId = id;
    render();
    const ta = document.getElementById("jrEntryInput");
    if (ta) { ta.focus(); ta.setSelectionRange(ta.value.length, ta.value.length); }
  }

  function cancelEdit() { _editingId = null; render(); }

  async function deleteEntry(id) {
    const entries = load();
    const idx = entries.findIndex(e => e.id === id);
    if (idx < 0) return;
    const entry = entries[idx];
    const ok = await ZG.confirm({ title: ZG.t ? ZG.t("jr_delete_title") : "Delete this entry?", body: ZG.t ? ZG.t("jr_delete_body") : "You'll get a chance to undo right after.", confirmLabel: ZG.t ? ZG.t("jr_delete_label") : "Delete", danger: true });
    if (!ok) return;
    save(entries.filter(e => e.id !== id));
    if (_editingId === id) _editingId = null;
    render();
    // Deleting written, personal content is heavier than most other undo
    // moments in this app, so this keeps the confirm step above AND adds
    // an undo window after — belt and suspenders, rather than trading the
    // confirm away the way recovery.js's lighter-weight relapse-undo does.
    ZG.toast(ZG.t ? ZG.t("jr_entry_deleted") : "Entry deleted", 6000, {
      actionLabel: ZG.t ? ZG.t("action_undo") : "Undo",
      onAction: () => _restoreEntry(entry, idx),
    });
  }

  /** Puts a just-deleted entry back at (approximately) its original list
   *  position. Exposed as its own named function, same pattern as
   *  recovery.js's _undoRelapse, so the restore step is independently
   *  testable without needing to drive the confirm dialog/toast UI. */
  function _restoreEntry(entry, atIndex) {
    const cur = load();
    if (cur.some(e => e.id === entry.id)) return; // already restored — ignore a stale/duplicate Undo tap
    const restored = [...cur];
    restored.splice(Math.min(atIndex, restored.length), 0, entry);
    save(restored);
    if (_editingId === entry.id) _editingId = null;
    render();
  }

  function isSunday() { return new Date().getDay() === 0; }

  function saveReflection() {
    const input = document.getElementById("jrReflectInput");
    const text = input?.value.trim();
    if (!text) { ZG.toast(ZG.t ? ZG.t("jr_write_reflection_first") : "Write a line first"); return; }
    const list = loadReflections();
    const t = today();
    if (list.some(r => r.date === t)) { ZG.toast(ZG.t ? ZG.t("jr_already_reflected_toast") : "Already reflected this week"); return; }
    list.unshift({ date: t, ts: Date.now(), text });
    saveReflections(list.slice(0, 100));
    ZG.addXP(15, ZG.t ? ZG.t("jr_xp_reason_reflection") : "Weekly reflection");
    if (input) input.value = "";
    render();
  }

  function _renderEntriesList() {
    const container = document.getElementById("jrEntriesContainer");
    if (!container) return;
    const entries = load();
    if (!entries.length) {
      container.innerHTML = `<div class="empty-note">${ZG.t ? ZG.t("jr_empty_entries") : "Your entries will build up here, one line at a time."}</div>`;
      return;
    }
    const q = _searchQuery.trim().toLowerCase();
    const filtered = entries.filter(e => {
      if (_moodFilter && e.mood !== _moodFilter) return false;
      if (q && !e.text.toLowerCase().includes(q) && !e.prompt.toLowerCase().includes(q)) return false;
      return true;
    });
    if (!filtered.length) {
      let emptyMsg;
      if (q && _moodFilter) emptyMsg = ZG.t ? ZG.t("jr_no_entries_matching_tagged", { query: ZG.esc(_searchQuery), mood: ZG.esc(_moodLabel(_moodFilter)) }) : `No entries matching "${ZG.esc(_searchQuery)}" tagged ${ZG.esc(_moodLabel(_moodFilter))}.`;
      else if (q) emptyMsg = ZG.t ? ZG.t("jr_no_entries_matching", { query: ZG.esc(_searchQuery) }) : `No entries matching "${ZG.esc(_searchQuery)}".`;
      else if (_moodFilter) emptyMsg = ZG.t ? ZG.t("jr_no_entries_tagged", { mood: ZG.esc(_moodLabel(_moodFilter)) }) : `No entries tagged ${ZG.esc(_moodLabel(_moodFilter))}.`;
      else emptyMsg = ZG.t ? ZG.t("jr_no_entries_plain") : "No entries found.";
      container.innerHTML = `<div class="empty-note">${emptyMsg}</div>`;
      return;
    }
    container.innerHTML = `<div class="jr-entries">` + filtered.slice(0, 30).map(e => {
      const d = new Date(e.ts).toLocaleDateString("en", { weekday: "short", month: "short", day: "numeric" });
      const mood = e.mood && MOODS[e.mood] ? MOODS[e.mood] : null;
      const moodTag = mood ? `<span class="jr-mood-tag" style="--mood-c:var(${mood.colorVar})">${_moodLabel(e.mood)}</span>` : "";
      return `<div class="jr-entry${_editingId === e.id ? " editing" : ""}">
        <div class="jr-entry-meta"><span class="jr-entry-date">${d}${moodTag}</span><span class="jr-entry-q">${ZG.esc(e.prompt)}</span></div>
        <div class="jr-entry-text">${ZG.esc(e.text)}</div>
        <div class="jr-entry-actions">
          <button class="btn-quiet" onclick="Journal.startEdit(${e.id})">${ZG.t ? ZG.t("jr_edit_label") : "Edit"}</button>
          <button class="btn-quiet" onclick="Journal.deleteEntry(${e.id})">${ZG.t ? ZG.t("jr_delete_label") : "Delete"}</button>
        </div>
      </div>`;
    }).join("") + `</div>`;
  }

  function _wireEntryControls() {
    const chips = document.querySelectorAll("#jrMoodRow .halt-chip");
    chips.forEach(b => b.addEventListener("click", () => {
      const wasOn = b.classList.contains("on");
      chips.forEach(x => x.classList.remove("on"));
      if (!wasOn) b.classList.add("on");
    }));
    const search = document.getElementById("jrSearchInput");
    search?.addEventListener("input", e => { _searchQuery = e.target.value; _renderEntriesList(); });
    document.querySelectorAll(".jr-mood-filter [data-mood-filter]").forEach(btn => {
      btn.addEventListener("click", () => {
        const mood = btn.dataset.moodFilter;
        _moodFilter = _moodFilter === mood ? null : mood;
        render();
      });
    });
    const satisfactionInput = document.getElementById("jrSatisfactionInput");
    const satisfactionReadout = document.getElementById("jrSatisfactionReadout");
    satisfactionInput?.addEventListener("input", () => {
      satisfactionInput.dataset.touched = "1";
      if (satisfactionReadout) satisfactionReadout.textContent = satisfactionInput.value + "/10";
    });
  }

  function render() {
    const body = document.getElementById("journalBody");
    if (!body) { return; }
    const entries = load();
    const t = today();
    const todayEntry = entries.find(e => e.date === t);
    const reflections = loadReflections();
    const reflectedThisWeek = reflections.some(r => r.date === t);

    const editingEntry = _editingId ? entries.find(e => e.id === _editingId) : null;
    const activeMood = editingEntry ? editingEntry.mood : (todayEntry ? todayEntry.mood : null);
    const activeSatisfaction = editingEntry ? editingEntry.satisfaction : (todayEntry ? todayEntry.satisfaction : null);
    let html = `
      <div class="card">
        <div class="jr-prompt">
          <div class="jr-prompt-label">${editingEntry ? (ZG.t ? ZG.t("jr_editing_past_entry") : "Editing a past entry") : (ZG.t ? ZG.t("jr_todays_prompt") : "Today's prompt")}</div>
          <div class="jr-prompt-text">${editingEntry ? ZG.esc(new Date(editingEntry.ts).toLocaleDateString("en", { weekday: "long", month: "short", day: "numeric" })) : ZG.esc(todayPrompt())}</div>
        </div>
        <textarea id="jrEntryInput" placeholder="${ZG.t ? ZG.esc(ZG.t("jr_entry_placeholder")) : "Write anything — this is for you…"}" rows="4">${editingEntry ? ZG.esc(editingEntry.text) : (todayEntry ? ZG.esc(todayEntry.text) : "")}</textarea>
        <div class="field-label" id="jrMoodLabel" style="margin-top:10px">${ZG.t ? ZG.t("jr_mood_field_label") : "How's this one feel? (optional)"}</div>
        <div class="halt-row jr-mood-row" id="jrMoodRow" role="group" aria-labelledby="jrMoodLabel">
          ${Object.keys(MOODS).map(k => `<button type="button" class="halt-chip${activeMood === k ? " on" : ""}" data-mood="${k}">${_moodLabel(k)}</button>`).join("")}
        </div>
        <label class="field-label" for="jrSatisfactionInput">${ZG.t ? ZG.t("jr_satisfaction_label") : "How satisfying did today actually feel? (optional)"} <span id="jrSatisfactionReadout">${activeSatisfaction != null ? activeSatisfaction + "/10" : "—"}</span></label>
        <input type="range" id="jrSatisfactionInput" min="1" max="10" value="${activeSatisfaction ?? 5}" data-touched="${activeSatisfaction != null ? "1" : "0"}"/>
        <div class="jr-save-row">
          <button class="btn-primary" onclick="Journal.saveEntry()" style="flex:1">${editingEntry ? (ZG.t ? ZG.t("jr_save_changes") : "Save changes") : (todayEntry ? (ZG.t ? ZG.t("jr_update_entry") : "Update entry") : (ZG.t ? ZG.t("jr_save_entry") : "Save entry"))}</button>
          ${editingEntry ? `<button class="btn-ghost" onclick="Journal.cancelEdit()">${ZG.t ? ZG.t("dialog_cancel") : "Cancel"}</button>` : ""}
        </div>
      </div>`;

    if (isSunday()) {
      html += `
        <div class="card jr-reflect-card">
          <div class="card-eyebrow">${ZG.t ? ZG.t("jr_weekly_reflection_sunday") : "Weekly reflection · Sunday"}</div>
          ${reflectedThisWeek
            ? `<p class="dim">${ZG.t ? ZG.t("jr_already_reflected_full") : "Already reflected this week — see you next Sunday."}</p>`
            : `<textarea id="jrReflectInput" placeholder="${ZG.t ? ZG.esc(ZG.t("jr_reflection_placeholder")) : "One honest line about this week…"}" rows="3"></textarea>
               <div class="jr-save-row"><button class="btn-secondary" onclick="Journal.saveReflection()" style="flex:1">${ZG.t ? ZG.t("jr_save_reflection_xp", { xp: 15 }) : "Save reflection (+15 XP)"}</button></div>`}
        </div>`;
    }

    if (entries.length) {
      html += `
        <div class="jr-search-row">
          <input type="text" id="jrSearchInput" placeholder="${ZG.t ? ZG.esc(ZG.t("jr_search_placeholder")) : "Search your entries…"}" aria-label="${ZG.t ? ZG.esc(ZG.t("jr_search_aria")) : "Search your journal entries"}" value="${ZG.esc(_searchQuery)}"/>
        </div>
        <div class="halt-row jr-mood-filter">
          ${Object.keys(MOODS).map(k => `<button type="button" class="halt-chip${_moodFilter === k ? " on" : ""}" data-mood-filter="${k}">${_moodLabel(k)}</button>`).join("")}
        </div>
        <div class="jr-divider">${ZG.t ? ZG.t("jr_past_entries") : "Past entries"}</div>
        <div id="jrEntriesContainer"></div>`;
    }

    body.innerHTML = html;
    _wireEntryControls();
    _renderEntriesList();
  }

  ZG.sectionRenderers.recovery = render;
  // Rendered on demand the first time Recovery is opened (see sectionRenderers
  // above and showSection() in app.js) rather than unconditionally on every
  // page load — Recovery isn't the default landing screen, so building its
  // journal card up front just wastes main-thread time on every visit.

  return { saveEntry, saveReflection, startEdit, cancelEdit, deleteEntry, render, load, MOODS, totalEntries: () => load().length };
})();
window.Journal = Journal;
