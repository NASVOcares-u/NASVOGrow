# NASVOGrow portable export schema

**Schema id:** `nasvogrow.portable` · **Current version:** `1`

This is a stable, documented, versioned alternative to NASVOGrow's raw
localStorage backup. It exists because the raw backup is
implementation-coupled — it's every internal `zg_*` key, verbatim — so
renaming or reshaping any internal key would silently break every
backup anyone had already taken. Given this app's whole pitch is "your
data, portable, forever" (see `privacy.html`), that coupling is worth
closing.

This format is **additive**. The existing "Full backup (.json)" export
still exists, unchanged, in Settings. This is a second option — pick
whichever you'd rather rely on. Both can be re-imported; the app
auto-detects which kind of file you're importing.

## Top-level shape

```json
{
  "schema": "nasvogrow.portable",
  "schemaVersion": 1,
  "exportedAt": "2026-09-14T12:00:00.000Z",
  "profile": { ... },
  "settings": { ... },
  "progress": { ... },
  "habits": { ... },
  "journal": { ... },
  "recovery": { ... },
  "challenges": { ... },
  "vitals": { ... },
  "context": { ... }
}
```

A namespace is only present if there's actually data for it — an
export from a fresh install with no journal entries yet simply omits
`journal.reflections` rather than including an empty placeholder.

## Field reference

Every field below is a **stable, public name**. The "Internal key
today" column is exactly that — an implementation detail that this
schema exists specifically to insulate you from. If a future version
of the app reshapes how something is stored internally, the field name
on the left stays the same; only the private mapping to an internal
key changes (see `portable-export.js`'s `FIELD_MAP`, the single source
of truth this document mirrors).

### `profile`
| Field | Type | Internal key today |
|---|---|---|
| `name` | string | `zg_name` |
| `username` | string | `zg_username` |
| `motto` | string | `zg_motto` |
| `bio` | string | `zg_bio` |
| `avatarDataUrl` | string (data URL) | `zg_avatar` |
| `joinedDate` | string (`Date.toDateString()`) | `zg_joined_date` |

### `settings`
| Field | Type | Internal key today |
|---|---|---|
| `theme` | string | `zg_theme` |
| `language` | string | `zg_lang` |
| `canvasTheme` | string | `zg_canvas_theme` |
| `weeklyGoal` | number (1–7) | `zg_weekly_goal` |
| `privacyVeil` | boolean | `zg_privacy_veil` |
| `calmMode` | boolean | `zg_calm_mode` |
| `notificationsEnabled` | boolean | `zg_notify_enabled` |
| `riskNotifyEnabled` | boolean | `zg_risk_notify_enabled` |
| `mindfulCheckins` | boolean | `zg_focus_mindful_checkins` |
| `mindfulPause` | boolean | `zg_focus_mindful_relapse_pause` |
| `crisisCountry` | string (ISO country code, or `"auto"`/`"other"`) | `zg_country` |
| `onboarded` | string (`"1"` once onboarding is done) | `zg_onboarded` |
| `security` | object `{enabled, scope, hash, disguise, disguiseName}` — `hash` is a one-way SHA-256 of a PIN, never the PIN itself | `zg_security` |
| `trustedContacts` | array of `{id, name, phone, email, message}` | `zg_trusted_contacts` |

### `progress`
| Field | Type | Internal key today |
|---|---|---|
| `xp` | number | `zg_xp` |
| `totalActions` | number | `zg_total_actions` |
| `streak` | number | `zg_streak` |
| `longestStreak` | number | `zg_longest_streak` |
| `lastActiveDate` | string (`Date.toDateString()`) | `zg_last_active_date` |
| `activeDates` | array of date strings (capped at the most recent ~60) | `zg_active_dates` |
| `unlockedSkills` | array of skill-node ids | `zg_unlocked_skills` |
| `achievements` | object mapping achievement id → unlock timestamp (ms) | `zg_achievements` |

### `habits`
| Field | Type | Internal key today |
|---|---|---|
| `data` | object `{habits, log, awarded, dismissedStackSuggestions?, dismissedLevelUps?}` — see `habits.js` | `zg_habits` |
| `completionHours` | array of hour-of-day integers (0–23), used to time the adaptive evening reminder | `zg_habit_completion_hours` |

### `journal`
| Field | Type | Internal key today |
|---|---|---|
| `entries` | array of `{id, date, ts, prompt, text, mood?, satisfaction?}` | `zg_journal` |
| `reflections` | array of `{date, ts, text}` (weekly reflections) | `zg_reflections` |

### `recovery`
| Field | Type | Internal key today |
|---|---|---|
| `data` | object `{trackers: {[categoryId]: {addedAt, streakStart, urges, relapses, milestones, copingPlans, why}}}` | `zg_recovery` |

### `challenges`
| Field | Type | Internal key today |
|---|---|---|
| `data` | object `{active, history}` | `zg_challenges` |

### `vitals`
| Field | Type | Internal key today |
|---|---|---|
| `entries` | array of `{weekKey, craving, mood, energy, ts}` | `zg_vitals` |

### `context`
| Field | Type | Internal key today |
|---|---|---|
| `data` | object `{enabled, log}` — opt-in sleep/weather log | `zg_context` |

## Deliberately excluded

These are device-local bookkeeping, not data worth restoring onto a
different device, and are never part of a portable export:

- `zg_schema_version` — this device's own migration state. Importing a
  foreign value here could make the migration runner skip steps this
  device still needs.
- `zg_last_section`, `zg_last_export_ts`, `zg_last_notify_date`,
  `zg_last_risk_notify_date`, `zg_last_digest_week`, `zg_daily_line_*`
  — one-shot or per-day UI bookkeeping that regenerates on its own.
- `zg_ai_key`, `zg_ai_insight_cache` — deprecated; `migrations.js`
  already removes these outright.

## Versioning policy

- `schemaVersion` only increases when the **public field shape**
  changes (a field renamed, restructured, added as required, or
  removed) — not when an internal key is renamed, since that's exactly
  what this schema exists to hide from you.
- Importing a file with a **higher** `schemaVersion` than the running
  app understands is refused with a clear message asking you to update
  the app first, rather than silently guessing at an unfamiliar shape.
- Importing a file with a **lower** `schemaVersion` than current is
  expected to keep working — old exports should stay importable.

## Import modes

- **Replace** (default, matches the existing full-backup import):
  wipes this device's data and writes the imported fields fresh.
- **Merge**: routes the same data through `sync.js`'s existing
  per-domain merge rules — additive across two devices' histories
  (deduped habit logs, latest-edit-wins journal entries, unioned
  recovery events, and so on) instead of one replacing the other.
