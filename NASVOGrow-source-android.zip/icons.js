"use strict";
/* ═══════════════════════════════════════════════════════════════
   ICONS — a small, deliberately abstract line-icon set.
   No emoji anywhere in the app. Two reasons:
     1. A considered product doesn't reach for 🔥/🎮/🍷 — it reads
        as a toy, not something you'd trust with a recovery streak.
     2. For the Recovery section specifically, literal depictions of
        a substance (a wine glass, a cigarette) are a known cue —
        seeing the thing can trigger the craving it's meant to help
        with. Every recovery icon here is deliberately non-literal.
   All icons share one grammar: 24×24 viewBox, stroke=currentColor,
   no fill, rounded joins — so color and size are controlled entirely
   by the CSS of whatever wraps them.
═══════════════════════════════════════════════════════════════ */
const Icons = (() => {
  const PATHS = {
    // Brand / growth — reused across tiers, default achievement glyph
    growth: `<path d="M12 21V11"/><path d="M5 4a7 7 0 0 0 7 7 7 7 0 0 0 7-7"/><path d="M5 10a7 7 0 0 0 7 7 7 7 0 0 0 7-7"/>`,
    // Streaks / momentum
    flame: `<path d="M12 3c1.5 2.6 1 4.2-.4 6C10 11 9 12.6 9 14.5A3.5 3.5 0 0 0 12.5 18 4 4 0 0 0 16 14c1.2 1 2 2.5 2 4a6 6 0 1 1-12 0c0-3.5 2-5.6 3.6-8C10.8 7.8 12 5.6 12 3z"/>`,
    // Habits / done
    check: `<path d="M4.5 12.5l5 5 10-11"/>`,
    // Journal
    book: `<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H19v16H6.5A2.5 2.5 0 0 0 4 21.5v-16z"/><path d="M4 19a2.5 2.5 0 0 1 2.5-2.5H19"/>`,
    // Challenges
    flag: `<path d="M6 21V4"/><path d="M6 4h12l-2.4 4L18 12H6"/>`,
    // Level / XP
    star: `<path d="M12 3.5l2.6 5.5 5.9.8-4.3 4.2 1 6-5.2-2.9-5.2 2.9 1-6-4.3-4.2 5.9-.8z"/>`,
    // Recovery — general / pornography (protection, without depicting anything)
    shield: `<path d="M12 3l7 3v6c0 4.5-3 7.5-7 9-4-1.5-7-4.5-7-9V6z"/>`,
    // Recovery — social media (endless scroll, as a still ripple, not a phone)
    wave: `<path d="M3 15c2-2 4-2 6 0s4 2 6 0 4-2 6 0"/><path d="M3 9c2-2 4-2 6 0s4 2 6 0 4-2 6 0"/>`,
    // Recovery — gaming (a facet/hexagon; deliberately not a controller)
    facet: `<path d="M12 3l8 4.5v9L12 21l-8-4.5v-9z"/><path d="M12 3v9M4 7.5l8 4.5 8-4.5M12 21v-9"/>`,
    // Recovery — caffeine (a single drop)
    droplet: `<path d="M12 3c3.5 4.5 6 7.8 6 11a6 6 0 1 1-12 0c0-3.2 2.5-6.5 6-11z"/>`,
    // Recovery — nicotine (breath / exhale, not a cigarette)
    wind: `<path d="M3 12h11a3 3 0 1 0-2.5-4.7"/><path d="M3 17h14a2.6 2.6 0 1 0-2-4.2"/>`,
    // Recovery — alcohol (an anchor — steady, not a glass/bottle)
    anchor: `<circle cx="12" cy="5" r="2"/><path d="M12 7v13"/><path d="M6 12H3a9 9 0 0 0 9 9 9 9 0 0 0 9-9h-3"/>`,
    // Recovery — compulsive eating (balance, not food)
    scale: `<path d="M12 3v18"/><path d="M5 8h14"/><path d="M5 8l-3 6a3.5 3.5 0 0 0 6 0z"/><path d="M19 8l-3 6a3.5 3.5 0 0 0 6 0z"/>`,
    // Recovery — cannabis (rising haze, not a leaf)
    haze: `<path d="M8 21c1.2-2.6-1-4-1-6.5s2.2-3.9 1-6.5S6.8 4 8 2"/><path d="M15 21c1.2-2.6-1-4-1-6.5s2.2-3.9 1-6.5S13.8 4 15 2"/>`,
    // Recovery — gambling (a ring with something in orbit — chance, not cards/dice/chips)
    orbit: `<ellipse cx="12" cy="12" rx="9" ry="4.5"/><circle cx="19.4" cy="12" r="1.5" fill="currentColor" stroke="none"/>`,
    // Recovery — compulsive spending (an inward, unending loop)
    spiral: `<path d="M12 12c1.8 0 3-1.3 3-3s-1.6-3.5-4-3.5-5 2-5 5.5 2.7 6.5 6.5 6.5S20 14.3 20 9"/>`,
    // Recovery — sugar & junk food (a craving spike, not the food itself)
    pulse: `<path d="M3 13h4l2-7 4 14 2-7h6"/>`,
    // Privacy
    eye: `<path d="M2 12s3.8-6.5 10-6.5S22 12 22 12s-3.8 6.5-10 6.5S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>`,
    eyeOff: `<path d="M3 3l18 18"/><path d="M10.6 5.7A10.6 10.6 0 0 1 12 5.5c6.2 0 10 6.5 10 6.5a15.6 15.6 0 0 1-3.3 4.1M6.6 6.6C4 8.3 2 12 2 12s3.8 6.5 10 6.5c1.4 0 2.6-.3 3.7-.8"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/>`,
    lock: `<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>`,
    // Insights — a lens, for looking closely at your own data
    lens: `<circle cx="10.5" cy="10.5" r="6.5"/><path d="M20 20l-5-5"/>`,
    // Urge-surfing — concentric ripples, echoing the breath itself (not a wave/phone/pill)
    breath: `<circle cx="12" cy="12" r="2.6"/><circle cx="12" cy="12" r="6.4" stroke-opacity=".55"/><circle cx="12" cy="12" r="10.2" stroke-opacity=".28"/>`,
    // Reach out to a trusted contact — a signal, not a phone icon
    signal: `<circle cx="12" cy="19" r="1.3" fill="currentColor" stroke="none"/><path d="M8.5 14.8a5 5 0 0 1 7 0"/><path d="M5.5 11.3a9.3 9.3 0 0 1 13 0"/>`,
    // Personal "why" / values anchor — a compass, not a quote mark
    compass: `<circle cx="12" cy="12" r="9"/><path d="M15.2 8.8l-2.1 5.3-5.3 2.1 2.1-5.3z"/>`,
    // Money saved — a coin, abstract enough that it's a neutral concept
    // (unlike a substance, money isn't a relapse cue for any tracker type)
    money: `<circle cx="12" cy="12" r="8.5"/><path d="M12 6.8v10.4"/><path d="M14.7 9.3c-.5-.8-1.5-1.1-2.5-1.1-1.5 0-2.6.7-2.6 1.7 0 2.3 5.2.8 5.2 3.2 0 1-1.1 1.7-2.6 1.7-1.1 0-2.1-.3-2.6-1.1"/>`,
    // Time reclaimed — a plain clock face, same reasoning as money above
    clock: `<circle cx="12" cy="12" r="8.5"/><path d="M12 7.2v5.3l3.6 2.1"/>`,
    // Identity DNA archetypes — night / morning orientation
    moon: `<path d="M20 13.2A8.2 8.2 0 0 1 10.8 4a8.5 8.5 0 1 0 9.2 9.2z"/>`,
    sunrise: `<path d="M12 3v4.2M5.6 9l1.5 1.5M18.4 9l-1.5 1.5M3 18h18M7 18a5 5 0 0 1 10 0"/>`,
  };

  /** Returns an inline <svg> string. `strokeWidth` defaults to 1.7 to match the nav icons. */
  function svg(name, strokeWidth = 1.7) {
    const p = PATHS[name] || PATHS.growth;
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${strokeWidth}" stroke-linecap="round" stroke-linejoin="round">${p}</svg>`;
  }

  /** Returns a ready-to-place icon wrapped in a sized, colored circle chip. */
  function chip(name, { size = 38, color = "var(--accent)", bg = null, strokeWidth = 1.7 } = {}) {
    const background = bg || `color-mix(in srgb, ${color} 14%, transparent)`;
    return `<span class="icon-chip" style="--chip-size:${size}px;--chip-color:${color};--chip-bg:${background}">${svg(name, strokeWidth)}</span>`;
  }

  return { svg, chip, PATHS };
})();
window.Icons = Icons;
