"use strict";
/* ═══════════════════════════════════════════════════════════════
   NASVOGrow — Service Worker
   Purpose: make the installed/standalone app actually open with no
   connection, not just load faster. Nothing here touches app data —
   all of that stays in localStorage, untouched by this file.

   Strategy: stale-while-revalidate for same-origin GETs. Serve the
   cached copy instantly if there is one (so offline just works),
   and quietly refresh the cache in the background when online.
   Cross-origin requests are never intercepted (the app makes none now
   that the fonts are self-hosted).
═══════════════════════════════════════════════════════════════ */

const CACHE_NAME = "nasvogrow-v5.6";
const CORE_ASSETS = [
  "/",
  "/index.html",
  "/styles.css",
  "/styles-extra.css",
  "/native-bridge.js",
  "/migrations.js",
  "/app.js",
  "/i18n.js",
  "/icons.js",
  "/profile.js",
  "/content/challenge-defs.js",
  "/content/recovery-expectations.js",
  "/content/recovery-learn-topics.js",
  "/habits.js",
  "/journal.js",
  "/challenges.js",
  "/skilltree.js",
  "/recovery.js",
  "/context.js",
  "/vitals.js",
  "/focus.js",
  "/safety.js",
  "/correlations.js",
  "/insights.js",
  "/sync.js",
  "/buddy.js",
  "/portable-export.js",
  "/auto-backup.js",
  "/export.js",
  "/digest.js",
  "/streak-card.js",
  "/native-app.js",
  "/site.webmanifest",
  "/404.html",
  "/privacy.html",
  "/assets/img/logo.bb07c779.webp",
  "/assets/img/favicon.7a5ea502.png",
  "/assets/fonts/fraunces.7234ed86.woff2",
  "/assets/fonts/work-sans.1dd49afc.woff2",
  "/assets/fonts/space-mono-400.fb4a81a2.woff2",
  "/assets/fonts/space-mono-700.2d46bd15.woff2",
];

self.addEventListener("install", (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(CORE_ASSETS.map((u) => new Request(u, { cache: "reload" }))))
      .catch(() => {}) // best-effort — a failed precache shouldn't block install
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys()
      .then((names) => Promise.all(names.filter((n) => n !== CACHE_NAME).map((n) => caches.delete(n))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;

  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return; // never intercept cross-origin calls

  event.respondWith(
    caches.match(req).then((cached) => {
      const network = fetch(req)
        .then((res) => {
          if (res && res.status === 200) {
            const copy = res.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(req, copy));
          }
          return res;
        })
        .catch(() => cached || caches.match("/404.html"));
      return cached || network;
    })
  );
});
