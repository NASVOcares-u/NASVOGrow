"use strict";
/* ═══════════════════════════════════════════════════════════════
   WEEKLY DIGEST — a short "here's your week" card that surfaces on
   its own, instead of a weekly summary only ever existing when
   someone thinks to go export it (see export.js's monthly summary,
   which this deliberately reuses the same spirit of rather than a
   second copy of its data-gathering — this reads the same local
   data every other module already reads; nothing new is collected,
   and nothing here is ever sent anywhere, same standing rule as the
   rest of this app).

   Shows at most once per calendar week, on the first Home visit ON
   OR AFTER Monday — so someone who only opens the app on a Thursday
   still sees last week's digest instead of nothing, but a second
   visit that same week doesn't show it again. Dismissible, never
   blocking, same restraint as the backup nudge and the stack-
   suggestion card elsewhere in this app. Says nothing at all for a
   week with no logged activity — an empty digest reads as a guilt
   trip, not a summary.

   Respects the two existing display settings the same way every
   other quantified surface in this app does: Calm Mode hides the
   one gamified line (challenges completed); the privacy veil blurs
   the Recovery-derived numbers via the existing .veil-target class,
   the same as everywhere else Recovery numbers show up.
═══════════════════════════════════════════════════════════════ */
const WeeklyDigest = (() => {
  const LAST_SHOWN_KEY = "zg_last_digest_week";

  function _weekStart(d = new Date()) {
    const dt = new Date(d); const day = (dt.getDay() + 6) % 7; // Monday=0, same convention used throughout the app
    dt.setHours(0, 0, 0, 0); dt.setDate(dt.getDate() - day);
    return dt;
  }

  function _lastWeekRange() {
    const thisWeekStart = _weekStart();
    const start = new Date(thisWeekStart); start.setDate(start.getDate() - 7);
    return { start, end: thisWeekStart }; // end is exclusive
  }

  function _inRange(ts, start, end) { return ts >= start.getTime() && ts < end.getTime(); }
  function _dateInRange(dateStr, start, end) { const t = new Date(dateStr).getTime(); return t >= start.getTime() && t < end.getTime(); }

  function computeLastWeek() {
    const { start, end } = _lastWeekRange();

    const h = window.Habits?.load?.() || { habits: [], log: {} };
    let habitDone = 0;
    const activeDays = new Set();
    Object.entries(h.log || {}).forEach(([dateStr, ids]) => {
      if (!_dateInRange(dateStr, start, end)) return;
      if ((ids || []).length) { habitDone += ids.length; activeDays.add(dateStr); }
    });
    const habitPossible = h.habits.length * 7;

    const journalCount = (window.Journal?.load?.() || []).filter(e => _dateInRange(e.date, start, end)).length;

    const rec = window.Recovery?.load?.() || { trackers: {} };
    let urgesResisted = 0, relapses = 0;
    Object.values(rec.trackers).forEach(t => {
      urgesResisted += (t.urges || []).filter(u => _inRange(u.ts, start, end)).length;
      relapses += (t.relapses || []).filter(r => _inRange(r.ts, start, end)).length;
    });

    const challengesDone = (window.Challenges?.load?.().history || []).filter(c => c.completed && _inRange(c.endTs, start, end)).length;

    return {
      start, end, habitDone, habitPossible, activeDaysCount: activeDays.size,
      journalCount, urgesResisted, relapses, challengesDone,
      hasRecoveryTrackers: Object.keys(rec.trackers).length > 0,
    };
  }

  function _hasAnythingToShow(w) {
    return w.habitDone > 0 || w.journalCount > 0 || w.urgesResisted > 0 || w.relapses > 0 || w.challengesDone > 0;
  }

  function shouldShow() {
    const thisWeekKey = _weekStart().toDateString();
    if (localStorage.getItem(LAST_SHOWN_KEY) === thisWeekKey) return false;
    return _hasAnythingToShow(computeLastWeek());
  }

  function dismiss() {
    localStorage.setItem(LAST_SHOWN_KEY, _weekStart().toDateString());
    const mount = document.getElementById("weeklyDigestMount");
    if (mount) mount.innerHTML = "";
  }

  function _weekLabel(start, end) {
    const endInclusive = new Date(end); endInclusive.setDate(endInclusive.getDate() - 1);
    const fmt = (d) => d.toLocaleDateString("en", { month: "short", day: "numeric" });
    return `${fmt(start)} \u2013 ${fmt(endInclusive)}`;
  }

  function render() {
    const mount = document.getElementById("weeklyDigestMount");
    if (!mount) return;
    if (!shouldShow()) { mount.innerHTML = ""; return; }
    const w = computeLastWeek();
    const calm = ZG.getCalmMode();
    const pct = w.habitPossible > 0 ? Math.round((w.habitDone / w.habitPossible) * 100) : null;

    const rows = [];
    if (pct != null) rows.push(`<div class="digest-row"><b>${pct}%</b><span>habit check-offs (${w.habitDone}/${w.habitPossible})</span></div>`);
    rows.push(`<div class="digest-row"><b>${w.activeDaysCount}/7</b><span>active days</span></div>`);
    if (w.journalCount > 0) rows.push(`<div class="digest-row"><b>${w.journalCount}</b><span>journal entr${w.journalCount === 1 ? "y" : "ies"}</span></div>`);
    if (w.hasRecoveryTrackers) {
      rows.push(`<div class="digest-row veil-target"><b>${w.urgesResisted}</b><span>urge${w.urgesResisted === 1 ? "" : "s"} resisted</span></div>`);
      if (w.relapses > 0) rows.push(`<div class="digest-row veil-target"><b>${w.relapses}</b><span>reset${w.relapses === 1 ? "" : "s"} logged \u2014 information, not a verdict</span></div>`);
    }
    if (!calm && w.challengesDone > 0) rows.push(`<div class="digest-row"><b>${w.challengesDone}</b><span>challenge${w.challengesDone === 1 ? "" : "s"} completed</span></div>`);

    mount.innerHTML = `
      <div class="card digest-card" id="weeklyDigestCard">
        <div class="digest-head">
          <div class="card-eyebrow" style="margin-bottom:0">Your week \u2014 ${ZG.esc(_weekLabel(w.start, w.end))}</div>
          <button class="habit-del" id="weeklyDigestClose" aria-label="Dismiss">\u2715</button>
        </div>
        <div class="digest-grid">${rows.join("")}</div>
      </div>`;
    document.getElementById("weeklyDigestClose")?.addEventListener("click", dismiss);
  }

  return { render, dismiss, shouldShow, computeLastWeek };
})();
window.WeeklyDigest = WeeklyDigest;
