"use strict";
/* ═══════════════════════════════════════════════════════════════
   FOCUS — dopamine-regulation friction, kept deliberately small.

   Two honest limitations, stated up front rather than glossed over:
     • This can't restrict "high-stimulus app modules" outside itself —
       a browser sandbox means a PWA has no ability to see or block
       other apps or sites. Everything here only ever applies to
       Grow's own Growth tab (the part of THIS app that's gamified
       enough to become its own checking-compulsion) and to Grow's
       own relapse-logging moment.
     • Neither feature is a hard gate. A cooldown that can't be
       skipped, or a pause someone can't get past, is exactly the
       kind of dark pattern this app is trying to be the opposite
       of — and this app also serves people who may need their
       coping tools fast. So: always visible, always immediate,
       always skippable. Both are off by default; both are just a
       few seconds of friction, never a lock.

   Two independent opt-in settings:
     • Mindful check-ins  — if the Growth tab gets opened several
       times in a short window, a brief breathing pause shows before
       the numbers do. Recovery, Habits, and Journal are never
       touched by this — only Growth.
     • Mindful pause before a reset — before "Start over" / "I gave
       in" commits, a short interstitial surfaces the tracker's why
       and any coping plans, with "Continue — log it" always right
       there, immediately. It's a moment of reflection, not an
       obstacle — logging a reset stays exactly as fast and shame-free
       as it already was if this is off, or if you tap through it.
═══════════════════════════════════════════════════════════════ */
const Focus = (() => {
  const CHECKIN_KEY = "zg_focus_checkins";
  const CHECKIN_WINDOW_MS = 10 * 60000; // 10 minutes
  const CHECKIN_THRESHOLD = 4;          // opens within the window before a pause shows
  const COOLDOWN_SECONDS = 15;

  function mindfulCheckinsEnabled() { return Store.get("zg_focus_mindful_checkins", false); }
  function setMindfulCheckins(on) { Store.set("zg_focus_mindful_checkins", !!on); }

  function mindfulPauseEnabled() { return Store.get("zg_focus_mindful_relapse_pause", false); }
  function setMindfulPause(on) { Store.set("zg_focus_mindful_relapse_pause", !!on); }

  /* ── check-in cooldown (Growth tab only) ── */
  function _recentCheckins() {
    const now = Date.now();
    const log = Store.get(CHECKIN_KEY, []).filter(ts => now - ts < CHECKIN_WINDOW_MS);
    return log;
  }

  function _recordCheckin() {
    const log = _recentCheckins();
    log.push(Date.now());
    Store.set(CHECKIN_KEY, log.slice(-20));
    return log;
  }

  /** Called by app.js right before the Growth tab actually renders.
   *  Returns true if it handled navigation (i.e. a pause is showing) —
   *  the caller should hold off rendering Growth's content until the
   *  pause's onContinue fires. Returns false immediately if the
   *  feature is off or the threshold isn't met, so Growth opens as
   *  normal in the common case. */
  function maybeShowCheckinCooldown(onContinue) {
    if (!mindfulCheckinsEnabled()) { onContinue(); return false; }
    const log = _recordCheckin();
    if (log.length < CHECKIN_THRESHOLD) { onContinue(); return false; }
    _showCooldownOverlay(onContinue);
    return true;
  }

  function _showCooldownOverlay(onContinue) {
    document.getElementById("zgCooldownModal")?.remove();
    const wrap = document.createElement("div");
    wrap.id = "zgCooldownModal";
    wrap.className = "celebrate-wrap";
    let remaining = COOLDOWN_SECONDS;
    wrap.innerHTML = `
      <div class="celebrate-card">
        <span class="icon-chip lg" style="margin:0 auto 14px">${window.Icons?.svg("breath") || ""}</span>
        <h3 role="heading" aria-level="2" style="margin-bottom:6px">A quick pause</h3>
        <p style="font-size:0.78125rem;color:var(--muted);line-height:1.6;margin-bottom:18px">
          You've checked in on your streak and stats a few times in the last few minutes. Numbers will be exactly where you left them in <span id="zgCooldownSec">${remaining}</span>s — or skip ahead any time.
        </p>
        <button class="btn-quiet" style="width:100%" id="zgCooldownSkip">Skip — show me now</button>
      </div>`;
    document.body.appendChild(wrap);
    const secEl = wrap.querySelector("#zgCooldownSec");
    const finish = () => { clearInterval(timer); wrap.remove(); onContinue(); };
    const timer = setInterval(() => {
      remaining--;
      if (secEl) secEl.textContent = remaining;
      if (remaining <= 0) finish();
    }, 1000);
    wrap.querySelector("#zgCooldownSkip").addEventListener("click", finish);
    // Deliberately no backdrop-click-to-dismiss silently — the explicit
    // "Skip" button is the one and only fast path, so it's always visible
    // and never accidental.
  }

  /* ── mindful pause before logging a reset ── */
  /** Wraps a tracker's relapse-logging entry point. If the setting is
   *  off, calls straight through — zero behavior change. If it's on,
   *  shows a brief reflection card first; "Continue — log it" calls
   *  through immediately, same as if the setting were off. */
  function maybeShowRelapsePause(id, type, onContinue, onSurfInstead) {
    if (!mindfulPauseEnabled()) { onContinue(); return; }
    const why = window.Recovery?.load?.().trackers?.[id]?.why || "";
    const plans = window.Recovery?.load?.().trackers?.[id]?.copingPlans || [];
    document.getElementById("zgPauseModal")?.remove();
    const wrap = document.createElement("div");
    wrap.id = "zgPauseModal";
    wrap.className = "celebrate-wrap";
    wrap.innerHTML = `
      <div class="celebrate-card" style="text-align:left">
        <span class="icon-chip lg" style="--chip-color:var(${type.colorVar});margin:0 auto 14px">${window.Icons?.svg("breath") || ""}</span>
        <h3 role="heading" aria-level="2" style="text-align:center;margin-bottom:8px">Before you decide</h3>
        <p style="font-size:0.78125rem;color:var(--muted);line-height:1.6;text-align:center;margin-bottom:14px">No judgment either way. Just a breath before it's done.</p>
        ${why ? `<div class="why-box" style="margin-bottom:12px"><span class="icon-chip sm" style="--chip-color:var(${type.colorVar})">${window.Icons?.svg("compass") || ""}</span><span>${ZG.esc(why)}</span></div>` : ""}
        ${plans.length ? `<div class="why-box" style="margin-bottom:12px;flex-direction:column;align-items:stretch;gap:6px">${plans.map(p => `<span><b>If</b> ${ZG.esc(p.trigger)} <b>→</b> ${ZG.esc(p.action)}</span>`).join("")}</div>` : ""}
        <div style="display:flex;flex-direction:column;gap:8px;margin-top:6px">
          <button class="btn-quiet" style="border-color:var(${type.colorVar});color:var(${type.colorVar})" id="zgPauseSurf">Try riding it out instead</button>
          <button class="btn-ghost" id="zgPauseContinue">Continue — log it</button>
        </div>
      </div>`;
    document.body.appendChild(wrap);
    const close = () => { document.removeEventListener("keydown", onKey); wrap.remove(); };
    const onKey = (e) => { if (e.key === "Escape") close(); };
    wrap.querySelector("#zgPauseContinue").addEventListener("click", () => { close(); onContinue(); });
    wrap.querySelector("#zgPauseSurf").addEventListener("click", () => { close(); onSurfInstead(); });
    // Tapping outside (or pressing Escape) just dismisses this — same as
    // never having tapped "Start over" at all. It must never silently
    // confirm the very action this pause exists to slow down.
    wrap.addEventListener("click", e => { if (e.target === wrap) close(); });
    document.addEventListener("keydown", onKey);
  }

  return { mindfulCheckinsEnabled, setMindfulCheckins, mindfulPauseEnabled, setMindfulPause, maybeShowCheckinCooldown, maybeShowRelapsePause };
})();
window.Focus = Focus;
