#!/usr/bin/env python3
"""End-to-end smoke test of the NATIVE build in headless Chromium, with a recording mock of the
Capacitor runtime (window.Capacitor + the plugins). It exercises the real app.js / safety.js /
auto-backup.js / streak-card.js code paths that were changed for the Android shell.

  npm run build:native && python3 qa/native-e2e.py

This proves the web side talks to the plugins correctly. It does NOT prove anything about Android
itself (notification delivery, widget, biometrics, back gesture) — that needs a device (ANDROID.md).
"""
import json, sys, threading, http.server, socketserver, functools, os, time
from playwright.sync_api import sync_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WEBROOT = os.path.join(ROOT, sys.argv[1] if len(sys.argv) > 1 else "dist-native")
MODE_WEB = "--web" in sys.argv

MOCK = r"""
(() => {
  const calls = [], handlers = {};
  const rec = (plugin, method, ret) => (...a) => { calls.push([plugin, method, a[0]]); return Promise.resolve(typeof ret === 'function' ? ret(...a) : ret); };
  const listen = (plugin) => (name, fn) => { handlers[plugin + ':' + name] = fn; return Promise.resolve({ remove() {} }); };
  const pending = [];
  const Plugins = {
    LocalNotifications: {
      createChannel: rec('LN', 'createChannel'), registerActionTypes: rec('LN', 'registerActionTypes'),
      checkPermissions: rec('LN', 'checkPermissions', () => ({ display: window.__permission || 'granted' })),
      requestPermissions: rec('LN', 'requestPermissions', () => ({ display: window.__permission = 'granted' })),
      getPending: rec('LN', 'getPending', () => ({ notifications: pending.map(id => ({ id })) })),
      cancel: (o) => { calls.push(['LN', 'cancel', o]); for (const n of o.notifications) { const i = pending.indexOf(n.id); if (i >= 0) pending.splice(i, 1); } return Promise.resolve(); },
      schedule: (o) => { calls.push(['LN', 'schedule', o]); for (const n of o.notifications) pending.push(n.id); return Promise.resolve({ notifications: o.notifications.map(n => ({ id: n.id })) }); },
      addListener: listen('LN'),
    },
    App: { addListener: listen('App'), getLaunchUrl: rec('App', 'getLaunchUrl', null), exitApp: rec('App', 'exitApp') },
    Filesystem: { writeFile: rec('FS', 'writeFile', () => ({ uri: 'file:///cache/export/x' })), rmdir: rec('FS', 'rmdir') },
    Share: { share: rec('Share', 'share') },
    Haptics: { impact: rec('Haptics', 'impact'), notification: rec('Haptics', 'notification') },
    SystemBars: { setStyle: rec('SystemBars', 'setStyle') },
    PrivacyScreen: { enable: rec('Privacy', 'enable'), disable: rec('Privacy', 'disable') },
    NasvoNative: {
      biometricStatus: rec('Native', 'biometricStatus', { available: true }),
      biometricAuthenticate: (o) => { calls.push(['Native', 'biometricAuthenticate', o]); return new Promise((res) => { if (window.__bioHold) window.__bioResolve = res; else res(); }); },
      saveBackupFile: rec('Native', 'saveBackupFile'), pruneBackups: rec('Native', 'pruneBackups'),
      updateWidget: rec('Native', 'updateWidget'),
    },
  };
  window.__calls = calls; window.__handlers = handlers; window.__pending = pending;
  window.Capacitor = { isNativePlatform: () => true, isPluginAvailable: (n) => n in Plugins, Plugins };
  localStorage.setItem('zg_onboarded', '1');
})();
"""

class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
    def end_headers(self):
        self.send_header('Cache-Control', 'no-store'); super().end_headers()

def serve():
    h = functools.partial(Quiet, directory=WEBROOT)
    srv = socketserver.TCPServer(('127.0.0.1', 0), h); srv.allow_reuse_address = True
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, srv.server_address[1]

results = []
def check(name, cond, detail=''):
    results.append((name, bool(cond), detail))
    print(('PASS ' if cond else 'FAIL ') + name + (f'  [{detail}]' if detail and not cond else ''))

srv, port = serve()
URL = f'http://127.0.0.1:{port}/index.html'

with sync_playwright() as pw:
    b = pw.chromium.launch(args=['--no-sandbox'])
    ctx = b.new_context(viewport={'width': 390, 'height': 800}, service_workers='allow')
    page = ctx.new_page()
    errors = []
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.on('console', lambda m: errors.append('console.error: ' + m.text) if m.type == 'error' and 'favicon' not in m.text else None)

    # ───────────── web build: no Capacitor present → nothing changes ─────────────
    if MODE_WEB:
        ctx.add_init_script("localStorage.setItem('zg_onboarded','1')")
        page.goto(URL); page.wait_for_timeout(1200)
        check('web: loads without errors', not errors, errors[:3])
        check('web: NativeBridge present but not native', page.evaluate('NativeBridge.isNative()') is False)
        check('web: html has no is-native class', page.evaluate("!document.documentElement.classList.contains('is-native')"))
        check('web: service worker still registers (PWA unchanged)', page.evaluate("navigator.serviceWorker.getRegistrations().then(r => r.length > 0)"))
        check('web: haptic() does not throw', page.evaluate("(() => { try { ZG.haptic('tap'); return true } catch { return false } })()"))
        check('web: AutoBackup still uses the browser folder-picker path', page.evaluate("AutoBackup.isSupported() === (typeof window.showDirectoryPicker === 'function')"))
        b.close(); srv.shutdown()
        bad = [r for r in results if not r[1]]
        print(f'\n{len(results) - len(bad)}/{len(results)} passed'); sys.exit(1 if bad else 0)

    # ───────────── native build with the mock runtime ─────────────
    ctx.add_init_script(MOCK)
    page.goto(URL); page.wait_for_timeout(1500)

    calls = lambda plugin=None, method=None: page.evaluate("(([p,m]) => window.__calls.filter(c => (!p || c[0]===p) && (!m || c[1]===m)))", [plugin, method])
    clear = lambda: page.evaluate("window.__calls.length = 0")
    fire = lambda key, arg=None: page.evaluate("([k,a]) => window.__handlers[k](a)", [key, arg])

    check('boot: no page errors', not errors, errors[:3])
    check('boot: html has is-native class', page.evaluate("document.documentElement.classList.contains('is-native')"))
    check('boot: service worker NOT registered in the app', page.evaluate("navigator.serviceWorker.getRegistrations().then(r => r.length === 0)"))
    check('boot: CSP meta present', page.evaluate("!!document.querySelector('meta[http-equiv=Content-Security-Policy]')"))
    check('boot: notification channels + action types registered', len(calls('LN', 'createChannel')) == 2 and len(calls('LN', 'registerActionTypes')) == 1)
    check('boot: back/resume/url/notification listeners attached', all(page.evaluate(f"'{k}' in window.__handlers") for k in ['App:backButton', 'App:appStateChange', 'App:appUrlOpen', 'LN:localNotificationActionPerformed']))
    check('boot: system bar icon style set from the saved theme', len(calls('SystemBars', 'setStyle')) >= 1 and all(c[2]['style'] in ('DARK', 'LIGHT') for c in calls('SystemBars', 'setStyle')), calls('SystemBars', 'setStyle'))

    # ── habits + reminders ──
    page.evaluate("Habits.add('Read', 'general'); Habits.add('Walk', 'general'); Habits.add('Stretch', 'general');")
    page.wait_for_timeout(300)
    page.click('#settingsBtnMobile'); page.wait_for_timeout(500)
    check('settings: "On this phone" block renders', page.locator('#nativeSettingsSection .toggle-row').count() >= 3, page.locator('#nativeSettingsSection').count())
    check('settings: biometric + privacy rows shown (plugins present)', page.locator('#nativeBioToggle').count() == 1 and page.locator('#nativePrivacyToggle').count() == 1)
    check('settings: Install row hidden in the app', page.evaluate("document.getElementById('installRow').hidden"))
    clear()
    page.click('#notifyToggle'); page.wait_for_timeout(900)
    check('reminders: toggling on asks Android for permission', len(calls('LN', 'requestPermissions')) == 1)
    sched = calls('LN', 'schedule')
    check('reminders: schedule called after enabling', len(sched) >= 1)
    if sched:
        notes = sched[-1][2]['notifications']
        ev = [n for n in notes if 1000 <= n['id'] < 1100]
        check('reminders: evening notifications on the habits channel, inexact', ev and all(n['channelId'] == 'nasvo_habits' and n['isExactNotification'] is False for n in ev))
        check('reminders: up to 7 evenings planned', 5 <= len(ev) <= 7, len(ev))
        today_n = [n for n in ev if n['id'] == 1000]
        left = page.evaluate("(() => { const c = Habits.todayCounts(); return c.total - c.done })()")
        check("reminders: today's body counts unfinished habits", (not today_n) or today_n[0]['body'] == f'{left} habits left today.', (left, today_n[:1] and today_n[0]['body']))
    clear()
    page.evaluate("document.getElementById('closeSettingsBtn').click()"); page.wait_for_timeout(200)

    # finish every habit → today's evening nudge must disappear from the plan
    page.evaluate("const d = Habits.load(); d.habits.forEach(h => Habits.toggle(h.id));"); page.wait_for_timeout(1400)
    sched = calls('LN', 'schedule')
    if sched:
        ids = [n['id'] for n in sched[-1][2]['notifications']]
        check("reminders: all habits done → today's nudge dropped, tomorrow's kept", 1000 not in ids and 1001 in ids, ids)
    else:
        check('reminders: re-planned after completing habits', False, 'no schedule call')
    w = calls('Native', 'updateWidget')
    tc = page.evaluate("Habits.todayCounts()")
    check('widget: snapshot pushed with done/total/streak/date/title', w and w[-1][2]['done'] == tc['done'] and w[-1][2]['total'] == tc['total'] and tc['done'] == tc['total'] and w[-1][2]['title'] == 'NASVOGrow' and len(w[-1][2]['date']) == 10, (w[-1:], tc))
    check('widget: carries habits+streak only', w and set(w[-1][2].keys()) == {'enabled', 'done', 'total', 'streak', 'date', 'title'}, w[-1:] )

    # reminders off → everything of ours cancelled
    clear(); page.evaluate("ZG.setNotificationsEnabled(false)"); page.wait_for_timeout(600)
    check('reminders: turning off cancels the scheduled ones', page.evaluate("window.__pending.length === 0"), page.evaluate("window.__pending"))
    page.evaluate("ZG.setNotificationsEnabled(true)"); page.wait_for_timeout(600)

    # ── routing ──
    fire('LN:localNotificationActionPerformed', {'actionId': 'ride_it_out', 'notification': {'extra': {}}}); page.wait_for_timeout(700)
    check('route: "Ride it out" button opens Recovery', page.evaluate("document.querySelector('.app-section.active').id") == 'recoverySection')
    fire('LN:localNotificationActionPerformed', {'actionId': 'tap', 'notification': {'extra': {'route': {'section': 'habits'}}}}); page.wait_for_timeout(500)
    check('route: tapping the habits notification opens Habits', page.evaluate("document.querySelector('.app-section.active').id") == 'habitsSection')
    fire('App:appUrlOpen', {'url': 'nasvogrow://open?section=habits&action=addhabit'}); page.wait_for_timeout(900)
    check('route: shortcut nasvogrow://…action=addhabit opens the add-habit sheet', page.evaluate("!!document.querySelector('.modal.show, .celebrate-wrap')"))

    # ── back button ──
    toasts = lambda: page.evaluate("document.getElementById('toast')?.textContent || ''")
    overlays = lambda: page.evaluate("document.querySelectorAll('.celebrate-wrap').length + document.querySelectorAll('.modal.show').length")
    for _ in range(8):                      # finishing every habit above can leave celebration overlays up; Back dismisses them one by one
        if not overlays(): break
        fire('App:backButton', {}); page.wait_for_timeout(250)
    check('back: repeated presses dismiss any open overlays/sheets', overlays() == 0, overlays())
    page.evaluate("ZG.celebrate({ icon: 'check', title: 'Test', sub: 'overlay', body: 'x' })"); page.wait_for_timeout(300)
    check('back: setup - a celebration overlay is open', page.evaluate("document.querySelectorAll('.celebrate-wrap').length") == 1)
    fire('App:backButton', {}); page.wait_for_timeout(300)
    check('back: dismisses a celebration overlay first', page.evaluate("document.querySelectorAll('.celebrate-wrap').length") == 0)
    page.evaluate("ZG.openModal('settingsModal')"); page.wait_for_timeout(400)
    fire('App:backButton', {'canGoBack': False}); page.wait_for_timeout(300)
    check('back: closes the open settings sheet', page.evaluate("!document.querySelector('.modal.show')"))
    page.evaluate("ZG.showSection('growth')"); page.wait_for_timeout(500)
    fire('App:backButton', {}); page.wait_for_timeout(400)
    check('back: from another tab goes Home', page.evaluate("document.querySelector('.app-section.active').id") == 'homeSection')
    page.wait_for_timeout(3200)             # let achievement toasts expire so ours is the one on screen
    clear(); fire('App:backButton', {}); page.wait_for_timeout(300)
    check('back: at Home shows "press back again", does not exit', 'press back again' in toasts().lower() and not calls('App', 'exitApp'), toasts())
    fire('App:backButton', {}); page.wait_for_timeout(200)
    check('back: second press within 2s exits', len(calls('App', 'exitApp')) == 1)

    # ── export / share ──
    clear(); page.evaluate("_downloadBlob('a,b\\n1,2', 'habits.csv', 'text/csv')"); page.wait_for_timeout(400)
    fs = calls('FS', 'writeFile')
    check('export: file written to cache then share sheet opened', fs and fs[0][2]['path'] == 'export/habits.csv' and fs[0][2]['directory'] == 'CACHE' and len(calls('Share', 'share')) == 1, fs[:1])
    clear(); page.evaluate("StreakCard.download()"); page.wait_for_timeout(1200)
    fs = calls('FS', 'writeFile')
    check('streak card: PNG shared as base64 through the share sheet', fs and fs[0][2]['path'].endswith('.png') and len(fs[0][2].get('data', '')) > 1000 and 'encoding' not in fs[0][2], [str(f)[:120] for f in fs[:1]])

    # ── haptics + system bars ──
    clear(); page.evaluate("ZG.haptic('tap'); ZG.haptic('success')"); page.wait_for_timeout(100)
    check('haptics: native impact + success notification', len(calls('Haptics', 'impact')) == 1 and len(calls('Haptics', 'notification')) == 1)
    clear(); page.evaluate("ZG.applyTheme('light', true)"); page.wait_for_timeout(100)
    check('theme: light theme → dark status-bar icons', [c[2] for c in calls('SystemBars', 'setStyle')] == [{'style': 'LIGHT'}])

    # ── auto backup to Documents ──
    check('backup: AutoBackup reports supported in the app', page.evaluate("AutoBackup.isSupported()"))
    clear(); ok = page.evaluate("AutoBackup.chooseFolder().then(() => true, e => String(e))"); page.wait_for_timeout(300)
    sb = calls('Native', 'saveBackupFile'); pr = calls('Native', 'pruneBackups')
    valid_json = False
    if sb:
        try: json.loads(sb[0][2]['text']); valid_json = True
        except Exception: pass
    check('backup: turning on writes a real portable backup file', ok is True and sb and sb[0][2]['filename'].startswith('nasvo-grow-autobackup-') and sb[0][2]['filename'].endswith('.json') and valid_json, (ok, sb[:1] and sb[0][2]['filename']))
    check('backup: old backups pruned to 14', pr and pr[0][2] == {'prefix': 'nasvo-grow-autobackup-', 'keep': 14}, pr[:1])
    check('backup: enabled flag + last-backup time stored', page.evaluate("AutoBackup.isEnabled() && !!AutoBackup.lastBackupTs()"))

    # ── PIN lock + biometrics ──
    page.evaluate("Safety.setPin('4321', 'app')"); page.wait_for_timeout(200)
    check('lock: PIN set, app currently unlocked', page.evaluate("!Safety.needsLock('home')"))
    page.evaluate("window.__bioHold = true"); clear()
    fire('App:appStateChange', {'isActive': False}); page.wait_for_timeout(150)
    check('lock: sending the app to the background re-locks it', page.evaluate("Safety.needsLock('home')"))
    fire('App:appStateChange', {'isActive': True}); page.wait_for_timeout(900)
    check('lock: coming back shows the PIN screen straight away', page.locator('#zrLockModal').count() == 1)
    check('lock: fingerprint/face button offered', page.locator('#lockBioBtn').count() == 1)
    check('lock: biometric prompt auto-started', len(calls('Native', 'biometricAuthenticate')) == 1)
    clear(); fire('App:backButton', {}); page.wait_for_timeout(200)
    check('lock: Back on the lock screen leaves the app instead of dismissing it', len(calls('App', 'exitApp')) == 1 and page.locator('#zrLockModal').count() == 1)
    page.evaluate("window.__bioResolve()"); page.wait_for_timeout(400)           # the person authenticates
    check('lock: successful biometric unlocks', page.locator('#zrLockModal').count() == 0 and page.evaluate("!Safety.needsLock('home')"))
    fire('App:appStateChange', {'isActive': False}); fire('App:appStateChange', {'isActive': True}); page.wait_for_timeout(800)
    page.fill('#lockPinInput', '0000'); page.click('#lockUnlockBtn'); page.wait_for_timeout(300)
    check('lock: a wrong PIN is rejected', page.locator('#zrLockModal').count() == 1 and page.locator('#lockError').is_visible())
    page.fill('#lockPinInput', '4321'); page.click('#lockUnlockBtn'); page.wait_for_timeout(400)
    check('lock: the PIN still unlocks (biometrics are only a shortcut)', page.locator('#zrLockModal').count() == 0)
    page.evaluate("localStorage.setItem('zg_native_biometric', 'false')")
    fire('App:appStateChange', {'isActive': False}); clear(); fire('App:appStateChange', {'isActive': True}); page.wait_for_timeout(700)
    check('lock: biometric switched off in Settings -> no biometric button or prompt', page.locator('#zrLockModal').count() == 1 and page.locator('#lockBioBtn').count() == 0 and not calls('Native', 'biometricAuthenticate'))
    page.fill('#lockPinInput', '4321'); page.click('#lockUnlockBtn'); page.wait_for_timeout(300)
    page.evaluate("localStorage.removeItem('zg_native_biometric'); window.__bioHold = false")

    # ── private notifications / disguise ──
    page.evaluate("Safety.setDisguise(true, 'Notes')"); page.wait_for_timeout(200)
    plan = page.evaluate("NativeApp.buildPlan()")
    check('disguise: notification titles use the disguise name', plan['title']['habits'] == 'Notes' and plan['title']['recovery'] == 'Notes', plan['title'])
    page.evaluate("Safety.setDisguise(false, '')")

    # ── privacy-screen toggle ──
    page.wait_for_function("document.getElementById('toast').hidden", timeout=8000)   # a toast sits over the Settings button for ~3s
    page.click('#settingsBtnMobile'); page.wait_for_timeout(500); clear()
    page.click('#nativePrivacyToggle'); page.wait_for_timeout(200)
    check('privacy screen: toggle enables FLAG_SECURE plugin', any(c[2] and c[2].get('android', {}).get('preventScreenshots') for c in calls('Privacy', 'enable')))
    page.click('#nativePrivacyToggle'); page.wait_for_timeout(200)
    check('privacy screen: toggle off disables it', len(calls('Privacy', 'disable')) == 1)

    check('end: no uncaught page errors during the whole run', not errors, errors[:3])
    b.close(); srv.shutdown()

bad = [r for r in results if not r[1]]
print(f'\n{len(results) - len(bad)}/{len(results)} passed')
sys.exit(1 if bad else 0)
