"""Accessibility matrix: axe-core over every section, Growth tab and key dialog, in every theme at two widths,
with seeded data. Fails (exit 1) on any WCAG violation (best-practice-only rules are listed but don't fail).
  python3 qa/a11y.py [--dir dist] [--themes dark,light,...] """
import argparse, asyncio, sys
from harness import *

BEST_PRACTICE_ONLY = {"page-has-heading-one", "region"}   # axe best-practice rules Lighthouse does not run
MODALS = ["settingsModal", "habitEditModal", "habitAddModal"]

async def main(a):
    srv = start_server(ROOT / a.dir, 8301); agg = {}
    async with async_playwright() as p:
        b = await p.chromium.launch(**LAUNCH)
        for theme in a.themes.split(","):
            for vn, vp in VIEWPORTS.items():
                ctx, pg, errs = await new_page(b, 8301, vp, theme)
                async def audit(label):
                    for v in await axe(pg):
                        for n in v["nodes"]: agg.setdefault((v["id"], n["t"][:70]), set()).add(f"{theme}/{vn}/{label}")
                for sec in SECTIONS:
                    await pg.evaluate(f"ZG.showSection('{sec}')"); await settle(pg, sec != "home")
                    if await pg.query_selector(".celebrate-wrap"): await audit("celebrate-overlay"); await clear_overlays(pg)
                    await audit(sec)
                    if sec == "recovery":
                        for tab in ("journal", "challenges"):
                            await pg.evaluate(f"Recovery.showTab('{tab}')"); await pg.wait_for_timeout(200); await audit(f"recovery-{tab}")
                        await pg.evaluate("Recovery.showTab('trackers')")
                    if sec == "growth":
                        for i in range(len(await pg.query_selector_all(".growth-tab"))):
                            await pg.evaluate(f"document.querySelectorAll('.growth-tab')[{i}].click()"); await pg.wait_for_timeout(150); await audit(f"growth-tab{i}")
                await pg.evaluate("ZG.showSection('home')")
                for m in MODALS:
                    await pg.evaluate(f"openModal('{m}')"); await pg.wait_for_timeout(300); await audit(m); await pg.evaluate("closeModal()")
                if errs: print("PAGE ERRORS", theme, vn, errs[:2])
                await ctx.close()
        await b.close()
    srv.kill()
    hard = {k: v for k, v in agg.items() if k[0] not in BEST_PRACTICE_ONLY}
    print(f"axe: {len(hard)} WCAG violation target(s), {len(agg) - len(hard)} best-practice-only")
    for (rid, t), where in sorted(agg.items()):
        print(("  FAIL " if rid not in BEST_PRACTICE_ONLY else "  note "), rid, t, "|", len(where), "states e.g.", sorted(where)[:2])
    sys.exit(1 if hard else 0)

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--dir", default="dist"); ap.add_argument("--themes", default=",".join(THEMES))
    asyncio.run(main(ap.parse_args()))
