#!/bin/bash
# Full gate: build -> accessibility -> text size -> visual regression -> Lighthouse.  Usage: npm run qa
set -e; cd "$(dirname "$0")/.."
npm run build
python3 qa/a11y.py --dir dist
python3 qa/small-text.py --dir dist --fail
python3 qa/visual.py parity . dist
python3 qa/visual.py snapshot --dir dist
bash qa/lighthouse.sh 2
echo "QA passed"
