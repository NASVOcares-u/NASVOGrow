// Netlify-like static server: brotli/gzip + _headers rules. Usage: node server.mjs <dir> <port>
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path'; import zlib from 'node:zlib';
const root = path.resolve(process.argv[2]); const port = +process.argv[3] || 8080;
const mime = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.png':'image/png','.webp':'image/webp','.svg':'image/svg+xml','.json':'application/json','.webmanifest':'application/manifest+json; charset=utf-8','.txt':'text/plain; charset=utf-8','.woff2':'font/woff2'};
// parse _headers
const rules=[]; try{ let cur=null; for(const l of fs.readFileSync(path.join(root,'_headers'),'utf8').split('\n')){ if(!l.trim()||l.trim().startsWith('#'))continue; if(!/^\s/.test(l)){cur={pat:l.trim(),h:{}};rules.push(cur);} else {const i=l.indexOf(':'); cur.h[l.slice(0,i).trim()]=l.slice(i+1).trim();}}}catch{}
const match=(pat,p)=>{ const re=new RegExp('^'+pat.replace(/[.+?^${}()|[\]\\]/g,'\\$&').replace(/\*/g,'.*')+'$'); return re.test(p); };
http.createServer((req,res)=>{
  let p=decodeURIComponent(req.url.split('?')[0]); if(p.endsWith('/'))p+='index.html';
  let f=path.join(root,p); if(!f.startsWith(root)||!fs.existsSync(f)||fs.statSync(f).isDirectory()){res.statusCode=404;f=path.join(root,'404.html'); if(!fs.existsSync(f))return res.end('404');}
  const ext=path.extname(f); let body=fs.readFileSync(f);
  res.setHeader('Content-Type',mime[ext]||'application/octet-stream');
  let hasCache=false; for(const r of rules){ if(match(r.pat,p)) for(const [k,v] of Object.entries(r.h)){res.setHeader(k,v); if(k.toLowerCase()==='cache-control')hasCache=true;} }
  if(!hasCache) res.setHeader('Cache-Control','public, max-age=0, must-revalidate');
  const ae=req.headers['accept-encoding']||''; if(/text|javascript|json|svg|xml/.test(res.getHeader('Content-Type'))){ if(/br/.test(ae)){body=zlib.brotliCompressSync(body);res.setHeader('Content-Encoding','br');} else if(/gzip/.test(ae)){body=zlib.gzipSync(body);res.setHeader('Content-Encoding','gzip');} res.setHeader('Vary','Accept-Encoding'); }
  res.end(body);
}).listen(port,()=>console.log('serving',root,'on',port));
