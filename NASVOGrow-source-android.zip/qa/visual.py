"""Visual regression.
  python3 qa/visual.py snapshot [--update] [--dir dist] [--themes dark,light]
      Screenshots every section on phone+desktop and compares with qa/baseline/*.png (--update rewrites them).
  python3 qa/visual.py parity [SRC DST]
      Compares the readable source (repo root) against the built site (dist) — catches build regressions such
      as a Home rule that ended up in the on-demand stylesheet.
Fails (exit 1) when more than --tolerance pixels differ in any screenshot."""
import argparse, asyncio, io, sys
import numpy as np
from PIL import Image, ImageChops
from harness import *

BASE = QA / "baseline"; OUT = QA / "out"

async def capture(b, port, theme, vn, vp):
    ctx, pg, errs = await new_page(b, port, vp, theme); shots = {}
    for sec in SECTIONS:
        await pg.evaluate(f"ZG.showSection('{sec}')"); await settle(pg, sec != "home"); await clear_overlays(pg)
        shots[sec] = await pg.screenshot(full_page=False)
        if sec == "recovery":
            for tab in ("journal", "challenges"):
                await pg.evaluate(f"Recovery.showTab('{tab}')"); await pg.wait_for_timeout(200); shots[f"recovery-{tab}"] = await pg.screenshot(full_page=False)
            await pg.evaluate("Recovery.showTab('trackers')")
    await ctx.close(); return shots, errs

def differs(a, b):
    x, y = Image.open(io.BytesIO(a)).convert("RGB"), Image.open(io.BytesIO(b)).convert("RGB")
    if x.size != y.size: return 10**9
    return int((np.asarray(ImageChops.difference(x, y)).sum(axis=2) > 30).sum())

async def main(a):
    OUT.mkdir(exist_ok=True); BASE.mkdir(exist_ok=True); bad = 0; total = 0
    if a.cmd == "parity":
        s1, s2 = start_server(ROOT / a.src, 8311), start_server(ROOT / a.dst, 8312)
    else:
        s1 = start_server(ROOT / a.dir, 8311); s2 = None
    async with async_playwright() as p:
        b = await p.chromium.launch(**LAUNCH)
        for theme in a.themes.split(","):
            for vn, vp in VIEWPORTS.items():
                shots, errs = await capture(b, 8311, theme, vn, vp)
                if errs: print("PAGE ERRORS", theme, vn, errs[:2]); bad += 1
                other = (await capture(b, 8312, theme, vn, vp))[0] if a.cmd == "parity" else None
                for sec, png in shots.items():
                    total += 1; name = f"{theme}_{vn}_{sec}.png"
                    if a.cmd == "snapshot" and a.update: (BASE / name).write_bytes(png); continue
                    ref = other[sec] if other else ((BASE / name).read_bytes() if (BASE / name).exists() else None)
                    if ref is None: print("  no baseline for", name, "(run with --update)"); bad += 1; continue
                    n = differs(png, ref)
                    if n > a.tolerance:
                        bad += 1; print(f"  DIFF {name}: {n} px"); (OUT / f"actual_{name}").write_bytes(png); (OUT / f"expected_{name}").write_bytes(ref)
        await b.close()
    for s in (s1, s2):
        if s: s.kill()
    print(("updated" if getattr(a, "update", False) else "compared"), total, "screenshots;", "mismatches/errors:", bad)
    sys.exit(1 if bad else 0)

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("snapshot"); s.add_argument("--update", action="store_true"); s.add_argument("--dir", default="dist")
    q = sub.add_parser("parity"); q.add_argument("src", nargs="?", default="."); q.add_argument("dst", nargs="?", default="dist")
    for x in (s, q): x.add_argument("--themes", default="dark,light"); x.add_argument("--tolerance", type=int, default=150)
    asyncio.run(main(ap.parse_args()))
