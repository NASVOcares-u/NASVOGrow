# QA toolkit

Guardrails so design polish can't silently break layouts, contrast or performance.
Everything runs against the built site in `dist/` (what you deploy). Baselines cover Home, Habits, Recovery (+ its Journal and
Challenges tabs) and Growth: 24 screenshots (2 themes x phone/desktop). Fonts are self-hosted, so baselines and the manifest
screenshots no longer depend on network access.

## One-time setup
```
npm install                       # esbuild + axe-core
pip install playwright numpy pillow && playwright install chromium
```
(Set `CHROME_PATH=/path/to/chromium` to use a specific browser. Lighthouse is fetched on demand via `npx`.)

## Commands (from the repo root)
| Command | What it checks |
|---|---|
| `npm run qa` | build -> accessibility -> text size -> parity -> snapshots -> Lighthouse (the full gate) |
| `npm run qa:a11y` | axe-core on Home / Habits / Recovery / Growth tabs / key dialogs, 5 themes x phone+desktop, seeded data. Fails on any WCAG violation. |
| `npm run qa:text` | rendered-size audit: fails if any visible text (SVG labels included, after scaling) renders below 11 px, in Home / Habits / Recovery (+tabs) / Growth tabs / key dialogs at phone + desktop width. `--theme`, `--min` to vary. |
| `npm run qa:parity` | readable source vs `dist/` screenshots — catches build mistakes (e.g. a Home rule left in the on-demand stylesheet) |
| `npm run qa:visual` | `dist/` vs the committed baselines in `qa/baseline/` |
| `npm run qa:visual:update` | accept the current look as the new baseline (do this deliberately, after reviewing) |
| `npm run qa:lighthouse` | desktop Lighthouse x2; lists any failing audit |

Failures write `qa/out/actual_*.png` and `expected_*.png` side by side.

## Notes
* Screenshots use a pinned clock, pinned randomness, reduced motion and hidden canvases/toasts, so differences are real.
* The tolerance is 150 px per screenshot (`--tolerance`). Font rendering differs between machines: regenerate baselines
  on the machine/CI image you will compare on.
* Component review: open `gallery.html` from a static server at the repo root and flip through the five themes + Calm mode.
