"""Rendered-text-size audit: walks every section, Growth/Recovery tab and key dialog and lists every piece of visible text
whose *rendered* size is below a threshold (default 11 px). SVG text is measured after the SVG's own scaling, so chart labels
count at the size people actually see. Reports are grouped by CSS class so a fix lands on a rule, not on 200 nodes.
  python3 qa/small-text.py [--dir dist] [--min 11] [--theme dark] [--fail]"""
import argparse, asyncio, collections, sys
from harness import *

JS = """(min)=>{
  const out=[]; const vis=(e)=>{const r=e.getBoundingClientRect();if(r.width<1||r.height<1)return false;
    for(let n=e;n&&n.nodeType===1;n=n.parentElement){const s=getComputedStyle(n);if(s.display==='none'||s.visibility==='hidden'||+s.opacity===0)return false;}return true;};
  const w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);
  while(w.nextNode()){
    const t=w.currentNode, txt=t.nodeValue.trim(); if(!txt) continue;
    const e=t.parentElement; if(!e||['SCRIPT','STYLE','NOSCRIPT'].includes(e.tagName)||!vis(e)) continue;
    let px=parseFloat(getComputedStyle(e).fontSize);
    const svg=e.closest('svg'); if(svg&&e.getScreenCTM) px*=Math.abs(e.getScreenCTM().a);
    if(px<min-0.01){ const cls=(e.getAttribute('class')||'').trim().split(/\\s+/)[0]; out.push({sel:(e.tagName.toLowerCase()+(cls?'.'+cls:'')+(e.id?'#'+e.id:'')),px:Math.round(px*10)/10,txt:txt.slice(0,32),svg:!!svg}); }
  } return out; }"""
MODALS = ["settingsModal", "habitEditModal", "habitAddModal"]

async def main(a):
    srv = start_server(ROOT / a.dir, 8302); agg = collections.defaultdict(lambda: {"px": set(), "where": set(), "txt": ""})
    async with async_playwright() as p:
        b = await p.chromium.launch(**LAUNCH)
        for vn, vp in VIEWPORTS.items():
            ctx, pg, errs = await new_page(b, 8302, vp, a.theme)
            async def audit(label):
                for r in await pg.evaluate(JS, a.min):
                    g = agg[r["sel"]]; g["px"].add(r["px"]); g["where"].add(f"{vn}/{label}"); g["txt"] = g["txt"] or r["txt"]
            for sec in SECTIONS:
                await pg.evaluate(f"ZG.showSection('{sec}')"); await settle(pg, sec != "home")
                if await pg.query_selector(".celebrate-wrap"): await audit("overlay"); await clear_overlays(pg)
                await audit(sec)
                if sec == "recovery":
                    for tab in ("journal", "challenges"):
                        await pg.evaluate(f"Recovery.showTab('{tab}')"); await pg.wait_for_timeout(200); await audit(f"recovery-{tab}")
                    await pg.evaluate("Recovery.showTab('trackers')")
                    await pg.evaluate("document.querySelectorAll('details').forEach(d=>d.open=true)"); await audit("recovery-details-open")
                if sec == "growth":
                    for i in range(len(await pg.query_selector_all(".growth-tab"))):
                        await pg.evaluate(f"document.querySelectorAll('.growth-tab')[{i}].click()"); await pg.wait_for_timeout(250); await audit(f"growth-tab{i}")
            await pg.evaluate("ZG.showSection('home')")
            for m in MODALS:
                await pg.evaluate(f"openModal('{m}')"); await pg.wait_for_timeout(300); await audit(m); await pg.evaluate("closeModal()")
            await ctx.close()
        await b.close()
    srv.kill()
    print(f"{len(agg)} selector(s) render below {a.min}px")
    for sel, g in sorted(agg.items(), key=lambda kv: min(kv[1]["px"])):
        print(f"  {sel:34s} {','.join(str(x) for x in sorted(g['px'])):>10s}px  {len(g['where'])} states  e.g. “{g['txt']}”")
    sys.exit(1 if (a.fail and agg) else 0)

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--dir", default="dist"); ap.add_argument("--min", type=float, default=11.0)
    ap.add_argument("--theme", default="dark"); ap.add_argument("--fail", action="store_true")
    asyncio.run(main(ap.parse_args()))
