// Unit tests for native-bridge.js + native-app.js using a mock Capacitor runtime.
//   node --test qa/native-bridge.test.mjs        (or: npm run test:native)
// No browser or Android needed. These cover the JavaScript decisions only — what actually
// happens on a phone still has to be checked on a phone (see ANDROID.md).
import { test } from "node:test";
import assert from "node:assert/strict";
// Values built inside the vm context have a different Object prototype; compare their JSON shape.
const same = (a, b) => assert.deepStrictEqual(JSON.parse(JSON.stringify(a)), JSON.parse(JSON.stringify(b)));
import vm from "node:vm";
import fs from "node:fs";
import path from "node:path";

const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
const load = (f) => fs.readFileSync(path.join(ROOT, f), "utf8");

function makeEnv({ native = true, plugins = {}, extra = {} } = {}) {
  const listeners = {};
  const events = [];
  const ctx = {
    console, setTimeout, clearTimeout, URL, Promise, Date, JSON, Math, String, Object,
    Event: class { constructor(t) { this.type = t; } },
    navigator: {},
    document: {
      documentElement: { classList: { add() {} } },
      getElementById: () => null,
      addEventListener: (t, fn) => (listeners[t] ||= []).push(fn),
      querySelector: () => null,
    },
    ...extra,
  };
  ctx.window = ctx;
  ctx.dispatchEvent = (e) => events.push(e.type);
  ctx.addEventListener = () => {};
  if (native) {
    ctx.Capacitor = { isNativePlatform: () => true, isPluginAvailable: (n) => n in plugins, Plugins: plugins };
  }
  vm.createContext(ctx);
  return { ctx, events, listeners, run: (f) => vm.runInContext(load(f), ctx, { filename: f }) };
}

/** A LocalNotifications mock that records everything. */
function ln(pending = []) {
  const calls = { schedule: [], cancel: [], createChannel: [], registerActionTypes: [] };
  const handlers = {};
  return {
    calls, handlers,
    createChannel: async (c) => calls.createChannel.push(c),
    registerActionTypes: async (o) => calls.registerActionTypes.push(o),
    getPending: async () => ({ notifications: pending }),
    cancel: async (o) => calls.cancel.push(o),
    schedule: async (o) => calls.schedule.push(o),
    checkPermissions: async () => ({ display: "granted" }),
    requestPermissions: async () => ({ display: "granted" }),
    addListener: async (name, fn) => { handlers[name] = fn; },
  };
}
const app = () => {
  const handlers = {}; let exited = 0;
  return { handlers, get exited() { return exited; }, addListener: async (n, fn) => { handlers[n] = fn; }, exitApp: async () => { exited++; }, getLaunchUrl: async () => null };
};
const tick = () => new Promise((r) => setTimeout(r, 5));

test("in a normal browser every call is a safe no-op", async () => {
  const { ctx, run } = makeEnv({ native: false });
  run("native-bridge.js");
  const NB = ctx.NativeBridge;
  assert.equal(NB.isNative(), false);
  assert.equal(await NB.hasPermission(), false);
  assert.equal(await NB.requestPermission(), false);
  assert.equal(NB.haptic("tap"), false);
  assert.equal((await NB.saveFile({ filename: "a.json", text: "{}" })).ok, false);
  assert.equal(await NB.biometricAvailable(), false);
  assert.equal(NB.canBackupToDocuments(), false);
  await NB.syncReminders({ evening: [], risk: [] });   // must not throw
});

test("init registers channels, action types and listeners", async () => {
  const L = ln(), A = app();
  const { ctx, run } = makeEnv({ plugins: { LocalNotifications: L, App: A } });
  run("native-bridge.js"); await tick();
  same(L.calls.createChannel.map((c) => [c.id, c.visibility]), [["nasvo_habits", 1], ["nasvo_recovery", 0]]);
  assert.equal(L.calls.registerActionTypes[0].types.length, 2);
  same(Object.keys(A.handlers).sort(), ["appStateChange", "appUrlOpen", "backButton"]);
  assert.ok(L.handlers.localNotificationActionPerformed);
  assert.ok(ctx.NativeBridge.isNative());
});

test("syncReminders cancels only our pending ids, then schedules inexact notifications", async () => {
  const L = ln([{ id: 1000 }, { id: 1003 }, { id: 2001 }, { id: 4242 }]);   // 4242 isn't ours
  const { ctx, run } = makeEnv({ plugins: { LocalNotifications: L, App: app() } });
  run("native-bridge.js");
  const at = new Date(2026, 9, 5, 19, 0).getTime();
  await ctx.NativeBridge.syncReminders({
    title: { habits: "NASVOGrow", recovery: "Reminder" },
    evening: [{ n: 0, at, body: "2 habits left today." }],
    risk: [{ n: 0, weekday: 6, hour: 21, minute: 0, body: "x" }],
  });
  same(L.calls.cancel[0].notifications.map((n) => n.id).sort(), [1000, 1003, 2001]);
  const sent = L.calls.schedule.at(-1).notifications;
  assert.equal(sent.length, 2);
  const [e, r] = sent;
  assert.equal(e.id, 1000); assert.equal(e.channelId, "nasvo_habits"); assert.equal(e.isExactNotification, false);
  assert.equal(e.schedule.at.getTime(), at); assert.equal(e.schedule.allowWhileIdle, true);
  assert.equal(r.id, 2000); assert.equal(r.channelId, "nasvo_recovery"); same(r.schedule.on, { weekday: 6, hour: 21, minute: 0 });
  assert.equal(r.title, "Reminder");
});

test("syncReminders calls are serialised and an empty plan just cancels", async () => {
  const L = ln([{ id: 1001 }]);
  const { ctx, run } = makeEnv({ plugins: { LocalNotifications: L, App: app() } });
  run("native-bridge.js");
  const order = [];
  const origCancel = L.cancel, origSchedule = L.schedule;
  L.cancel = async (o) => { order.push("cancel"); await new Promise((r) => setTimeout(r, 10)); return origCancel(o); };
  L.schedule = async (o) => { order.push("schedule"); return origSchedule(o); };
  const plan = { evening: [{ n: 0, at: Date.now() + 1e6, body: "b" }], risk: [] };
  await Promise.all([ctx.NativeBridge.syncReminders(plan), ctx.NativeBridge.syncReminders({ evening: [], risk: [] })]);
  same(order, ["cancel", "schedule", "cancel"]);   // second sync waited for the first, and scheduled nothing
});

test("notification taps and action buttons route into the app, waiting for it to be ready", async () => {
  const L = ln();
  const { ctx, run } = makeEnv({ plugins: { LocalNotifications: L, App: app() } });
  run("native-bridge.js");
  const routed = [];
  ctx.ZG = { routeTo: (s, a) => routed.push([s, a]) };
  // cold start: app not ready yet
  L.handlers.localNotificationActionPerformed({ actionId: "tap", notification: { extra: { route: { section: "habits" } } } });
  same(routed, []);
  ctx.ZG.routeReady = true; ctx.NativeBridge.flushRoute();
  same(routed, [["habits", undefined]]);
  L.handlers.localNotificationActionPerformed({ actionId: "ride_it_out", notification: { extra: {} } });
  L.handlers.localNotificationActionPerformed({ actionId: "quick_journal", notification: { extra: {} } });
  same(routed.slice(1), [["recovery", "rideitout"], ["recovery", "journal"]]);
});

test("deep links route: nasvogrow:// and https://localhost URLs", async () => {
  const A = app();
  const { ctx, run } = makeEnv({ plugins: { App: A } });
  run("native-bridge.js");
  const routed = [];
  ctx.ZG = { routeReady: true, routeTo: (s, a) => routed.push([s, a]) };
  A.handlers.appUrlOpen({ url: "nasvogrow://open?section=recovery&action=urge" });
  A.handlers.appUrlOpen({ url: "https://localhost/index.html?section=growth" });
  A.handlers.appUrlOpen({ url: "nasvogrow://open" });   // nothing to route
  same(routed, [["recovery", "urge"], ["growth", undefined]]);
});

test("back button: handled -> stays; unhandled -> toast, then exits on a quick second press", async () => {
  const A = app(); const toasts = [];
  const { ctx, run } = makeEnv({ plugins: { App: A } });
  run("native-bridge.js");
  ctx.ZG = { handleBack: () => true, toast: (t) => toasts.push(t) };
  A.handlers.backButton({}); assert.equal(A.exited, 0);
  ctx.ZG.handleBack = () => false;
  A.handlers.backButton({}); assert.equal(A.exited, 0); assert.equal(toasts.length, 1);
  A.handlers.backButton({}); assert.equal(A.exited, 1);
});

test("back button exits immediately from the lock screen", async () => {
  const A = app();
  const { ctx, run } = makeEnv({ plugins: { App: A } });
  ctx.document.getElementById = (id) => (id === "zrLockModal" ? {} : null);
  run("native-bridge.js");
  ctx.ZG = { handleBack: () => false, toast() {} };
  A.handlers.backButton({}); assert.equal(A.exited, 1);
});

test("app lifecycle becomes nasvo:resume / nasvo:pause window events", async () => {
  const A = app();
  const { events, run } = makeEnv({ plugins: { App: A } });
  run("native-bridge.js");
  A.handlers.appStateChange({ isActive: false }); A.handlers.appStateChange({ isActive: true });
  same(events, ["nasvo:pause", "nasvo:resume"]);
});

test("saveFile writes to cache then opens the share sheet; cancel is not an error", async () => {
  const writes = [], shares = [];
  const Filesystem = { writeFile: async (a) => { writes.push(a); return { uri: "file:///cache/export/x" }; }, rmdir: async () => {} };
  let cancel = false;
  const Share = { share: async (a) => { if (cancel) throw new Error("Share canceled"); shares.push(a); } };
  const { ctx, run } = makeEnv({ plugins: { Filesystem, Share } });
  run("native-bridge.js");
  const r = await ctx.NativeBridge.saveFile({ filename: "j.json", text: "{}" });
  assert.equal(r.ok, true);
  same([writes[0].path, writes[0].directory, writes[0].encoding], ["export/j.json", "CACHE", "utf8"]);
  assert.equal(shares[0].url, "file:///cache/export/x");
  await ctx.NativeBridge.saveFile({ filename: "c.png", base64: "AAAA" });
  assert.equal(writes[1].encoding, undefined); assert.equal(writes[1].data, "AAAA");
  cancel = true;
  same(await ctx.NativeBridge.saveFile({ filename: "k", text: "" }), { ok: false, reason: "cancelled" });
  assert.equal(typeof ctx.navigator.share, "function");   // polyfill installed
});

test("haptics, system bars, privacy screen and widget go to the right plugins", async () => {
  const seen = [];
  const Haptics = { impact: async (a) => seen.push(["impact", a.style]), notification: async (a) => seen.push(["notif", a.type]) };
  const SystemBars = { setStyle: async (a) => seen.push(["bars", a.style]) };
  const PrivacyScreen = { enable: async (a) => seen.push(["priv-on", a.android.preventScreenshots]), disable: async () => seen.push(["priv-off"]) };
  const NasvoNative = { updateWidget: async (a) => seen.push(["widget", a.done]) };
  const { ctx, run } = makeEnv({ plugins: { Haptics, SystemBars, PrivacyScreen, NasvoNative } });
  run("native-bridge.js");
  const NB = ctx.NativeBridge;
  NB.haptic("tap"); NB.haptic("soft"); NB.haptic("success");
  NB.setSystemBars("dark"); NB.setSystemBars("dune");
  await NB.setPrivacyScreen(true); await NB.setPrivacyScreen(false);
  NB.pushWidget({ done: 3 });
  same(seen, [["impact", "MEDIUM"], ["impact", "LIGHT"], ["notif", "SUCCESS"], ["bars", "DARK"], ["bars", "LIGHT"], ["priv-on", true], ["priv-off"], ["widget", 3]]);
});

test("a missing optional plugin degrades instead of throwing", async () => {
  const { ctx, run } = makeEnv({ plugins: { LocalNotifications: ln(), App: app() } });   // no Haptics, no NasvoNative…
  run("native-bridge.js");
  const NB = ctx.NativeBridge;
  assert.equal(NB.haptic("tap"), false);
  assert.equal(await NB.biometricAvailable(), false);
  assert.equal(await NB.biometricAuth(), false);
  assert.equal((await NB.saveBackup("f.json", "{}")).ok, false);
  assert.equal(await NB.setPrivacyScreen(true), false);
});

/* ───────────── native-app.js: the reminder rules ───────────── */
function appEnv({ habits = { done: 0, total: 0 }, hour = 19, active = [], risk = false, windows = [], security = {}, discreet } = {}) {
  const store = { zg_security: security, zg_active_dates: active };
  if (discreet !== undefined) store.zg_native_discreet = discreet;
  const L = ln();
  const e = makeEnv({
    plugins: { LocalNotifications: L, App: app() },
    extra: {
      Store: { get: (k, d) => (k in store ? store[k] : d), set: (k, v) => { store[k] = v; } },
      _today: () => "Mon Oct 05 2026",
      Habits: { todayCounts: () => habits },
      Insights: { compute: () => ({ riskWindows: { windows } }) },
    },
  });
  e.ctx.ZG = { reminderThresholdHour: () => hour, riskRemindersEnabled: () => risk, notificationsEnabled: () => true, getStreak: () => 4, esc: (s) => s };
  e.run("native-bridge.js"); e.run("native-app.js");
  return { ...e, L };
}
const NOON = new Date(2026, 9, 5, 12, 0);   // Mon 5 Oct 2026, noon

test("plan: unfinished habits today -> 7 evenings, today's body has the count", () => {
  const { ctx } = appEnv({ habits: { done: 1, total: 4 } });
  const p = ctx.NativeApp.buildPlan(NOON);
  assert.equal(p.evening.length, 7);
  assert.equal(p.evening[0].body, "3 habits left today.");
  assert.equal(new Date(p.evening[0].at).getHours(), 19);
  assert.equal(p.evening[1].body, "A quiet reminder — today's still open.");
});

test("plan: all habits done -> today is skipped; passed hour -> today is skipped", () => {
  assert.equal(appEnv({ habits: { done: 3, total: 3 } }).ctx.NativeApp.buildPlan(NOON).evening.length, 6);
  const late = new Date(2026, 9, 5, 20, 30);
  const p = appEnv({ habits: { done: 0, total: 2 } }).ctx.NativeApp.buildPlan(late);
  assert.equal(p.evening.length, 6); assert.equal(p.evening[0].n, 1);
});

test("plan: nothing to nudge when active today and no habits (matches the web rule)", () => {
  const p = appEnv({ habits: { done: 0, total: 0 }, active: ["Mon Oct 05 2026"] }).ctx.NativeApp.buildPlan(NOON);
  assert.equal(p.evening.length, 6);
});

test("plan: risk windows become weekly entries (JS Sunday=0 -> Capacitor Sunday=1)", () => {
  const { ctx } = appEnv({ risk: true, windows: [{ dow: 0, hour: 22 }, { dow: 5, hour: 21 }] });
  const p = ctx.NativeApp.buildPlan(NOON);
  same(p.risk.map((r) => [r.weekday, r.hour, r.minute]), [[1, 22, 0], [6, 21, 0]]);
  assert.equal(p.risk[0].body, "A quiet moment to check in with yourself.");   // private notifications default on
});

test("plan: with private notifications off, the original wording and app name are used", () => {
  const { ctx } = appEnv({ risk: true, windows: [{ dow: 2, hour: 20 }], discreet: false });
  const p = ctx.NativeApp.buildPlan(NOON);
  assert.match(p.risk[0].body, /harder hour for you before/);
  assert.equal(p.title.recovery, "NASVOGrow");
});

test("plan: a disguised app never shows its real name; private titles are neutral", () => {
  assert.equal(appEnv({ security: { disguise: true, disguiseName: "Notes" } }).ctx.NativeApp.buildPlan(NOON).title.habits, "Notes");
  const t = appEnv({}).ctx.NativeApp.buildPlan(NOON).title;
  same(t, { habits: "NASVOGrow", recovery: "Reminder" });
});

test("plan: risk reminders off -> no weekly entries", () => {
  assert.equal(appEnv({ risk: false, windows: [{ dow: 1, hour: 9 }] }).ctx.NativeApp.buildPlan(NOON).risk.length, 0);
});
