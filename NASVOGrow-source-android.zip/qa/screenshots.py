"""Regenerates the install-dialog screenshots listed in site.webmanifest. Run `npm run build` first, on a machine with internet
(so the Google Fonts load), then `python3 qa/screenshots.py` and rebuild."""
import asyncio, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'qa'))
import harness as H
from playwright.async_api import async_playwright
SEED=H.SEED.replace("Meditate <b>10</b> min & \\\"breathe\\\"","Meditate for 10 minutes").replace('Meditate <b>10</b> min & "breathe"','Meditate for 10 minutes')
# Store listings must not show a personal-looking profile: drop the demo name/username/motto from the seed.
SEED=SEED.replace("S('zg_name','Sam'); S('zg_username','sam'); S('zg_motto','Small steps, every day.');","")
assert '<b>' not in SEED and 'Sam' not in SEED and 'zg_name' not in SEED
OUT=str(ROOT/'assets'/'screenshots')+'/'
async def run(b,w,h,dsf,mobile,items):
    ctx=await b.new_context(viewport={"width":w,"height":h},device_scale_factor=dsf,has_touch=mobile,is_mobile=mobile,reduced_motion="reduce")
    pg=await ctx.new_page()
    await pg.add_init_script(H.FREEZE+SEED+"localStorage.setItem('zg_theme','dark');")
    await pg.goto("http://127.0.0.1:8096/"); await H.wait_js(pg,"!!(window.ZG&&ZG.showSection)"); await pg.wait_for_timeout(600)
    for sec,name in items:
        await pg.evaluate(f"ZG.showSection('{sec}')"); await pg.wait_for_timeout(500); await H.settle(pg,css=(sec!='home'))
        await pg.evaluate("window.scrollTo(0,0)")
        await pg.screenshot(path=OUT+name); print(name)
    await ctx.close()
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path=H.CHROME,args=["--no-sandbox","--no-proxy-server"])
        srv=H.start_server(ROOT/'dist',8096)
        try:
            await run(b,390,844,2,True,[("home","home-narrow.png"),("habits","habits-narrow.png"),("recovery","recovery-narrow.png")])
            await run(b,1280,800,1,False,[("home","home-wide.png"),("recovery","recovery-wide.png")])
        finally: srv.terminate(); await b.close()
asyncio.run(main())
