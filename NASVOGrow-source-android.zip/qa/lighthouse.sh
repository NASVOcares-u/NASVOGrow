#!/bin/bash
# Lighthouse (desktop preset) against dist/ via a Netlify-like local server. Usage: bash qa/lighthouse.sh [runs]
set -e; cd "$(dirname "$0")/.."; RUNS=${1:-2}; mkdir -p qa/out
node qa/server.mjs dist 8321 >/dev/null 2>&1 & SP=$!; sleep 1.2; trap "kill $SP 2>/dev/null" EXIT
for i in $(seq 1 $RUNS); do
  npx --yes lighthouse http://127.0.0.1:8321/ --preset=desktop --output=json --output-path=qa/out/lh_$i.json --quiet \
    --chrome-flags="--headless=new --no-sandbox --no-proxy-server" >/dev/null 2>&1
  node -e "const d=require('./qa/out/lh_$i.json');const c=d.categories;console.log('run $i:',Object.entries(c).map(([k,v])=>k+' '+Math.round(v.score*100)).join(' | '));const bad=Object.values(d.audits).filter(a=>a.score!==null&&a.score<1&&!['informative','notApplicable','manual'].includes(a.scoreDisplayMode)&&!/^(first-contentful|largest-contentful|total-blocking|speed-index|interactive|max-potential|cumulative)/.test(a.id)&&a.id!=='errors-in-console');console.log(bad.length?'  failing audits: '+bad.map(a=>a.id).join(', '):'  no failing audits (excluding raw metrics)')"
done
