"""Shared helpers for the QA scripts: serve a folder like Netlify, open pages with realistic seeded data,
run axe-core. Needs: `npm install` (axe-core), `pip install playwright && playwright install chromium`.
Set CHROME_PATH to use a specific Chromium; otherwise Playwright's own is used."""
import asyncio, json, os, subprocess, sys, time
from pathlib import Path
from playwright.async_api import async_playwright

QA = Path(__file__).resolve().parent
ROOT = QA.parent
CHROME = os.environ.get("CHROME_PATH") or None
LAUNCH = dict(executable_path=CHROME, args=["--no-sandbox", "--no-proxy-server"])

def axe_source():
    p = ROOT / "node_modules" / "axe-core" / "axe.min.js"
    if not p.exists(): sys.exit("axe-core missing — run `npm install` in the repo root first.")
    return p.read_text()

# Realistic app state: streaks, habit history, recovery trackers with urges/relapses, journal entries.
SEED = """
(()=>{
 const S=(k,v)=>localStorage.setItem(k,typeof v==='string'?v:JSON.stringify(v));
 const day=(n)=>new Date(Date.now()-n*864e5).toDateString();
 if(localStorage.getItem('zg_seeded'))return;
 S('zg_seeded','1'); S('zg_onboarded','1');
 S('zg_name','Sam'); S('zg_username','sam'); S('zg_motto','Small steps, every day.');
 S('zg_streak',12); S('zg_longest_streak',19); S('zg_total_actions',87); S('zg_xp',640);
 S('zg_weekly_goal',5); S('zg_joined_date',day(40)); S('zg_last_active_date',day(0));
 S('zg_active_dates',[...Array(12).keys()].map(i=>day(i)));
 const log={},aw={}; for(let i=0;i<28;i++){ if(i%5!==3){ log[day(i)]=['h_water','h_move'].concat(i%2?['h_read']:[]); aw[day(i)]=[]; } }
 S('zg_habits',{habits:[
   {id:'h_water',name:'Drink water first thing',weeklyTarget:7,category:'health'},
   {id:'h_move',name:'Move your body',weeklyTarget:7,category:'health'},
   {id:'h_read',name:'Read a few pages',weeklyTarget:5,category:'mind'},
   {id:'h_med',name:'Meditate <b>10</b> min & "breathe"',weeklyTarget:4,category:'mind'}],log,awarded:aw});
 const urge=(d,h)=>({ts:Date.now()-d*864e5-h*36e5,note:'Wanted to scroll; walked instead',halt:['T'],intensity:6});
 S('zg_recovery',{trackers:{
  social_media:{addedAt:Date.now()-30*864e5,streakStart:Date.now()-9*864e5,urges:[urge(1,2),urge(2,5),urge(3,1),urge(6,9),urge(8,3)],relapses:[{ts:Date.now()-10*864e5,note:'Late night',halt:['L'],intensity:7,satisfaction:2}],milestones:[3,7],copingPlans:[],why:'Be present with family'},
  caffeine:{addedAt:Date.now()-20*864e5,streakStart:Date.now()-4*864e5,urges:[urge(1,1),urge(2,2)],relapses:[],milestones:[3],copingPlans:[],why:''}}});
 S('zg_journal',[0,1,2,4].map(i=>({id:Date.now()-i*864e5,date:day(i),ts:Date.now()-i*864e5,prompt:'What went well today?',text:'Entry number '+i+' — felt steadier than last week.',mood:['calm','good','low','good'][i],satisfaction:3})));
})();
"""
# Deterministic randomness and a fixed "now" (ticking), so screenshots are comparable run to run.
FREEZE = "Math.random=()=>0.5;" + """
(()=>{const R=Date,base=new R('2026-09-30T10:00:00').getTime(),t0=R.now();
class D extends R{constructor(...a){if(a.length===0)super(base+(R.now()-t0));else super(...a)}static now(){return base+(R.now()-t0)}}
window.Date=D;})();"""

def start_server(directory, port):
    p = subprocess.Popen(["node", str(QA / "server.mjs"), str(directory), str(port)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(1.2); return p

async def wait_js(pg, expr, timeout=15):
    t = time.time()
    while time.time() - t < timeout:
        try:
            if await pg.evaluate(expr): return True
        except Exception: pass
        await asyncio.sleep(0.1)
    raise TimeoutError(expr)

async def new_page(browser, port, viewport, theme="dark", seed=True, motion="reduce"):
    ctx = await browser.new_context(viewport=viewport, reduced_motion=motion)
    pg = await ctx.new_page(); errs = []
    pg.on("pageerror", lambda e: errs.append("PAGEERR " + str(e)))
    pg.on("console", lambda m: errs.append("CONSOLE " + m.text) if m.type == "error" and "ERR_" not in m.text and "403" not in m.text and "fonts.g" not in m.text else None)
    await pg.add_init_script(FREEZE + (SEED if seed else "localStorage.setItem('zg_onboarded','1');"))
    await pg.add_init_script(f"localStorage.setItem('zg_theme','{theme}');")
    await pg.goto(f"http://127.0.0.1:{port}/")
    await wait_js(pg, "!!(window.ZG && ZG.showSection)")
    await pg.wait_for_timeout(500)
    return ctx, pg, errs

async def settle(pg, css=True):
    """Freeze animations/toasts/canvases so screenshots are stable; wait for the on-demand stylesheet if needed."""
    await pg.add_style_tag(content="*,*::before,*::after{animation:none!important;transition:none!important;caret-color:transparent!important}"
                                   "canvas,#toast,.toast{visibility:hidden!important}.celebrate-wrap{opacity:1!important}")
    if css: await wait_js(pg, "!ZG.ensureExtraCss || ZG.extraCssReady===true || !!document.querySelector('link[data-extra]')", 8)
    await pg.wait_for_timeout(250)

async def axe(pg, rules=None):
    if not await pg.evaluate("!!window.axe"): await pg.evaluate("window.eval(" + json.dumps(axe_source()) + ")")
    opts = {"runOnly": {"type": "rule", "values": rules}} if rules else {}
    return await pg.evaluate("(o)=>axe.run(document,o).then(r=>r.violations.map(v=>({id:v.id,impact:v.impact,nodes:v.nodes.map(n=>({t:n.target.join(' ')}))})))", opts)

VIEWPORTS = {"desktop": {"width": 1350, "height": 940}, "mobile": {"width": 390, "height": 844}}
THEMES = ["dark", "light", "forest", "dune", "slate"]
SECTIONS = ["home", "habits", "recovery", "growth"]

async def clear_overlays(pg):
    await pg.evaluate("document.querySelectorAll('.celebrate-wrap').forEach(e=>e.remove())")
