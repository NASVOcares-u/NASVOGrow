"use strict";
/* ═══════════════════════════════════════════════════════════════
   SYNC — moving data between two devices without a server.

   This is deliberately NOT live/automatic sync — there's nowhere
   for that to run in the background from (see netlify.toml: no
   build step, no server, no database, on purpose). Instead: one
   device generates a short "sync code," you carry it over to the
   other device through any channel you already trust (the share
   sheet, a message to yourself, AirDrop), and paste it in there.
   Nothing about the code ever touches a server this app controls.

   Merging is additive wherever that's safe — habit logs, journal
   entries, recovery urges/relapses, XP/streak baselines — instead
   of wiping whichever device happens to import second. Using the
   app on a phone and a laptop during the same week shouldn't cost
   you either device's data. A plain "replace everything" option is
   still offered for people who want a clean restore instead.
═══════════════════════════════════════════════════════════════ */
const Sync = (() => {
  const SKIP_KEYS = ["zg_ai_key", "zg_ai_insight_cache"]; // deprecated feature, never carried forward
  const MAX_KEYS = ["zg_xp", "zg_total_actions", "zg_streak", "zg_longest_streak"];
  const LOCAL_WINS_KEYS = [
    "zg_name", "zg_theme", "zg_weekly_goal", "zg_privacy_veil", "zg_calm_mode",
    "zg_notify_enabled", "zg_security", "zg_trusted_contacts", "zg_canvas_theme",
    "zg_last_section", "zg_onboarded", "zg_last_export_ts", "zg_last_notify_date",
    "zg_country", // crisis-line country — a device/locale preference, not data to overwrite
    "zg_lang", // UI language preference
    "zg_username", "zg_motto", "zg_bio", "zg_avatar", // profile fields — same "fills a gap, never overwrites" treatment as zg_name
    "zg_focus_mindful_checkins", "zg_focus_mindful_relapse_pause", // Focus friction settings — device preferences, not data
    "zg_risk_notify_enabled", // risk-window reminder toggle — device preference, not data
    "zg_native_discreet", "zg_native_privacy", "zg_native_biometric", "zg_native_widget", // Android-app device settings
  ];

  function _safeParse(str, fallback) {
    try { const v = JSON.parse(str); return v == null ? fallback : v; } catch { return fallback; }
  }

  /* ── collect everything this device has ── */
  function _collect() {
    const data = {};
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k?.startsWith("zg_") && !SKIP_KEYS.includes(k)) data[k] = localStorage.getItem(k);
    }
    return data;
  }

  /* ── encode/decode: gzip+base64 when available, plain base64 otherwise.
     Both are self-describing via a short prefix, and a bare pasted JSON
     backup (from the existing Export button) is accepted too. ── */
  async function _encode(dataObj) {
    const json = JSON.stringify(dataObj);
    if (typeof CompressionStream === "function") {
      try {
        const stream = new Blob([json]).stream().pipeThrough(new CompressionStream("gzip"));
        const buf = await new Response(stream).arrayBuffer();
        let binary = ""; new Uint8Array(buf).forEach(b => binary += String.fromCharCode(b));
        return "NGZ1:" + btoa(binary);
      } catch { /* fall through to plain encoding below */ }
    }
    return "NG01:" + btoa(unescape(encodeURIComponent(json)));
  }

  async function _decode(code) {
    code = (code || "").trim();
    if (code.startsWith("NGZ1:")) {
      const binary = atob(code.slice(5));
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
      const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream("gzip"));
      const buf = await new Response(stream).arrayBuffer();
      return JSON.parse(new TextDecoder().decode(buf));
    }
    if (code.startsWith("NG01:")) return JSON.parse(decodeURIComponent(escape(atob(code.slice(5)))));
    return JSON.parse(code); // tolerate a raw pasted backup file's contents too
  }

  /* ── per-domain merge rules ── */
  function _mergeHabits(localRaw, incomingRaw) {
    const local = _safeParse(localRaw, { habits: [], log: {}, awarded: {} });
    const incoming = _safeParse(incomingRaw, null);
    if (!incoming) return local;
    const byId = new Map((local.habits || []).map(h => [h.id, h]));
    (incoming.habits || []).forEach(h => { if (!byId.has(h.id)) byId.set(h.id, h); });
    const log = { ...(local.log || {}) };
    Object.entries(incoming.log || {}).forEach(([date, ids]) => { log[date] = [...new Set([...(log[date] || []), ...ids])]; });
    const awarded = { ...(local.awarded || {}) };
    Object.entries(incoming.awarded || {}).forEach(([date, ids]) => { awarded[date] = [...new Set([...(awarded[date] || []), ...ids])]; });
    const dismissedStackSuggestions = [...new Set([...(local.dismissedStackSuggestions || []), ...(incoming.dismissedStackSuggestions || [])])];
    return { habits: [...byId.values()], log, awarded, dismissedStackSuggestions };
  }

  function _mergeJournal(localRaw, incomingRaw) {
    const local = _safeParse(localRaw, []);
    const incoming = _safeParse(incomingRaw, []);
    const byDate = new Map(local.map(e => [e.date, e]));
    incoming.forEach(e => { const cur = byDate.get(e.date); if (!cur || (e.ts || 0) > (cur.ts || 0)) byDate.set(e.date, e); });
    return [...byDate.values()].sort((a, b) => b.ts - a.ts);
  }

  function _mergeReflections(localRaw, incomingRaw) {
    const local = _safeParse(localRaw, []);
    const incoming = _safeParse(incomingRaw, []);
    const byDate = new Map(local.map(r => [r.date, r]));
    incoming.forEach(r => { if (!byDate.has(r.date)) byDate.set(r.date, r); });
    return [...byDate.values()].sort((a, b) => b.ts - a.ts);
  }

  /** One entry per calendar week — if both devices logged the same week
   *  (e.g. checked in on phone, then again on laptop), the more recent
   *  edit wins, same "latest wins per key" rule as coping plans below. */
  function _mergeVitals(localRaw, incomingRaw) {
    const local = _safeParse(localRaw, []);
    const incoming = _safeParse(incomingRaw, []);
    const byWeek = new Map(local.map(v => [v.weekKey, v]));
    incoming.forEach(v => {
      const cur = byWeek.get(v.weekKey);
      if (!cur || (v.ts || 0) > (cur.ts || 0)) byWeek.set(v.weekKey, v);
    });
    return [...byWeek.values()].sort((a, b) => b.ts - a.ts);
  }

  function _mergeContext(localRaw, incomingRaw) {
    const local = _safeParse(localRaw, { enabled: false, log: {} });
    const incoming = _safeParse(incomingRaw, null);
    if (!incoming) return local;
    const log = { ...(local.log || {}) };
    Object.entries(incoming.log || {}).forEach(([date, entry]) => {
      const cur = log[date];
      if (!cur || (entry.ts || 0) > (cur.ts || 0)) log[date] = entry;
    });
    // Enabled on either device means enabled after merge — no reason to
    // silently drop data one device was already logging.
    return { enabled: !!(local.enabled || incoming.enabled), log };
  }

  /** zg_joined_date is a stamp, not a preference — if both devices have
   *  one (e.g. each independently back-filled it before ever syncing),
   *  the earlier one is the truer "since" date, not whichever happened
   *  to sync first. */
  function _mergeEarliestDateStr(localRaw, incomingRaw) {
    const local = _safeParse(localRaw, null);
    const incoming = _safeParse(incomingRaw, null);
    if (!local) return incoming;
    if (!incoming) return local;
    return new Date(incoming) < new Date(local) ? incoming : local;
  }

  function _mergeCopingPlans(localArr, incomingArr) {
    const byId = new Map((localArr || []).map(p => [p.id, p]));
    (incomingArr || []).forEach(p => {
      const cur = byId.get(p.id);
      if (!cur || (p.updatedAt || 0) > (cur.updatedAt || 0)) byId.set(p.id, p);
    });
    return [...byId.values()];
  }

  function _mergeEventList(a, b) {
    const seen = new Set(); const out = [];
    [...(a || []), ...(b || [])].forEach(e => { if (seen.has(e.ts)) return; seen.add(e.ts); out.push(e); });
    return out.sort((x, y) => x.ts - y.ts);
  }

  function _mergeRecovery(localRaw, incomingRaw) {
    const local = _safeParse(localRaw, { trackers: {} });
    const incoming = _safeParse(incomingRaw, null);
    if (!incoming) return local;
    const trackers = { ...(local.trackers || {}) };
    Object.entries(incoming.trackers || {}).forEach(([id, incT]) => {
      const locT = trackers[id];
      if (!locT) { trackers[id] = incT; return; }
      const urges = _mergeEventList(locT.urges, incT.urges);
      const relapses = _mergeEventList(locT.relapses, incT.relapses);
      const addedAt = Math.min(locT.addedAt || Date.now(), incT.addedAt || Date.now());
      // The streak clock is derived, not a stored preference — recompute it
      // from the merged relapse timeline instead of arbitrarily picking one
      // device's clock over the other's.
      const streakStart = relapses.length ? Math.max(...relapses.map(r => r.ts)) : addedAt;
      const milestones = [...new Set([...(locT.milestones || []), ...(incT.milestones || [])])];
      const copingPlans = _mergeCopingPlans(locT.copingPlans, incT.copingPlans);
      trackers[id] = { addedAt, streakStart, urges, relapses, milestones, copingPlans, why: locT.why || incT.why || "" };
    });
    return { trackers };
  }

  function _mergeChallenges(localRaw, incomingRaw) {
    const local = _safeParse(localRaw, { active: null, history: [] });
    const incoming = _safeParse(incomingRaw, null);
    if (!incoming) return local;
    const seen = new Set();
    const history = [...(local.history || []), ...(incoming.history || [])].filter(h => {
      const key = `${h.id}:${h.endTs}`;
      if (seen.has(key)) return false;
      seen.add(key); return true;
    }).sort((a, b) => b.endTs - a.endTs);
    // Whichever device is "local" keeps its own in-progress challenge; the
    // other device's in-flight attempt isn't merged into "active" (there's
    // no clean way to run two at once), but its completed/abandoned history
    // above is, so nothing is silently thrown away.
    return { active: local.active, history };
  }

  function _mergeIdArray(localRaw, incomingRaw) {
    return [...new Set([..._safeParse(localRaw, []), ..._safeParse(incomingRaw, [])])];
  }

  function _mergeActiveDates(localRaw, incomingRaw) {
    return _mergeIdArray(localRaw, incomingRaw).sort().slice(-60);
  }

  function _mergeAchievements(localRaw, incomingRaw) {
    const local = _safeParse(localRaw, {});
    const incoming = _safeParse(incomingRaw, {});
    const out = { ...local };
    Object.entries(incoming).forEach(([id, ts]) => { if (!out[id] || ts < out[id]) out[id] = ts; });
    return out;
  }

  /* ── top-level merge: routes each zg_ key to its own rule ── */
  function merge(incomingData, storeSet) {
    const set = storeSet || ((k, v) => Store.set(k, v));
    const before = {
      habits: (_safeParse(localStorage.getItem("zg_habits"), { habits: [] }).habits || []).length,
      journal: _safeParse(localStorage.getItem("zg_journal"), []).length,
    };

    Object.keys(incomingData).forEach(key => {
      if (SKIP_KEYS.includes(key)) return;
      const localRaw = localStorage.getItem(key), incomingRaw = incomingData[key];

      if (key === "zg_habits")       { set(key, _mergeHabits(localRaw, incomingRaw)); return; }
      if (key === "zg_journal")      { set(key, _mergeJournal(localRaw, incomingRaw)); return; }
      if (key === "zg_reflections")  { set(key, _mergeReflections(localRaw, incomingRaw)); return; }
      if (key === "zg_vitals")       { set(key, _mergeVitals(localRaw, incomingRaw)); return; }
      if (key === "zg_context")      { set(key, _mergeContext(localRaw, incomingRaw)); return; }
      if (key === "zg_joined_date")  { set(key, _mergeEarliestDateStr(localRaw, incomingRaw)); return; }
      if (key === "zg_recovery")     { set(key, _mergeRecovery(localRaw, incomingRaw)); return; }
      if (key === "zg_challenges")   { set(key, _mergeChallenges(localRaw, incomingRaw)); return; }
      if (key === "zg_active_dates") { set(key, _mergeActiveDates(localRaw, incomingRaw)); return; }
      if (key === "zg_unlocked_skills") { set(key, _mergeIdArray(localRaw, incomingRaw)); return; }
      if (key === "zg_achievements") { set(key, _mergeAchievements(localRaw, incomingRaw)); return; }

      if (MAX_KEYS.includes(key)) {
        // Never a smaller number after a merge — worst case this slightly
        // over-counts decorative XP, never loses real recorded progress.
        set(key, Math.max(Number(localRaw || 0), Number(incomingRaw || 0)));
        return;
      }
      if (key === "zg_last_active_date") {
        if (!localRaw || (incomingRaw && new Date(incomingRaw) > new Date(localRaw))) localStorage.setItem(key, incomingRaw);
        return;
      }
      if (LOCAL_WINS_KEYS.includes(key)) {
        if (localRaw == null) localStorage.setItem(key, incomingRaw); // only fills a gap, never overwrites a device's own settings
        return;
      }
      // Anything else (forward-compat: a future key this version doesn't
      // know how to merge yet) — keep local if present, else take incoming.
      if (localRaw == null) localStorage.setItem(key, incomingRaw);
    });

    const after = {
      habits: (Store.get("zg_habits", { habits: [] }).habits || []).length,
      journal: Store.get("zg_journal", []).length,
    };
    return {
      habitsAdded: Math.max(0, after.habits - before.habits),
      journalAdded: Math.max(0, after.journal - before.journal),
    };
  }

  /* ── public API ── */
  async function generateCode() { return _encode(_collect()); }

  async function applyCode(code, mode) {
    const incoming = await _decode(code);
    const keys = Object.keys(incoming).filter(k => k.startsWith("zg_"));
    if (!keys.length) throw new Error("not a NASVOGrow sync code");
    if (mode === "replace") {
      Object.keys(localStorage).filter(k => k.startsWith("zg_")).forEach(k => localStorage.removeItem(k));
      keys.forEach(k => { if (!SKIP_KEYS.includes(k)) localStorage.setItem(k, incoming[k]); });
      return { replaced: true };
    }
    const filtered = {}; keys.forEach(k => { filtered[k] = incoming[k]; });
    return merge(filtered);
  }

  /* ── Settings UI ── */
  function _renderGetCodePanel() {
    const panel = document.getElementById("syncPanel");
    if (!panel) return;
    panel.innerHTML = `<p class="fine-print" style="margin-top:0">Generating…</p>`;
    generateCode().then(code => {
      const kb = Math.max(0.1, Math.round((code.length / 1024) * 10) / 10);
      panel.innerHTML = `
        <textarea id="syncCodeOutput" rows="4" readonly style="font-family:var(--font-mono);font-size:0.6875rem">${code}</textarea>
        <p class="fine-print">~${kb}KB. Not encrypted — send it the way you'd send anything else personal. Works for one transfer; paste it into "Enter a code" on the other device.</p>
        <div class="settings-actions">
          <button class="btn-primary" style="flex:1" id="syncCopyBtn">Copy code</button>
          ${navigator.share ? `<button class="btn-secondary" style="flex:1" id="syncShareBtn">Share…</button>` : ""}
        </div>`;
      document.getElementById("syncCopyBtn")?.addEventListener("click", async () => {
        try { await navigator.clipboard.writeText(code); ZG.toast("Copied — paste it on your other device"); }
        catch { ZG.toast("Couldn't copy — select the text above manually"); }
      });
      document.getElementById("syncShareBtn")?.addEventListener("click", async () => {
        try { await navigator.share({ title: "NASVOGrow sync code", text: code }); } catch {} // cancelled share isn't an error
      });
    }).catch(() => { panel.innerHTML = `<p class="fine-print" style="margin-top:0;color:var(--danger)">Couldn't generate a code on this device.</p>`; });
  }

  function _renderEnterCodePanel() {
    const panel = document.getElementById("syncPanel");
    if (!panel) return;
    panel.innerHTML = `
      <textarea id="syncCodeInput" rows="4" placeholder="Paste the code from your other device…" style="font-family:var(--font-mono);font-size:0.6875rem"></textarea>
      <div class="settings-actions">
        <button class="btn-primary" style="flex:1" id="syncApplyMergeBtn">Merge in (recommended)</button>
        <button class="btn-danger-ghost" style="flex:1" id="syncApplyReplaceBtn">Replace instead</button>
      </div>
      <p class="fine-print">Merge combines the code with what's already on this device — nothing here gets deleted. Replace wipes this device first, same as a full backup import.</p>`;
    document.getElementById("syncApplyMergeBtn")?.addEventListener("click", () => _apply("merge"));
    document.getElementById("syncApplyReplaceBtn")?.addEventListener("click", () => _apply("replace"));
  }

  async function _apply(mode) {
    const code = document.getElementById("syncCodeInput")?.value.trim();
    if (!code) { ZG.toast("Paste a code first"); return; }
    if (mode === "replace") {
      const ok = await ZG.confirm({ title: "Replace all data on this device?", body: "This can't be undone — export a backup first if you're not sure.", confirmLabel: "Replace", danger: true });
      if (!ok) return;
    }
    try {
      const result = await applyCode(code, mode);
      if (result.replaced) {
        ZG.toast("Data replaced — reloading…");
        setTimeout(() => location.reload(), 600);
      } else {
        ZG.toast(`Merged — ${result.habitsAdded} new habit${result.habitsAdded === 1 ? "" : "s"}, ${result.journalAdded} new journal entr${result.journalAdded === 1 ? "y" : "ies"}`);
        setTimeout(() => location.reload(), 900);
      }
    } catch {
      ZG.toast("That code didn't look right — check you copied all of it");
    }
  }

  document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("syncGetCodeBtn")?.addEventListener("click", _renderGetCodePanel);
    document.getElementById("syncEnterCodeBtn")?.addEventListener("click", _renderEnterCodePanel);
  });

  return { generateCode, applyCode, merge };
})();
window.Sync = Sync;
