"use strict";
/* ═══════════════════════════════════════════════════════════════
   VITALS — a short weekly pulse: craving strength, mood, energy.
   Everything else in Grow logs per-event (a habit check, a resisted
   urge, a journal line) — useful for spotting patterns, but it
   doesn't answer "am I actually getting better" without a lot of
   mental math. This is the missing baseline: three numbers, once a
   week, tracked as their own trend (see insights.js's weekly
   check-in trend panel) so progress reads as a line, not a feeling.

   Deliberately NOT diagnostic and NOT daily — three sliders, no
   free text required, once per (Monday-start) week, same rhythm as
   Journal's own weekly reflection. Entirely local, same as
   everything else here.
═══════════════════════════════════════════════════════════════ */
const Vitals = (() => {
  const KEY = "zg_vitals";
  let _editing = false;

  function load() { return Store.get(KEY, []); }
  function save(arr) { Store.set(KEY, arr); }

  function _weekStart(d = new Date()) {
    const dt = new Date(d); const day = (dt.getDay() + 6) % 7; // Monday=0, matches the rest of the app
    dt.setHours(0, 0, 0, 0); dt.setDate(dt.getDate() - day);
    return dt;
  }
  function _weekKey(d = new Date()) { return _weekStart(d).toDateString(); }

  function thisWeekEntry() { return load().find(v => v.weekKey === _weekKey()) || null; }

  function _clamp1to10(n, fallback) {
    const v = Number(n);
    return Number.isFinite(v) ? Math.max(1, Math.min(10, Math.round(v))) : fallback;
  }

  function saveEntry({ craving, mood, energy }) {
    const list = load();
    const wk = _weekKey();
    const existing = list.find(v => v.weekKey === wk);
    const entry = {
      craving: _clamp1to10(craving, 5),
      mood: _clamp1to10(mood, 5),
      energy: _clamp1to10(energy, 5),
      ts: Date.now(),
    };
    if (existing) {
      Object.assign(existing, entry);
      save(list);
      ZG.toast("Check-in updated");
      ZG.markActiveToday();
    } else {
      list.unshift({ weekKey: wk, ...entry });
      save(list.slice(0, 200));
      ZG.addXP(10, "Weekly check-in");
    }
    _editing = false;
    render();
  }

  function startEdit() { _editing = true; render(); }

  function _wire() {
    ["vCraving", "vMood", "vEnergy"].forEach(id => {
      const input = document.getElementById(id);
      const readout = document.getElementById(id + "Readout");
      input?.addEventListener("input", () => { if (readout) readout.textContent = input.value; });
    });
    document.getElementById("vitalsEditBtn")?.addEventListener("click", startEdit);
    document.getElementById("vitalsSaveBtn")?.addEventListener("click", () => {
      saveEntry({
        craving: document.getElementById("vCraving")?.value,
        mood: document.getElementById("vMood")?.value,
        energy: document.getElementById("vEnergy")?.value,
      });
    });
  }

  function render() {
    const body = document.getElementById("vitalsBody");
    if (!body) return;
    const entry = thisWeekEntry();

    if (entry && !_editing) {
      body.innerHTML = `
        <div class="card vitals-card">
          <div class="card-eyebrow">Weekly check-in</div>
          <div class="vitals-summary-row">
            <div class="vitals-summary-cell"><span class="vitals-summary-val">${entry.craving}</span><span class="vitals-summary-lbl">Craving strength</span></div>
            <div class="vitals-summary-cell"><span class="vitals-summary-val">${entry.mood}</span><span class="vitals-summary-lbl">Mood</span></div>
            <div class="vitals-summary-cell"><span class="vitals-summary-val">${entry.energy}</span><span class="vitals-summary-lbl">Energy</span></div>
          </div>
          <button class="btn-quiet" style="width:100%;margin-top:12px" id="vitalsEditBtn">Update this week's check-in</button>
        </div>`;
    } else {
      const c = entry?.craving ?? 5, m = entry?.mood ?? 5, e = entry?.energy ?? 5;
      body.innerHTML = `
        <div class="card vitals-card">
          <div class="card-eyebrow">Weekly check-in</div>
          <p class="fine-print" style="margin-top:-4px">Three quick numbers, once a week — a baseline reading, not a diagnosis.</p>
          <label class="field-label" style="margin-top:6px" for="vCraving">Craving strength this week overall — <span id="vCravingReadout">${c}</span>/10</label>
          <input type="range" id="vCraving" min="1" max="10" value="${c}"/>
          <label class="field-label" for="vMood">Mood this week — <span id="vMoodReadout">${m}</span>/10</label>
          <input type="range" id="vMood" min="1" max="10" value="${m}"/>
          <label class="field-label" for="vEnergy">Energy &amp; rest this week — <span id="vEnergyReadout">${e}</span>/10</label>
          <input type="range" id="vEnergy" min="1" max="10" value="${e}"/>
          <button class="btn-primary" style="width:100%;margin-top:12px" id="vitalsSaveBtn">${entry ? "Save changes" : "Save check-in (+10 XP)"}</button>
        </div>`;
    }
    _wire();
  }

  ZG.sectionRenderers.recovery = (() => {
    const prev = ZG.sectionRenderers.recovery;
    return () => { prev?.(); render(); };
  })();
  // Rendered on demand the first time Recovery is opened, not on every page
  // load — see the matching note in journal.js.

  return { load, save, saveEntry, thisWeekEntry, startEdit, render };
})();
window.Vitals = Vitals;
