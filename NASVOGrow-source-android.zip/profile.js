"use strict";
/* ═══════════════════════════════════════════════════════════════
   PROFILE — who this app is for, made a little more visible.

   Everything here follows the same local-only rules as the rest of
   Grow: no accounts, nothing uploaded. The one thing worth flagging
   specifically is the avatar — a photo is meaningfully bigger than
   anything else this app stores, so it's resized and compressed to a
   small square on-device (via canvas) before it ever touches
   localStorage, and it travels through sync.js the same "fills a gap,
   never overwrites" way as name/theme/other personal settings (see
   sync.js's LOCAL_WINS_KEYS) rather than being force-pushed between
   devices.

   Four fields, deliberately different from each other:
     • Name       — used in the Home greeting, same as before.
     • Username   — a small "@handle" shown under the greeting and on
       the printable summary. Purely cosmetic; there's no account for
       it to identify.
     • Motto      — a personal line that, once set, replaces the
       rotating daily quote on Home. Shown on the printable summary
       too, since it's meant to be seen.
     • Why        — the one field that's explicitly private: a
       reminder for the person alone, never surfaced anywhere else in
       the app (not even the printable export).
═══════════════════════════════════════════════════════════════ */
const Profile = (() => {
  const AVATAR_SIZE = 160;              // stored square, px
  const AVATAR_MAX_BYTES = 220 * 1024;  // sanity ceiling on the data URL itself

  function getName() { return Store.get("zg_name", ""); }
  function setName(v) { Store.set("zg_name", (v || "").trim().slice(0, 30)); }

  function getUsername() { return Store.get("zg_username", ""); }
  function setUsername(v) {
    const u = (v || "").trim().replace(/^@+/, "").replace(/\s+/g, "").slice(0, 24);
    Store.set("zg_username", u);
  }

  function getMotto() { return Store.get("zg_motto", ""); }
  function setMotto(v) { Store.set("zg_motto", (v || "").trim().slice(0, 140)); }

  function getBio() { return Store.get("zg_bio", ""); }
  function setBio(v) { Store.set("zg_bio", (v || "").trim().slice(0, 240)); }

  function getAvatar() { return Store.get("zg_avatar", ""); }
  function setAvatar(dataUrl) { Store.set("zg_avatar", dataUrl || ""); }
  function removeAvatar() { Store.set("zg_avatar", ""); }

  /** First-ever call stamps today; existing users get back-filled with the
   *  earliest date already on record (zg_active_dates, capped at ~60 days)
   *  rather than being credited with starting "today" if they've actually
   *  been here for weeks. */
  function joinedDate() {
    let d = Store.get("zg_joined_date", null);
    if (d) return d;
    const active = Store.get("zg_active_dates", []);
    d = (active.length ? active.slice().sort()[0] : null) || new Date().toDateString();
    Store.set("zg_joined_date", d);
    return d;
  }

  function _fileToAvatarDataUrl(file) {
    return new Promise((resolve, reject) => {
      if (!file.type || !file.type.startsWith("image/")) { reject(new Error("not_image")); return; }
      const reader = new FileReader();
      reader.onload = () => {
        const img = new Image();
        img.onload = () => {
          const size = AVATAR_SIZE;
          const canvas = document.createElement("canvas");
          canvas.width = size; canvas.height = size;
          const ctx = canvas.getContext("2d");
          const side = Math.min(img.width, img.height);
          const sx = (img.width - side) / 2, sy = (img.height - side) / 2;
          ctx.drawImage(img, sx, sy, side, side, 0, 0, size, size);
          let quality = 0.86;
          let dataUrl = canvas.toDataURL("image/jpeg", quality);
          while (dataUrl.length > AVATAR_MAX_BYTES && quality > 0.4) {
            quality -= 0.1;
            dataUrl = canvas.toDataURL("image/jpeg", quality);
          }
          resolve(dataUrl);
        };
        img.onerror = () => reject(new Error("bad_image"));
        img.src = reader.result;
      };
      reader.onerror = () => reject(new Error("read_failed"));
      reader.readAsDataURL(file);
    });
  }

  function initial() {
    const n = getName() || getUsername();
    return n ? n.trim()[0].toUpperCase() : "";
  }

  /** Paints whichever <span class="avatar" id="..."> is on screen right
   *  now — photo if one's set, otherwise a colored initial, otherwise a
   *  quiet default icon. Never replaces the element itself, just its
   *  contents, so callers can size it purely with CSS (.avatar / .avatar.lg). */
  function _paintAvatar(id) {
    const el = document.getElementById(id);
    if (!el) return;
    const url = getAvatar();
    if (url) { el.classList.remove("avatar-fallback"); el.innerHTML = `<img src="${url}" alt=""/>`; return; }
    el.classList.add("avatar-fallback");
    const ch = initial();
    el.innerHTML = ch ? ZG.esc(ch) : (window.Icons?.svg("growth") || "");
  }

  function render() {
    ["heroAvatar", "settingsAvatarPreview", "profileAvatarPreview"].forEach(_paintAvatar);

    const nameEl = document.getElementById("settingsProfileName");
    if (nameEl) nameEl.textContent = getName() || (window.ZG?.t ? ZG.t("add_your_name") : "Add your name");

    const uEl = document.getElementById("heroUsername");
    if (uEl) {
      const u = getUsername();
      uEl.textContent = u ? "@" + u : "";
      uEl.hidden = !u;
    }
  }

  function openModal() {
    const nameInput = document.getElementById("profileNameInput");
    const userInput = document.getElementById("profileUsernameInput");
    const mottoInput = document.getElementById("profileMottoInput");
    const bioInput = document.getElementById("profileBioInput");
    if (nameInput) nameInput.value = getName();
    if (userInput) userInput.value = getUsername();
    if (mottoInput) mottoInput.value = getMotto();
    if (bioInput) bioInput.value = getBio();
    _paintAvatar("profileAvatarPreview");

    const note = document.getElementById("profileJoinedNote");
    if (note) {
      const d = new Date(joinedDate());
      const label = d.toLocaleDateString(window.I18N?.getLang?.() || "en", { month: "long", year: "numeric" });
      note.textContent = ZG.t ? ZG.t("building_since", { date: label }) : `Building since ${label}.`;
    }
    ZG.openModal("profileModal");
  }

  async function handleAvatarFile(file) {
    if (!file) return;
    try {
      const dataUrl = await _fileToAvatarDataUrl(file);
      setAvatar(dataUrl);
      render();
      ZG.toast("Photo updated");
    } catch (e) {
      const msg = e.message === "not_image" ? "That doesn't look like an image" : "Couldn't read that photo";
      ZG.toast(msg);
    }
  }

  function clearAvatar() {
    removeAvatar();
    render();
    ZG.toast("Photo removed");
  }

  function save() {
    setName(document.getElementById("profileNameInput")?.value);
    setUsername(document.getElementById("profileUsernameInput")?.value);
    setMotto(document.getElementById("profileMottoInput")?.value);
    setBio(document.getElementById("profileBioInput")?.value);
    render();
    ZG.refreshChrome();
    ZG.closeModal("profileModal");
    ZG.toast("Profile saved");
  }

  document.addEventListener("DOMContentLoaded", () => {
    joinedDate(); // stamp once; no-op every load after
    render();
    document.getElementById("openProfileBtn")?.addEventListener("click", () => {
      // Settings is already open when this is tapped — close it first so
      // Profile doesn't stack on top of it (both are .modal.drawer at the
      // same fixed position). The Home avatar's own button never has this
      // problem since nothing else is open when it's tapped.
      ZG.closeModal("settingsModal");
      openModal();
    });
    document.getElementById("heroProfileBtn")?.addEventListener("click", openModal);
    document.getElementById("avatarUploadBtn")?.addEventListener("click", () => document.getElementById("avatarFileInput")?.click());
    document.getElementById("avatarFileInput")?.addEventListener("change", e => {
      handleAvatarFile(e.target.files?.[0]);
      e.target.value = "";
    });
    document.getElementById("avatarRemoveBtn")?.addEventListener("click", clearAvatar);
    document.getElementById("profileSaveBtn")?.addEventListener("click", save);
  });

  return {
    getName, setName, getUsername, setUsername, getMotto, setMotto, getBio, setBio,
    getAvatar, setAvatar, removeAvatar, joinedDate, render, openModal,
  };
})();
window.Profile = Profile;
