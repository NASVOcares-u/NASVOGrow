"use strict";
/* ═══════════════════════════════════════════════════════════════
   RECOVERY EXPECTATION TIMELINES — community-editable content, split
   out of recovery.js on purpose (see CONTRIBUTING.md). One entry per
   tracker category (matching recovery.js's TYPES ids), each a short
   list of { when, text } describing what's commonly reported at that
   point — general patterns, never a prediction for a specific person,
   and never a substitute for the medical notes on the tracker types
   themselves (needsNote/resource in recovery.js's own TYPES table,
   which stays there since those are safety-reviewed, not open content).

   A contributor refining or extending one of these timelines only
   ever touches this file — no application logic lives here. New
   category keys must match an id already defined in recovery.js's
   TYPES table (see scripts/validate-content.js).

   Works in two environments without a build step:
     • the browser, where it attaches itself to window.RecoveryExpectations
       (loaded before recovery.js — see index.html)
     • Node, for scripts/validate-content.js and its tests, via
       module.exports
═══════════════════════════════════════════════════════════════ */
const RecoveryExpectations = {
    pornography: [
      { when: "First few days", text: "Urges can spike as old cues (boredom, being alone, certain times of day) show up without the usual response. That's the habit loop adjusting, not a sign anything's wrong." },
      { when: "1–2 weeks", text: "Mood can dip for some people around here — often described as a flatness before things start feeling normal again." },
      { when: "3–4+ weeks", text: "Many people report cravings becoming less frequent and less intense, though a bad day can still happen — that's normal, not a setback." },
    ],
    social_media: [
      { when: "First few days", text: "Reaching for your phone out of habit, even mid-task, is normal. The urge is usually about the reflex itself, not really needing to check anything." },
      { when: "1–2 weeks", text: "Boredom can feel more intense for a bit while your brain recalibrates to slower-paced stimulation." },
      { when: "3+ weeks", text: "Many people report better focus and less \u201Cphantom check\u201D reaching by this point." },
    ],
    gaming: [
      { when: "First few days", text: "Downtime can feel unusually restless — gaming is often the thing that filled every spare minute, so that gap is the hardest part early on." },
      { when: "1–2 weeks", text: "Sleep often improves once late sessions stop, even before it feels that way day to day." },
      { when: "3+ weeks", text: "Other activities typically start feeling less flat and more engaging again as sensitivity resets." },
    ],
    caffeine: [
      { when: "Day 1–3", text: "Headaches, fatigue, and irritability are common and usually peak around day 2–3 — this is why tapering is often easier than stopping cold." },
      { when: "Day 4–9", text: "Withdrawal symptoms typically fade for most people within about a week." },
      { when: "2+ weeks", text: "Energy levels usually normalize without caffeine, though it can take a few weeks to feel fully adjusted." },
    ],
    nicotine: [
      { when: "Day 1–3", text: "Physical withdrawal (irritability, restlessness, cravings) usually peaks in the first 72 hours as nicotine clears your system." },
      { when: "Week 1–2", text: "Cravings become less frequent, though they can still hit hard and fast for a few seconds at a time — that's normal, and it passes." },
      { when: "1+ month", text: "Most people report the physical pull fading substantially by here, even if habitual triggers (coffee, driving, stress) still prompt a thought." },
    ],
    alcohol: [
      { when: "First 72 hours", text: "This is the period doctors watch most closely for heavy drinkers — see the note above about medical supervision." },
      { when: "1–2 weeks", text: "Sleep and mood are commonly disrupted for a couple of weeks before starting to settle." },
      { when: "1+ month", text: "Many people report noticeably better sleep and steadier mood by this point." },
    ],
    binge_eating: [
      { when: "Early on", text: "Urges to binge often cluster around specific emotional states (stress, loneliness, boredom) more than around hunger itself — HALT check-ins can help make that visible." },
      { when: "Ongoing", text: "This isn't a countdown to a finish line the way abstinence-based recovery is — progress here usually looks like fewer, less intense episodes over time, not zero forever." },
    ],
    cannabis: [
      { when: "Days 1–10", text: "Irritability, sleep trouble, and vivid dreams are common and usually strongest in the first week or so." },
      { when: "2–4 weeks", text: "Sleep and appetite typically start normalizing, though it varies a lot by how regularly and how long someone used." },
    ],
    gambling: [
      { when: "First few days", text: "Thoughts about gambling, or \u201Cwhat if I'd won,\u201D can be intrusive at first — this tends to ease with distance, not with willpower alone." },
      { when: "2+ weeks", text: "The urge to check or chase a loss usually loses intensity as new routines take its place." },
    ],
    shopping: [
      { when: "First week", text: "The urge to browse or buy \u201Cjust to look\u201D is often strongest right after a stressful moment — noticing that link is most of the work early on." },
    ],
    sugar: [
      { when: "Days 1–5", text: "Cravings and mild irritability are common as taste sensitivity resets — this passes for most people within about a week." },
      { when: "1–2 weeks", text: "Many people notice steadier energy and less intense sugar cravings by here." },
    ],
  };

if (typeof window !== "undefined") window.RecoveryExpectations = RecoveryExpectations;
if (typeof module !== "undefined" && module.exports) module.exports = RecoveryExpectations;
