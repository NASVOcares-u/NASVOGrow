"use strict";
/* ═══════════════════════════════════════════════════════════════
   CHALLENGE DEFINITIONS — community-editable content, split out of
   challenges.js on purpose (see CONTRIBUTING.md). A contributor
   proposing a new challenge, or adjusting the wording/XP/length of
   an existing one, only ever needs to touch this file — no
   application logic lives here, so a content PR is trivial to
   review and can't accidentally change how challenges are tracked
   or awarded.

   Shape of one entry (see scripts/validate-content.js for the
   enforced version of this):
     id          — must match its own object key, snake_case
     name        — shown as the challenge's title
     icon        — one of icons.js's PATHS keys (see icons.js)
     tagline     — one short line, shown on the challenge card
     description — one or two sentences, shown when active
     days        — length of the challenge window
     xp          — reward on completion
     target      — (optional) a count goal, for challenges tracked
                   by "do the thing N times" rather than daily presence
     colorVar    — one of the app's existing CSS color tokens
                   (--gold, --accent, --clay, --danger)
     failOn      — (optional) array of event kinds that END the
                   challenge outright rather than just failing to
                   advance it (see challenges.js's notify())

   Works in two environments without a build step:
     • the browser, where it attaches itself to window.ChallengeDefs
       (loaded before challenges.js — see index.html)
     • Node, for scripts/validate-content.js and its tests, via
       module.exports
═══════════════════════════════════════════════════════════════ */
const ChallengeDefs = {
    consistency_reset: {
      id: "consistency_reset", name: "7-Day Consistency Reset", icon: "flame",
      tagline: "Do one identity action, every day, for 7 days.",
      description: "A habit check-off, a journal line, or a recovery check-in — any one counts. Miss a day and the streak for this challenge resets.",
      days: 7, xp: 250, colorVar: "--gold",
    },
    habit_stack: {
      id: "habit_stack", name: "Habit Stack Marathon", icon: "check",
      tagline: "Log 15 total habit check-offs within 5 days.",
      description: "Doesn't matter which habits or how they're spread — just get to 15 completions before the window closes.",
      days: 5, xp: 200, target: 15, colorVar: "--accent",
    },
    deep_reflection: {
      id: "deep_reflection", name: "Deep Reflection Week", icon: "book",
      tagline: "Write 5 journal entries in 7 days.",
      description: "Real entries, not one-liners you don't mean. Notice what repeats.",
      days: 7, xp: 220, target: 5, colorVar: "--clay",
    },
    perfect_days: {
      id: "perfect_days", name: "3 Perfect Days", icon: "star",
      tagline: "Clear every habit on your list, on any 3 days within a week.",
      description: "Doesn't need to be 3 days in a row — just 3 full-clear days inside the window.",
      days: 7, xp: 240, target: 3, colorVar: "--gold",
    },
    urge_surf_wave: {
      id: "urge_surf_wave", name: "5-Wave Ride", icon: "breath",
      tagline: "Ride out 5 urge-surfing sessions in 10 days.",
      description: "Whether you resist afterward or not, using the timer counts — this is about building the pause, not the outcome.",
      days: 10, xp: 260, target: 5, colorVar: "--clay",
    },
    plan_ahead: {
      id: "plan_ahead", name: "Plan For It", icon: "compass",
      tagline: "Write 2 coping plans within 5 days.",
      description: "A plan made now, thinking clearly, is easier to follow than one improvised mid-urge.",
      days: 5, xp: 150, target: 2, colorVar: "--accent",
    },
    clean_streak_5: {
      id: "clean_streak_5", name: "5 Clean Days", icon: "shield",
      tagline: "5 days with no logged reset, across any tracker.",
      description: "Any habit, journal, or resisted-urge action keeps this moving — one logged reset starts it over.",
      days: 5, xp: 220, colorVar: "--danger",
      failOn: ["relapse"], // a reset doesn't just fail to advance this one — it ends it
    },
  };

if (typeof window !== "undefined") window.ChallengeDefs = ChallengeDefs;
if (typeof module !== "undefined" && module.exports) module.exports = ChallengeDefs;
