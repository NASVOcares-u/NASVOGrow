"use strict";
/* ═══════════════════════════════════════════════════════════════
   RECOVERY "LEARN" TOPICS — community-editable content, split out of
   recovery.js on purpose (see CONTRIBUTING.md). A handful of short,
   plain-language explanations of the mechanism behind recovery/habit
   change, shared once across every active tracker rather than
   repeated per category. Each entry is { title, text } — keep text to
   a short paragraph; this is meant to stay legible, not become a
   reading app (see recovery.js's own Learn panel).

   Works in two environments without a build step:
     • the browser, where it attaches itself to window.RecoveryLearnTopics
       (loaded before recovery.js — see index.html)
     • Node, for scripts/validate-content.js and its tests, via
       module.exports
═══════════════════════════════════════════════════════════════ */
const RecoveryLearnTopics = [
    { title: "Why this feels so hard to just stop", text: "Compulsive behaviors work by hijacking a normal system: dopamine doesn't just reward pleasure, it drives wanting and anticipation. Unpredictable rewards — a notification, a win, a like — release more dopamine than predictable ones, which is part of why hard-to-predict things are often the hardest to put down." },
    { title: "Tolerance and baseline", text: "Repeated high-dopamine spikes can push your baseline down, so ordinary things — a conversation, a walk, finishing a task — start to feel flatter by comparison. That flatness usually isn't permanent; it tends to recover with time away from the spike, which is what the \u201Cwhat's common, roughly\u201D timelines above are describing." },
    { title: "Why tapering sometimes beats stopping cold", text: "For some categories — caffeine, nicotine, alcohol especially — a gradual taper reduces withdrawal severity and is often more sustainable than an abrupt stop. For others, an immediate stop plus a concrete plan tends to work better. Neither is a universal rule — see the note on your specific tracker above." },
    { title: "A slip isn't proof it's not working", text: "Research on habit and recovery consistently finds that a slip is part of the normal process for most people, not a sign of failure — what predicts long-term success is getting back to it quickly, not never slipping at all." },
  ];

if (typeof window !== "undefined") window.RecoveryLearnTopics = RecoveryLearnTopics;
if (typeof module !== "undefined" && module.exports) module.exports = RecoveryLearnTopics;
