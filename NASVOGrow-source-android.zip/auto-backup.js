"use strict";
/* ═══════════════════════════════════════════════════════════════
   AUTO-BACKUP — a silent, user-chosen local backup folder, built on
   Chromium's File System Access API. Addresses the real #1 data-loss
   risk this app has always had: everything lives only in browser
   storage (see privacy.html), and browsers are allowed to evict that
   storage under disk pressure — app.js already best-effort-asks the
   browser not to via navigator.storage.persist(), but "best effort"
   isn't a guarantee. The existing manual export (see export.js/
   app.js's _exportData) is the only real safety net today, and it
   only works if someone remembers to use it.

   This is the same shape of feature, made automatic: the person picks
   a real folder on their own device ONCE (a native OS folder picker —
   nothing about this touches a server, same standing rule as every
   other feature here), and from then on a fresh portable-format
   backup (see portable-export.js) is written there automatically, with
   old backups pruned so it can't quietly fill their disk.

   Browser support is real but partial: this is a Chromium-only API
   (Chrome, Edge, Opera, and Chromium-based browsers) — Firefox and
   Safari don't implement it. isSupported() is checked before showing
   any of this in Settings, and everything here fails closed (returns
   a reason, never throws past its own boundary) when the API, a
   granted folder, or permission isn't available. This is a strict
   ADDITION to manual export, never a replacement — the "Full backup"/
   "Portable backup" buttons in Settings keep working exactly as they
   do today regardless of whether auto-backup is set up.

   A folder handle itself can't be stored in localStorage (it isn't
   JSON-serializable) — it's kept in IndexedDB instead, which supports
   storing these handles directly. Everything ELSE about this feature
   (enabled flag, last-backup timestamp) stays in the same zg_*
   localStorage keys as everything else, so it round-trips through the
   existing backup/restore and Sync machinery like any other setting.
═══════════════════════════════════════════════════════════════ */
const AutoBackup = (() => {
  const DB_NAME = "zg_autobackup_db";
  const DB_VERSION = 1;
  const STORE = "handles";
  const HANDLE_KEY = "backup_dir";
  const ENABLED_KEY = "zg_autobackup_enabled";
  const LAST_TS_KEY = "zg_last_autobackup_ts";
  const MAX_KEPT_BACKUPS = 14; // roughly two weeks of daily backups before pruning the oldest

  const _native = () => !!window.NativeBridge?.isNative?.();

  function isSupported() {
    if (_native()) return NativeBridge.canBackupToDocuments();   // Android app: Documents/NASVOGrow via the native plugin
    return typeof window !== "undefined" && "showDirectoryPicker" in window && typeof indexedDB !== "undefined";
  }

  function _openDb() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => { if (!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE); };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async function _idbGet(key) {
    const db = await _openDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, "readonly");
      const req = tx.objectStore(STORE).get(key);
      req.onsuccess = () => resolve(req.result ?? null);
      req.onerror = () => reject(req.error);
    });
  }

  async function _idbSet(key, value) {
    const db = await _openDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, "readwrite");
      tx.objectStore(STORE).put(value, key);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  async function _idbDelete(key) {
    const db = await _openDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, "readwrite");
      tx.objectStore(STORE).delete(key);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  function isEnabled() { return Store.get(ENABLED_KEY, false); }
  function lastBackupTs() { return Store.get(LAST_TS_KEY, null); }

  /** Opens the OS folder picker (must be called from a real user
   *  gesture — a click handler — same rule as any browser permission
   *  prompt) and remembers the chosen folder for next time. */
  async function chooseFolder() {
    if (!isSupported()) throw new Error("File System Access isn't available in this browser.");
    if (_native()) {                                   // no folder to pick: turn on, then prove it works with a real write
      Store.set(ENABLED_KEY, true);
      const r = await writeBackupNow();
      if (!r.ok) { Store.set(ENABLED_KEY, false); throw new Error(r.message || r.reason || "write failed"); }
      return true;
    }
    const handle = await window.showDirectoryPicker({ mode: "readwrite" });
    await _idbSet(HANDLE_KEY, handle);
    Store.set(ENABLED_KEY, true);
    return handle;
  }

  async function disable() {
    Store.set(ENABLED_KEY, false);
    Store.set(LAST_TS_KEY, null);
    try { await _idbDelete(HANDLE_KEY); } catch {}
  }

  async function _getHandle() {
    try { return await _idbGet(HANDLE_KEY); } catch { return null; }
  }

  /** True once permission is actually confirmed for this session — a
   *  granted folder handle can still need re-confirmation after the
   *  browser restarts, which is why this is checked before every
   *  write rather than trusted from setup time. requestPermission()
   *  only works from a user gesture in real browsers; called here so
   *  the very click that triggers a backup can also silently re-grant
   *  it when needed, without a separate prompt first. */
  async function hasPermission(handle) {
    if (!handle || typeof handle.queryPermission !== "function") return false;
    const opts = { mode: "readwrite" };
    if ((await handle.queryPermission(opts)) === "granted") return true;
    try { return (await handle.requestPermission(opts)) === "granted"; } catch { return false; }
  }

  function _backupFilename(date = new Date()) {
    return `nasvo-grow-autobackup-${date.toISOString().slice(0, 10)}.json`;
  }

  const _BACKUP_FILENAME_RE = /^nasvo-grow-autobackup-(\d{4}-\d{2}-\d{2})\.json$/;

  /** Pure decision logic, deliberately separate from the actual
   *  filesystem calls below: given a list of existing filenames in the
   *  backup folder, returns which ones should be deleted to stay under
   *  MAX_KEPT_BACKUPS — oldest first, ties broken by filename. This is
   *  the part worth unit testing directly; walking a real
   *  FileSystemDirectoryHandle isn't something Node can do. */
  function filesToPrune(existingNames, keep = MAX_KEPT_BACKUPS) {
    const ours = existingNames.filter(n => _BACKUP_FILENAME_RE.test(n)).sort(); // ISO dates sort correctly as strings
    return ours.slice(0, Math.max(0, ours.length - keep));
  }

  async function _pruneOldBackups(handle) {
    const names = [];
    for await (const [name, entry] of handle.entries()) {
      if (entry.kind === "file") names.push(name);
    }
    for (const name of filesToPrune(names)) {
      try { await handle.removeEntry(name); } catch {}
    }
  }

  /** The actual write — building the SAME portable export format the
   *  manual "Portable backup" export button produces (see
   *  portable-export.js), so a folder full of these is restorable the
   *  exact same way. Fails closed with a reason string rather than
   *  throwing, so a caller can decide how (or whether) to surface it —
   *  this runs silently in the background most of the time and
   *  shouldn't interrupt anyone with an error toast for something as
   *  routine as a stale permission. */
  async function _writeBackupNative() {
    if (!window.PortableExport) return { ok: false, reason: "no-export" };
    const filename = _backupFilename();
    const r = await NativeBridge.saveBackup(filename, JSON.stringify(window.PortableExport.build(), null, 2));
    if (!r.ok) return { ok: false, reason: "write-failed", message: r.message };
    Store.set(LAST_TS_KEY, Date.now());
    await NativeBridge.pruneBackups("nasvo-grow-autobackup-", MAX_KEPT_BACKUPS);
    return { ok: true, filename };
  }

  async function writeBackupNow() {
    if (!isSupported()) return { ok: false, reason: "unsupported" };
    if (!isEnabled()) return { ok: false, reason: "disabled" };
    if (_native()) return _writeBackupNative();
    const handle = await _getHandle();
    if (!handle) return { ok: false, reason: "no-folder" };
    if (!(await hasPermission(handle))) return { ok: false, reason: "no-permission" };
    if (!window.PortableExport) return { ok: false, reason: "no-export" };

    const filename = _backupFilename();
    try {
      const fileHandle = await handle.getFileHandle(filename, { create: true });
      const writable = await fileHandle.createWritable();
      await writable.write(JSON.stringify(window.PortableExport.build(), null, 2));
      await writable.close();
      Store.set(LAST_TS_KEY, Date.now());
      try { await _pruneOldBackups(handle); } catch {} // pruning failure shouldn't fail the backup that just succeeded
      return { ok: true, filename };
    } catch (err) {
      return { ok: false, reason: "write-failed", message: err?.message };
    }
  }

  /** Once-per-day, best-effort — mirrors the cadence of the existing
   *  backup nudge (see app.js's _maybeNudgeBackup) rather than writing
   *  on every single change, which would be needless disk churn for
   *  data this small. */
  async function maybeRunDailyBackup() {
    if (!isEnabled()) return;
    const last = lastBackupTs();
    if (last && Date.now() - last < 20 * 3600000) return; // ~once/day, same spirit as the 20hr floor elsewhere
    await writeBackupNow();
  }

  /* ── Settings UI ── */
  function renderSettingsBlock() {
    const el = document.getElementById("autoBackupSection");
    if (!el) return;

    if (!isSupported()) {
      el.innerHTML = `
        <label class="field-label" style="margin-top:0">Automatic local backup</label>
        <p class="fine-print" style="margin-top:-4px">Not available in this browser — this needs a Chromium-based browser (Chrome, Edge). Manual export above always works everywhere.</p>`;
      return;
    }

    if (!isEnabled()) {
      el.innerHTML = `
        <label class="field-label" style="margin-top:0">Automatic local backup</label>
        <p class="fine-print" style="margin-top:-4px">${_native()
          ? "Saves a fresh backup to Documents/NASVOGrow on this phone about once a day. The files stay on your phone, and they are still there if you uninstall the app. Nothing is sent anywhere."
          : "Pick a folder on this device once, and a fresh backup writes there automatically — no need to remember. Nothing leaves your device; same no-server rule as everything else here."}</p>
        <button class="btn-secondary" style="width:100%" id="autoBackupChooseBtn">${_native() ? "Turn on automatic backup" : "Choose a backup folder"}</button>`;
      document.getElementById("autoBackupChooseBtn")?.addEventListener("click", async () => {
        try {
          await chooseFolder();
          ZG.toast("Backup folder set");
          await writeBackupNow();
          renderSettingsBlock();
        } catch (err) {
          if (err?.name !== "AbortError") ZG.toast(_native() ? "Couldn't save to Documents on this phone — use the Full or Portable backup buttons above instead" : "Couldn't set that folder — try again");
        }
      });
      return;
    }

    const ts = lastBackupTs();
    const statusLine = ts
      ? `Last auto-backup: ${Math.floor((Date.now() - ts) / 86400000) === 0 ? "today" : `${Math.floor((Date.now() - ts) / 86400000)} day${Math.floor((Date.now() - ts) / 86400000) === 1 ? "" : "s"} ago`}.`
      : "Folder set — first backup runs shortly.";
    el.innerHTML = `
      <label class="field-label" style="margin-top:0">Automatic local backup</label>
      <p class="fine-print" style="margin-top:-4px">${ZG.esc(statusLine)} Old backups are pruned automatically, keeping the most recent ${MAX_KEPT_BACKUPS}.</p>
      <div class="settings-actions">
        <button class="btn-secondary" style="flex:1" id="autoBackupNowBtn">Back up now</button>
        <button class="btn-danger-ghost" style="flex:1" id="autoBackupOffBtn">Turn off</button>
      </div>`;
    document.getElementById("autoBackupNowBtn")?.addEventListener("click", async () => {
      const result = await writeBackupNow();
      ZG.toast(result.ok ? "Backed up" : "Couldn't back up right now — check the folder still allows access");
      renderSettingsBlock();
      ZG.renderBackupNote?.();
    });
    document.getElementById("autoBackupOffBtn")?.addEventListener("click", async () => {
      await disable();
      ZG.toast("Automatic backup turned off");
      renderSettingsBlock();
      ZG.renderBackupNote?.();
    });
  }

  return {
    isSupported, isEnabled, lastBackupTs, chooseFolder, disable,
    hasPermission, writeBackupNow, maybeRunDailyBackup, filesToPrune, renderSettingsBlock,
  };
})();
window.AutoBackup = AutoBackup;
