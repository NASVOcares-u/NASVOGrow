"use strict";
/* ═══════════════════════════════════════════════════════════════
   GROWTH — skill tree (XP-gated perks), achievements, streak canvas.
   XP here comes only from Grow's own actions (habits, journal,
   recovery, challenges) — nothing timer/session dependent.

   Icon language: one icon per *branch*, reused across its three
   nodes. Distinguishing three sequential unlocks with three
   different pictures adds noise, not clarity — the ring fill and
   lock state already show progression.
═══════════════════════════════════════════════════════════════ */

/* ── Skill tree definitions ── */
const BRANCHES = {
  discipline:  { label: "Discipline",  icon: "check", colorVar: "--clay",   nodes: [
    { id: "foothold",     xp: 50,   icon: "check", name: "Foothold",      perk: "+1 XP on every habit check-off", desc: "You've started proving it to yourself." },
    { id: "steady_hands", xp: 300,  icon: "check", name: "Steady Hands",  perk: "One bad day no longer feels like failure", desc: "You've absorbed a setback and kept going." },
    { id: "iron_root",    xp: 900,  icon: "check", name: "Iron Root",     perk: "+3 more XP on every habit check-off", desc: "This isn't willpower anymore. It's structure." },
  ]},
  consistency: { label: "Consistency", icon: "flame", colorVar: "--accent", nodes: [
    { id: "first_roots",  xp: 100,  icon: "flame", name: "First Roots",   perk: "Streak becomes visible everywhere", desc: "The pattern is real, not imagined." },
    { id: "deep_roots",   xp: 500,  icon: "flame", name: "Deep Roots",    perk: "Weekly rhythm ring glows at goal", desc: "Showing up stopped being a question." },
    { id: "evergreen",    xp: 1500, icon: "flame", name: "Evergreen",     perk: "Identity tier: Legend status", desc: "Consistency is now just who you are." },
  ]},
  reflection:  { label: "Reflection",  icon: "book", colorVar: "--gold",   nodes: [
    { id: "noticing",     xp: 75,   icon: "book", name: "Noticing",      perk: "You start catching patterns as they happen", desc: "Awareness is the first real lever." },
    { id: "clarity",      xp: 400,  icon: "book", name: "Clarity",       perk: "Deeper weekly reflection prompts unlock", desc: "You know what actually moves you now." },
    { id: "wisdom",       xp: 1200, icon: "book", name: "Wisdom",        perk: "Your own journal becomes a reference", desc: "You've written enough to trust yourself." },
  ]},
  recovery:    { label: "Recovery",    icon: "shield", colorVar: "--danger", nodes: [
    { id: "first_stand",   xp: 60,   icon: "shield", name: "First Stand",   perk: "Recovery milestones surface on Home", desc: "You stood somewhere you used to fall." },
    { id: "steady_ground", xp: 350,  icon: "shield", name: "Steady Ground", perk: "Urge-resist streaks tracked separately", desc: "Resisting is starting to feel normal." },
    { id: "unshakeable",   xp: 1000, icon: "shield", name: "Unshakeable",   perk: "Nothing has this much power over you now", desc: "You've out-lasted the thing that used to run you." },
  ]},
};
const ALL_NODES = Object.values(BRANCHES).flatMap(b => b.nodes.map(n => ({ ...n, branch: b.label, colorVar: b.colorVar })));
ZG.SKILL_NODES = ALL_NODES;

/* ── Achievements — grouped visually by icon, not one-off per badge ── */
ZG.ACHIEVEMENTS = [
  { id: "first_habit",     label: "First habit completed",      icon: "check", check: () => (window.Habits?.totalCompletions?.() ?? 0) >= 1 },
  { id: "habit_streak_7",  label: "A 7-day streak on a habit",   icon: "check", check: () => (window.Habits?.load?.().habits || []).some(h => window.Habits.streakFor(h.id) >= 7) },
  { id: "first_journal",   label: "Wrote your first entry",      icon: "book", check: () => (window.Journal?.totalEntries?.() ?? 0) >= 1 },
  { id: "journal_10",      label: "10 journal entries",          icon: "book", check: () => (window.Journal?.totalEntries?.() ?? 0) >= 10 },
  { id: "first_recovery",  label: "Started a recovery tracker",  icon: "shield", check: () => (window.Recovery?.trackerCount?.() ?? 0) >= 1 },
  { id: "recovery_day1",   label: "24 hours clean on any track", icon: "shield", check: () => (window.Recovery?.bestCurrentDays?.() ?? 0) >= 1 },
  { id: "first_challenge", label: "Completed a challenge",       icon: "flag", check: () => (window.Challenges?.completedCount?.() ?? 0) >= 1 },
  { id: "streak_7",        label: "7-day overall streak",        icon: "flame", check: () => ZG.getStreak() >= 7 },
  { id: "streak_30",       label: "30-day overall streak",       icon: "flame", check: () => ZG.getStreak() >= 30 },
  { id: "streak_100",      label: "100-day overall streak",      icon: "flame", check: () => ZG.getStreak() >= 100 },
  { id: "level_5",         label: "Reached Level 5",              icon: "star", check: () => ZG.getLevel() >= 5 },
  { id: "level_10",        label: "Reached Level 10",             icon: "star", check: () => ZG.getLevel() >= 10 },
  { id: "urge_surfed",     label: "Rode out a craving with the timer", icon: "breath", check: () =>
      Object.values(window.Recovery?.load?.().trackers || {}).some(t => (t.urges || []).some(u => (u.surfSeconds || 0) > 0)) },
  { id: "why_set",         label: "Set a personal why",           icon: "compass", check: () =>
      Object.values(window.Recovery?.load?.().trackers || {}).some(t => (t.why || "").length > 0) },
  { id: "habit_stacked",   label: "Stacked two habits together",  icon: "check", check: () =>
      (window.Habits?.load?.().habits || []).some(h => !!h.anchorId) },
  { id: "habit_categorized", label: "Organized habits into categories", icon: "check", check: () =>
      new Set((window.Habits?.load?.().habits || []).map(h => h.category || "general")).size >= 2 },
  { id: "profile_set", label: "Personalized your profile", icon: "compass", check: () =>
      !!(window.Profile?.getUsername?.() || window.Profile?.getMotto?.() || window.Profile?.getAvatar?.()) },
  { id: "coping_plan_set", label: "Wrote a coping plan",          icon: "compass", check: () =>
      Object.values(window.Recovery?.load?.().trackers || {}).some(t => (t.copingPlans || []).length > 0) },
  { id: "streak_freeze_used", label: "Used a streak freeze",      icon: "lock", check: () =>
      (window.Habits?.load?.().habits || []).some(h => (h.frozenDays || []).length > 0) },
  { id: "mood_tagged",     label: "Tagged a journal entry's mood", icon: "book", check: () =>
      (window.Journal?.load?.() || []).some(e => !!e.mood) },
];

const Growth = (() => {
  let activeBranch = "discipline";
  let activeGrowthTab = "overview";
  let achievementFilter = "unlocked";

  function _chip(icon, color, size = 34) {
    return `<span class="icon-chip" style="--chip-size:${size}px;--chip-color:${color};--chip-bg:color-mix(in srgb, ${color} 14%, transparent)">${window.Icons?.svg(icon) || ""}</span>`;
  }

  function renderTierBadge() {
    const total = ZG.getTotalActions();
    const tier = ZG.getTier(total);
    const next = ZG.getNextTier(total);
    return `
      <div class="tier-badge">
        ${_chip(tier.icon, tier.color, 44)}
        <div>
          <div class="tier-name">${tier.name}</div>
          <div class="tier-next">${next ? (ZG.t ? ZG.t("gr_actions_to", { n: next.min - total, tier: next.name }) : `${next.min - total} actions to ${next.name}`) : (ZG.t ? ZG.t("gr_max_tier") : "Maximum tier reached")}</div>
        </div>
      </div>`;
  }

  function renderXpBar() {
    const xp = ZG.getXP();
    const level = ZG.getLevel();
    const inLevel = xp % 100;
    return `
      <div class="xp-bar-wrap">
        <div class="xp-bar-head"><span>${ZG.t ? ZG.t("gr_level", { n: level }) : `Level ${level}`}</span><span>${ZG.t ? ZG.t("gr_xp_of_100", { n: inLevel }) : `${inLevel}/100 XP`}</span></div>
        <div class="xp-bar-track"><div class="xp-bar-fill" style="width:${inLevel}%"></div></div>
      </div>`;
  }

  function renderSkillTree() {
    const unlocked = ZG.getUnlockedSkills();
    const xp = ZG.getXP();

    const tabs = Object.entries(BRANCHES).map(([key, b]) => {
      const total = b.nodes.length, done = b.nodes.filter(n => unlocked.includes(n.id)).length;
      return `<button class="branch-tab${key === activeBranch ? " active" : ""}" style="--bc:var(${b.colorVar});--bc-r:var(${b.colorVar}-rgb)"
        onclick="Growth.switchBranch('${key}')"><span class="icon-chip sm" style="background:none;color:inherit">${window.Icons?.svg(b.icon) || ""}</span>${b.label} <span>${done}/${total}</span></button>`;
    }).join("");

    const branch = BRANCHES[activeBranch];
    const nodes = branch.nodes.map(n => {
      const isUnlocked = unlocked.includes(n.id);
      const pct = isUnlocked ? 100 : Math.min(100, Math.round((xp / n.xp) * 100));
      const R = 18, C = 2 * Math.PI * R, dash = (pct / 100) * C;
      const ring = `<svg class="progress-svg" viewBox="0 0 44 44"><circle cx="22" cy="22" r="${R}" fill="none" stroke="var(--border)" stroke-width="4"/>
        <circle cx="22" cy="22" r="${R}" fill="none" stroke="var(${n.colorVar})" stroke-width="4" stroke-linecap="round"
          stroke-dasharray="${dash.toFixed(1)} ${C.toFixed(1)}" stroke-dashoffset="${(C / 4).toFixed(1)}" opacity="${isUnlocked ? 1 : .6}"/></svg>`;
      return `
        <div class="node-row">
          <div class="node-ring">${ring}<span class="node-glyph" style="color:var(${n.colorVar})">${window.Icons?.svg(n.icon) || ""}</span></div>
          <div class="node-info">
            <div class="node-name${isUnlocked ? "" : " locked"}">${n.name}</div>
            <div class="node-desc">${n.desc}</div>
            <div class="node-perk">${n.perk}</div>
            ${!isUnlocked ? `<div class="node-need">${ZG.t ? ZG.t("gr_xp_to_unlock", { n: Math.max(0, n.xp - xp), pct }) : `${Math.max(0, n.xp - xp)} XP to unlock · ${pct}%`}</div>` : ""}
          </div>
        </div>`;
    }).join("");

    return `<div class="branch-tabs">${tabs}</div>${nodes}`;
  }

  function switchBranch(key) {
    activeBranch = key;
    const body = document.getElementById("growthPanelSkills");
    if (body) body.innerHTML = `<div class="card gr-block">${renderSkillTree()}</div>`;
  }

  function _achievementRows(filter) {
    const unlocked = ZG.getAchievements();
    const defs = ZG.ACHIEVEMENTS.filter(a => filter === "unlocked" ? unlocked[a.id] : !unlocked[a.id]);
    if (!defs.length) {
      return `<div class="empty-note">${filter === "unlocked" ? (ZG.t ? ZG.t("gr_none_unlocked") : "None unlocked yet — keep going.") : (ZG.t ? ZG.t("gr_all_unlocked") : "Everything is unlocked. Well earned.")}</div>`;
    }
    return `<div class="ach-list">${defs.map(a => {
      const on = !!unlocked[a.id];
      return `<div class="ach-row${on ? " on" : ""}">${_chip(a.icon, "var(--gold)", 30)}<span class="ach-name">${a.label}</span><span class="ach-check">${on ? (window.Icons?.svg("check", 2.4) || "") : ""}</span></div>`;
    }).join("")}</div>`;
  }

  function renderAchievementsPanel() {
    const unlocked = ZG.getAchievements();
    const total = ZG.ACHIEVEMENTS.length;
    const unlockedCount = ZG.ACHIEVEMENTS.filter(a => unlocked[a.id]).length;
    const lockedCount = total - unlockedCount;
    return `
      <div class="card gr-block">
        <div class="settings-actions" style="margin-top:0">
          <button class="btn-primary${achievementFilter === "unlocked" ? "" : " btn-secondary"}" style="flex:1" onclick="Growth.switchAchievementFilter('unlocked')">${ZG.t ? ZG.t("gr_unlocked_count", { n: unlockedCount }) : `Unlocked (${unlockedCount})`}</button>
          <button class="btn-primary${achievementFilter === "locked" ? "" : " btn-secondary"}" style="flex:1" onclick="Growth.switchAchievementFilter('locked')">${ZG.t ? ZG.t("gr_locked_count", { n: lockedCount }) : `Locked (${lockedCount})`}</button>
        </div>
        <div id="achievementRowsBody" style="margin-top:14px">${_achievementRows(achievementFilter)}</div>
      </div>`;
  }

  function switchAchievementFilter(filter) {
    achievementFilter = filter;
    const panel = document.getElementById("growthPanelAchievements");
    if (panel) panel.innerHTML = renderAchievementsPanel();
  }

  function switchGrowthTab(tab) {
    activeGrowthTab = tab;
    document.querySelectorAll(".growth-tab").forEach(b => {
      const on = b.dataset.gtab === tab;
      b.classList.toggle("active", on);
      b.setAttribute("aria-selected", String(on));
    });
    ["overview", "skills", "achievements"].forEach(t => {
      const panel = document.getElementById(`growthPanel${t[0].toUpperCase()}${t.slice(1)}`);
      if (panel) panel.hidden = t !== tab;
    });
  }

  function render() {
    const overviewBody = document.getElementById("growthPanelOverview");
    const skillsBody = document.getElementById("growthPanelSkills");
    const achBody = document.getElementById("growthPanelAchievements");
    if (!overviewBody) return;
    const calm = ZG.getCalmMode();

    overviewBody.innerHTML = `
      <div class="card gr-block">
        ${renderTierBadge()}
        ${calm ? "" : renderXpBar()}
        <div class="streak-canvas-wrap" style="margin-top:16px"><canvas id="streakCanvas" class="streak-canvas"></canvas></div>
        <div class="streak-theme-row">
          <button class="streak-theme-btn" data-theme="ember" onclick="Growth.setCanvasTheme('ember')">${window.Icons?.svg("flame") || ""} ${ZG.t ? ZG.t("gr_ember") : "Ember"}</button>
          <button class="streak-theme-btn" data-theme="grove" onclick="Growth.setCanvasTheme('grove')">${window.Icons?.svg("growth") || ""} ${ZG.t ? ZG.t("gr_grove") : "Grove"}</button>
        </div>
        <button class="btn-secondary" style="width:100%;margin-top:10px" onclick="window.StreakCard?.download?.()">${window.Icons?.svg("growth") || ""} ${ZG.t ? ZG.t("gr_download_streak_card") : "Download streak card"}</button>
        <p class="fine-print" style="margin:6px 2px 0">${ZG.t ? ZG.t("gr_streak_card_fine_print") : "A shareable image with your streak and tier — generated on this device, nothing sent anywhere. Never includes anything from Recovery."}</p>
      </div>`;

    const growthTabsWrap = document.querySelector(".growth-tabs");
    if (growthTabsWrap) growthTabsWrap.style.display = calm ? "none" : "flex";

    if (skillsBody) {
      skillsBody.innerHTML = calm
        ? `<div class="card gr-block"><p class="fine-print" style="margin:0">${ZG.t ? ZG.t("gr_calm_skills_hidden") : "Calm mode is on — the skill tree is hidden. It's still tracking underneath exactly as before; turn this off anytime in Settings to see it again."}</p></div>`
        : `<div class="card gr-block">${renderSkillTree()}</div>`;
    }
    if (achBody) {
      achBody.innerHTML = calm
        ? `<div class="card gr-block"><p class="fine-print" style="margin:0">${ZG.t ? ZG.t("gr_calm_achievements_hidden") : "Calm mode is on — achievements are hidden. They're still tracking underneath exactly as before; turn this off anytime in Settings to see them again."}</p></div>`
        : renderAchievementsPanel();
    }

    if (calm && activeGrowthTab !== "overview") switchGrowthTab("overview");
    _syncCanvasThemeButtons();
    _startCanvas();
  }

/* ── Streak canvas ── */
let canvas, ctx, raf, particles = [], theme = localStorage.getItem("zg_canvas_theme") || "ember", frame = 0;
let _cachedColors = { gold: {r:217,g:164,b:65}, clay: {r:201,g:123,b:74}, accent: {r:143,g:174,b:107} };

/* Theme colours are read lazily and only when the theme actually changed.
   Reading computed style right after a class change forces a synchronous
   style recalculation, so applyTheme() just marks the cache dirty (see
   syncTheme below) and the next draw refreshes it once, from one
   getComputedStyle() object instead of three separate lookups. */
let _colorsDirty = true;
function _hexToRgb(hex) {
  const m = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec((hex || "").trim());
  return m ? { r: parseInt(m[1], 16), g: parseInt(m[2], 16), b: parseInt(m[3], 16) } : { r: 143, g: 174, b: 107 };
}
function _refreshColors() {
  const cs = getComputedStyle(document.documentElement);
  _cachedColors = { gold: _hexToRgb(cs.getPropertyValue("--gold")), clay: _hexToRgb(cs.getPropertyValue("--clay")), accent: _hexToRgb(cs.getPropertyValue("--accent")) };
  _colorsDirty = false;
}
function _markColorsDirty() { _colorsDirty = true; }

function setCanvasTheme(t) { theme = t; localStorage.setItem("zg_canvas_theme", t); _syncCanvasThemeButtons(); _seedParticles(); }
function _syncCanvasThemeButtons() { document.querySelectorAll(".streak-theme-btn").forEach(b => b.classList.toggle("on", b.dataset.theme === theme)); }

function _setupCanvas() {
  canvas = document.getElementById("streakCanvas");
  if (!canvas) return false;
  ctx = canvas.getContext("2d");
  return true;
}
/* Canvas-context state (font etc.) is reset whenever width/height are assigned,
   so the cached font key is cleared here. */
let _fontKey = "";
function _resizeCanvas(cssWidth) {
  const dpr = window.devicePixelRatio || 1;
  const w = Math.round(cssWidth) || 320, h = 150;
  canvas.width = w * dpr; canvas.height = h * dpr;
  canvas.style.width = w + "px"; canvas.style.height = h + "px";
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  _fontKey = "";
}
/* Setting ctx.font makes the browser resolve styles against the canvas element,
   which flushes pending style/layout work. Only do it when the font really changes,
   never once per animation frame. */
function _setFont(font) { if (font !== _fontKey) { ctx.font = font; _fontKey = font; } }
function _W() { return (canvas?.width || 320) / (window.devicePixelRatio || 1); }
function _H() { return (canvas?.height || 150) / (window.devicePixelRatio || 1); }

function _seedParticles() {
    const streak = ZG.getStreak();
    const count = Math.min(70, 12 + streak * 2);
    const W = _W(), H = _H();
    particles = Array.from({ length: count }, () => ({
      x: W / 2 + (Math.random() - .5) * W * .7,
      y: H + Math.random() * 20,
      vx: (Math.random() - .5) * .4,
      vy: -(0.6 + Math.random() * 1.4),
      life: Math.random(), maxLife: .5 + Math.random() * .5,
      size: 2 + Math.random() * (streak > 14 ? 6 : 4),
    }));
  }

function _draw() {
  if (!ctx) return;
  if (_colorsDirty) _refreshColors();
  const W = _W(), H = _H(), streak = ZG.getStreak();
  ctx.clearRect(0, 0, W, H);
  if (theme === "ember") {
      const { gold, clay } = _cachedColors;
      const grad = ctx.createRadialGradient(W / 2, H, 0, W / 2, H, W * .5);
      grad.addColorStop(0, `rgba(${gold.r},${gold.g},${gold.b},.14)`); grad.addColorStop(1, "transparent");
      ctx.fillStyle = grad; ctx.fillRect(0, 0, W, H);
      particles.forEach(p => {
        p.x += p.vx + Math.sin(frame * .04 + p.y * .05) * .3;
        p.y += p.vy; p.life -= .01;
        if (p.life <= 0 || p.y < -10) { p.x = W / 2 + (Math.random() - .5) * W * .6; p.y = H + 5; p.vy = -(0.6 + Math.random() * 1.4); p.life = p.maxLife; }
        const alpha = Math.max(0, p.life / p.maxLife), size = p.size * alpha;
        const c = Math.random() < .5 ? gold : clay;
        ctx.beginPath(); ctx.arc(p.x, p.y, size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${c.r},${c.g},${c.b},${(alpha * .9).toFixed(2)})`; ctx.fill();
      });
      ctx.globalAlpha = .16 + Math.sin(frame * .05) * .05;
      _setFont(`bold ${Math.min(46, 22 + streak)}px sans-serif`); ctx.textAlign = "center"; ctx.textBaseline = "middle";
      ctx.fillStyle = "#fff"; ctx.fillText(`${streak}`, W / 2, H / 2); ctx.globalAlpha = 1;
  } else {
      const { accent: moss } = _cachedColors;
      const cx = W / 2, baseY = H - 6;
      const sway = Math.sin(frame * .02) * 2;
      const trunkH = Math.min(H - 26, 20 + streak * 1.4);
      ctx.strokeStyle = `rgba(${moss.r},${moss.g},${moss.b},.85)`;
      ctx.lineWidth = 3; ctx.lineCap = "round";
      ctx.beginPath(); ctx.moveTo(cx, baseY); ctx.lineTo(cx + sway, baseY - trunkH); ctx.stroke();

      const branches = Math.min(10, Math.floor(streak / 3));
      for (let i = 0; i < branches; i++) {
        const t = (i + 1) / (branches + 1);
        const by = baseY - trunkH * t;
        const bx = cx + sway * t;
        const dir = i % 2 === 0 ? 1 : -1;
        const len = 10 + (branches - i) * 1.6;
        const angle = dir * (0.6 + Math.sin(frame * .015 + i) * .06);
        ctx.strokeStyle = `rgba(${moss.r},${moss.g},${moss.b},.6)`;
        ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(bx, by);
        ctx.lineTo(bx + Math.sin(angle) * len, by - Math.cos(angle) * len);
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(bx + Math.sin(angle) * len, by - Math.cos(angle) * len, 3, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${moss.r},${moss.g},${moss.b},.75)`; ctx.fill();
      }
      ctx.globalAlpha = .5; _setFont("11px sans-serif"); ctx.textAlign = "center"; ctx.textBaseline = "alphabetic";
      ctx.fillStyle = `rgb(${moss.r},${moss.g},${moss.b})`;
      ctx.fillText(streak > 0 ? `${streak} days growing` : "plant your first day", cx, H - 8);
      ctx.globalAlpha = 1;
    }
  }

function _loop() { frame++; _draw(); raf = requestAnimationFrame(_loop); }

/* The animation is driven by a ResizeObserver on the canvas' parent: it reports
   the width after layout has run (no forced reflow) and reports 0 while the
   Growth section is hidden — so the loop only runs while the canvas is actually
   on screen instead of burning a requestAnimationFrame loop behind other tabs. */
let _ro = null;
function _onCanvasResize(entries) {
  cancelAnimationFrame(raf); raf = 0;
  const w = entries[entries.length - 1].contentRect.width;
  if (!w || document.hidden || !canvas) return;
  _resizeCanvas(w);
  _seedParticles();
  _loop();
}
function _startCanvas() {
  cancelAnimationFrame(raf); raf = 0;
  if (!_setupCanvas()) return;
  if (typeof ResizeObserver === "undefined") {           // very old browsers: single sizing pass, no live resize
    requestAnimationFrame(() => { _resizeCanvas(canvas.parentElement.clientWidth); _seedParticles(); _loop(); });
    return;
  }
  if (!_ro) _ro = new ResizeObserver(_onCanvasResize);
  _ro.disconnect();
  _ro.observe(canvas.parentElement);                     // re-observing always delivers a fresh initial callback
}

  document.addEventListener("visibilitychange", () => {
    if (document.hidden) { cancelAnimationFrame(raf); raf = 0; }
    else if (document.getElementById("growthSection")?.classList.contains("active")) _startCanvas();
  });
  document.addEventListener("DOMContentLoaded", () => {
    document.querySelectorAll(".growth-tab").forEach(btn => {
      btn.addEventListener("click", () => switchGrowthTab(btn.dataset.gtab));
    });
  });

  ZG.sectionRenderers.growth = render;

return { render, switchBranch, switchGrowthTab, switchAchievementFilter, setCanvasTheme, syncTheme: _markColorsDirty };
})();
window.Growth = Growth;
