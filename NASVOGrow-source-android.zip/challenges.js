"use strict";
/* ═══════════════════════════════════════════════════════════════
   CHALLENGES — short structured pushes, built only from Grow's own
   data (habit checks, journal entries) so this app stands alone.
═══════════════════════════════════════════════════════════════ */
const Challenges = (() => {
  const KEY = "zg_challenges";

  // Definitions now live in content/challenge-defs.js — a small, focused
  // file with no application logic, so a community PR proposing or tuning
  // a challenge never needs to touch this file at all (see CONTRIBUTING.md).
  const DEFS = window.ChallengeDefs || {};

  function load() { return Store.get(KEY, { active: null, history: [] }); }
  function save(s) { Store.set(KEY, s); }
  function today() { return new Date().toDateString(); }

  function _chip(def, size = 34) {
    return `<span class="icon-chip" style="--chip-size:${size}px;--chip-color:var(${def.colorVar});--chip-bg:rgba(var(${def.colorVar}-rgb),.14)">${window.Icons?.svg(def.icon) || ""}</span>`;
  }

  function start(id) {
    const s = load();
    if (s.active) { ZG.toast("Finish or abandon your current challenge first"); return; }
    const def = DEFS[id]; if (!def) return;
    s.active = { id, startTs: Date.now(), progress: _initProgress(def), lastCountDay: null };
    save(s);
    ZG.toast(`${def.name} started`, 2600, { icon: def.icon, color: `var(${def.colorVar})` });
    render();
  }

  function abandon() {
    const s = load(); if (!s.active) return;
    s.history.unshift({ id: s.active.id, endTs: Date.now(), completed: false });
    s.active = null;
    save(s);
    render();
  }

  function _initProgress(def) {
    if (def.id === "consistency_reset") return { daysDone: 0 };
    if (def.id === "habit_stack") return { count: 0 };
    if (def.id === "deep_reflection") return { count: 0 };
    if (def.id === "perfect_days") return { count: 0 };
    if (def.id === "urge_surf_wave") return { count: 0 };
    if (def.id === "plan_ahead") return { count: 0 };
    if (def.id === "clean_streak_5") return { daysDone: 0 };
    return {};
  }

  /** Called by other modules after a relevant action (habit toggle, journal save, recovery urge). */
  function notify(kind) {
    const s = load(); if (!s.active) return;
    const def = DEFS[s.active.id]; if (!def) return;
    const elapsed = Date.now() - s.active.startTs;
    if (elapsed > def.days * 86400000) { _expire(s, def); return; }
    if (def.failOn && def.failOn.includes(kind)) { _fail(s, def); return; }

    const p = s.active.progress;
    let advanced = false;

    if (def.id === "consistency_reset" && (kind === "habit" || kind === "journal" || kind === "recovery")) {
      const t = today();
      if (s.active.lastCountDay !== t) { p.daysDone++; s.active.lastCountDay = t; advanced = true;
        if (p.daysDone >= def.days) { _complete(s, def); return; } }
    }
    if (def.id === "clean_streak_5" && (kind === "habit" || kind === "journal" || kind === "recovery")) {
      const t = today();
      if (s.active.lastCountDay !== t) { p.daysDone++; s.active.lastCountDay = t; advanced = true;
        if (p.daysDone >= def.days) { _complete(s, def); return; } }
    }
    if (def.id === "habit_stack" && kind === "habit") {
      p.count++; advanced = true;
      if (p.count >= def.target) { _complete(s, def); return; }
    }
    if (def.id === "deep_reflection" && kind === "journal") {
      p.count++; advanced = true;
      if (p.count >= def.target) { _complete(s, def); return; }
    }
    if (def.id === "perfect_days" && kind === "all_habits") {
      p.count++; advanced = true;
      if (p.count >= def.target) { _complete(s, def); return; }
    }
    if (def.id === "urge_surf_wave" && kind === "surf") {
      p.count++; advanced = true;
      if (p.count >= def.target) { _complete(s, def); return; }
    }
    if (def.id === "plan_ahead" && kind === "plan") {
      p.count++; advanced = true;
      if (p.count >= def.target) { _complete(s, def); return; }
    }
    if (advanced) { save(s); render(); }
  }

  function _complete(s, def) {
    s.history.unshift({ id: def.id, endTs: Date.now(), completed: true, xp: def.xp });
    s.active = null;
    save(s);
    ZG.addXP(def.xp, `${def.name} complete`);
    const body = ZG.getCalmMode() ? "That's proof — you kept a promise to yourself." : `+${def.xp} XP. That's proof — you kept a promise to yourself.`;
    setTimeout(() => ZG.celebrate({ icon: def.icon, color: `var(${def.colorVar})`, title: "Challenge complete", sub: def.name, body }), 300);
    render();
  }

  function _expire(s, def) {
    s.history.unshift({ id: def.id, endTs: Date.now(), completed: false, expired: true });
    s.active = null;
    save(s);
    ZG.toast(`${def.name} expired — start fresh anytime`);
    render();
  }

  /** For challenges a relapse specifically breaks (see failOn on the def) —
   *  distinct from timing out: this ends the run right when the thing it
   *  was protecting against happens, not just when time runs out. */
  function _fail(s, def) {
    s.history.unshift({ id: def.id, endTs: Date.now(), completed: false, failed: true });
    s.active = null;
    save(s);
    ZG.toast(`${def.name} reset — a logged relapse ended this one. Starting over is always on the table.`, 4600);
    render();
  }

  function render() {
    const body = document.getElementById("challengesBody");
    if (!body) { return; }
    const s = load();
    let html = "";

    if (s.active) {
      const def = DEFS[s.active.id];
      const elapsed = Date.now() - s.active.startTs;
      const remainingH = Math.max(0, Math.ceil((def.days * 86400000 - elapsed) / 3600000));
      const p = s.active.progress;
      let progLine = "";
      if (def.id === "consistency_reset" || def.id === "clean_streak_5") {
        const dots = Array.from({ length: def.days }, (_, i) => `<span class="ch-day-dot${i < p.daysDone ? " done" : ""}">${i + 1}</span>`).join("");
        progLine = `<div class="ch-day-row">${dots}</div><div class="ch-prog-label">${p.daysDone}/${def.days} days · ${remainingH}h left</div>`;
      } else {
        progLine = `<div class="ch-prog-label">${p.count}/${def.target} · ${remainingH}h left</div>`;
      }
      html += `
        <div class="ch-active" style="--zt-c:var(${def.colorVar});--zt-r:var(${def.colorVar}-rgb)">
          <div class="ch-active-head">
            ${_chip(def)}
            <div><div class="ch-active-name">${def.name}</div><div class="ch-active-tag">Active</div></div>
            <button class="ch-abandon" onclick="Challenges.confirmAbandon()">✕</button>
          </div>
          ${progLine}
        </div>`;
    }

    const calm = ZG.getCalmMode();
    html += Object.values(DEFS).map(def => {
      const isActive = s.active?.id === def.id;
      const blocked = !!s.active && !isActive;
      const completions = s.history.filter(h => h.id === def.id && h.completed).length;
      const rewardText = calm
        ? (completions ? `Completed ${completions}×` : "")
        : (completions ? `Completed ${completions}× · +${def.xp} XP each` : `+${def.xp} XP`);
      return `
        <div class="ch-card">
          ${_chip(def)}
          <div class="ch-info">
            <div class="ch-name">${def.name}</div>
            <div class="ch-desc">${def.tagline}</div>
            ${rewardText ? `<div class="ch-reward">${rewardText}</div>` : ""}
          </div>
          <button class="ch-start" ${isActive || blocked ? "disabled" : ""} onclick="Challenges.start('${def.id}')">${isActive ? "Active" : "Start"}</button>
        </div>`;
    }).join("");

    if (s.history.length) {
      html += `<div class="zr-section-label">Recent</div>`;
      html += s.history.slice(0, 6).map(h => {
        const def = DEFS[h.id];
        const d = new Date(h.endTs).toLocaleDateString("en", { month: "short", day: "numeric" });
        const outcomeText = h.completed ? (calm ? "complete" : `+${h.xp} XP`) : (h.failed ? "reset by a relapse" : (h.expired ? "expired" : "abandoned"));
        return `<div class="ch-history-row">${def ? _chip(def, 20) : ""}<span style="flex:1">${def?.name ?? h.id}</span>
          <span class="${h.completed ? "ch-history-ok" : "ch-history-fail"}">${outcomeText}</span>
          <span>${d}</span></div>`;
      }).join("");
    }

    body.innerHTML = html;
  }

  async function confirmAbandon() {
    const ok = await ZG.confirm({ title: "Abandon this challenge?", body: "Progress will be lost — this can't be undone.", confirmLabel: "Abandon", danger: true });
    if (ok) abandon();
  }

  ZG.sectionRenderers.recovery = (() => {
    const prev = ZG.sectionRenderers.recovery;
    return () => { prev?.(); render(); };
  })();
  // Rendered on demand the first time Recovery is opened, not on every page
  // load — see the matching note in journal.js.

  function completedCount() { return load().history.filter(h => h.completed).length; }

  return { start, abandon, confirmAbandon, notify, render, DEFS, completedCount, load };
})();
window.Challenges = Challenges;
