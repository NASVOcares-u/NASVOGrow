"use strict";
/* ═══════════════════════════════════════════════════════════════
   INSIGHTS — the analysis layer Grow didn't have: it reads your own
   habit, recovery, and journal data back to you instead of just
   collecting it. Everything below is computed locally, entirely from
   data Grow already stores on this device — nothing here ever calls
   out anywhere. An earlier version had a generated "weekly read" text
   card here; it's been removed in favor of the plainer, more directly
   verifiable correlation call-outs below ("What the data says") —
   numbers you can check against your own log, not prose to trust.

   Two pieces are deliberately modeled on NASVO Intelligence's
   sharpest ideas, rebuilt against identity data instead of focus
   sessions:
     • Growth Radar   ~ Intelligence's Cognitive Radar
     • Identity DNA    ~ Intelligence's Focus DNA
═══════════════════════════════════════════════════════════════ */
const Insights = (() => {
  // HALT_LABELS/MOOD_LABELS used to be read here directly by _insightRows;
  // that logic now lives in correlations.js's plugin registry (with its
  // own copies), so this file no longer needs them.

  function _dateKey(ts) { return new Date(ts).toDateString(); }
  function _lastNDates(n) { return Array.from({ length: n }, (_, i) => { const d = new Date(); d.setDate(d.getDate() - i); return d.toDateString(); }); }

  function _recoveryEvents() {
    const rec = window.Recovery?.load?.() || { trackers: {} };
    const events = [];
    Object.entries(rec.trackers).forEach(([id, t]) => {
      (t.urges || []).forEach(u => events.push({ ts: u.ts, type: "urge", halt: u.halt || [], intensity: u.intensity ?? null, trackerId: id }));
      (t.relapses || []).forEach(r => events.push({ ts: r.ts, type: "relapse", halt: r.halt || [], intensity: r.intensity ?? null, trackerId: id }));
    });
    return events.sort((a, b) => a.ts - b.ts);
  }

  function _habitCompletionRatio(dateStr) {
    const h = window.Habits?.load?.();
    if (!h || !h.habits.length) return null;
    const done = (h.log[dateStr] || []).length;
    return done / h.habits.length;
  }

  function _journalDates() { return new Set((window.Journal?.load?.() || []).map(e => e.date)); }

  /** Multiple decayed, recency-weighted risk windows instead of one flat,
   *  lifetime-equal-weight best bucket. Two upgrades over the original
   *  single-bucket model:
   *    • Recency decay — an event fades toward zero influence over time
   *      (half-life below) instead of counting exactly as loud as the day
   *      it happened forever. A pattern that's genuinely shifting shows
   *      up here before it would in a flat lifetime count.
   *    • Multiple windows with a confidence label — up to 3 distinct
   *      day/hour windows that each clearly stand out from the average,
   *      each labeled low/medium/high confidence rather than one binary
   *      yes/no, so a second-best window doesn't get silently discarded
   *      just because a single best one existed.
   *  Same honesty floor as before: returns null outright rather than
   *  guess from too little data. */
  const RISK_DECAY_HALF_LIFE_DAYS = 45; // an event this old carries half the weight of one logged today

  function _decayWeight(ts) {
    const ageDays = Math.max(0, (Date.now() - ts) / 86400000);
    return Math.pow(0.5, ageDays / RISK_DECAY_HALF_LIFE_DAYS);
  }

  function _riskWindows(events) {
    if (events.length < 6) return null;
    const grid = Array.from({ length: 7 }, () => Array(24).fill(0));
    events.forEach(e => {
      const d = new Date(e.ts);
      const severity = e.type === "relapse" ? 2 : 1;
      grid[d.getDay()][d.getHours()] += severity * _decayWeight(e.ts);
    });

    const cells = [];
    let sum = 0, nonZeroCount = 0;
    for (let day = 0; day < 7; day++) {
      for (let hour = 0; hour < 24; hour++) {
        const v = grid[day][hour];
        if (v > 0) { sum += v; nonZeroCount++; cells.push({ day, hour, value: v }); }
      }
    }
    if (!nonZeroCount) return null;
    const avg = sum / nonZeroCount;
    cells.sort((a, b) => b.value - a.value);

    const DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    const windows = [];
    for (const cell of cells) {
      if (windows.length >= 3) break;
      // A dominant top cluster pulls the average toward itself, which would
      // otherwise make it disproportionately hard for a real SECOND cluster
      // to also clear the same bar the top one needed to. 1.15x keeps this
      // meaningful (nothing in a genuinely flat/uniform week can exceed its
      // own mean) without punishing a second real signal for the first
      // one's size.
      if (cell.value < avg * 1.15) break; // cells are sorted descending — once one fails to stand out, none after it will either
      if (cell.value < 1.5) continue; // too faint on its own to call a "window," decayed or not
      const ratio = cell.value / avg;
      const confidence = ratio >= 2.0 ? "high" : ratio >= 1.5 ? "medium" : "low";
      windows.push({
        dow: cell.day, hour: cell.hour,
        dayLabel: DAYS[cell.day], hourLabel: _fmtHour(cell.hour),
        value: Math.round(cell.value * 10) / 10, confidence,
      });
    }
    if (!windows.length) return null;
    return { windows, top: windows[0] };
  }

  function _weekHeatmap(events) {
    const grid = Array.from({ length: 7 }, () => Array(24).fill(0));
    events.forEach(e => { const d = new Date(e.ts); grid[d.getDay()][d.getHours()] += e.type === "relapse" ? 2 : 1; });
    return { grid, maxVal: Math.max(...grid.flat(), 1) };
  }

  function _dayOfWeekResist(events) {
    const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    const counts = Array.from({ length: 7 }, () => ({ urge: 0, relapse: 0 }));
    events.forEach(e => { const d = new Date(e.ts).getDay(); counts[d][e.type === "relapse" ? "relapse" : "urge"]++; });
    return counts.map((c, i) => ({ day: DAYS[i], urge: c.urge, relapse: c.relapse, total: c.urge + c.relapse, resistRate: (c.urge + c.relapse) ? c.urge / (c.urge + c.relapse) : null }));
  }

  function _habitCorrelation(events) {
    const byDate = {};
    events.forEach(e => { const k = _dateKey(e.ts); if (!byDate[k]) byDate[k] = { urge: 0, relapse: 0 }; byDate[k][e.type === "relapse" ? "relapse" : "urge"]++; });
    const resistDays = [], relapseDays = [];
    Object.entries(byDate).forEach(([date, c]) => {
      const ratio = _habitCompletionRatio(date);
      if (ratio == null) return;
      (c.relapse > 0 ? relapseDays : resistDays).push(ratio);
    });
    const avg = arr => arr.length ? Math.round((arr.reduce((s, v) => s + v, 0) / arr.length) * 100) : null;
    return { resistAvg: avg(resistDays), relapseAvg: avg(relapseDays), resistDays: resistDays.length, relapseDays: relapseDays.length };
  }

  function _journalCorrelation(events) {
    const jDates = _journalDates();
    const relapseDates = [...new Set(events.filter(e => e.type === "relapse").map(e => _dateKey(e.ts)))];
    const allDates = [...new Set(events.map(e => _dateKey(e.ts)))];
    if (!relapseDates.length || !allDates.length) return null;
    const relapseWithJournal = relapseDates.filter(d => jDates.has(d)).length;
    const allWithJournal = allDates.filter(d => jDates.has(d)).length;
    return { relapsePct: Math.round((relapseWithJournal / relapseDates.length) * 100), basePct: Math.round((allWithJournal / allDates.length) * 100), relapseDays: relapseDates.length };
  }

  function _haltFrequency(events) {
    const counts = {};
    events.forEach(e => (e.halt || []).forEach(h => { counts[h] = (counts[h] || 0) + 1; }));
    const sorted = Object.entries(counts).sort((a, b) => b[1] - a[1]);
    return sorted.length ? { tag: sorted[0][0], count: sorted[0][1] } : null;
  }

  function _intensityCompare(events) {
    const resisted = events.filter(e => e.type === "urge" && e.intensity != null).map(e => e.intensity);
    const relapsed = events.filter(e => e.type === "relapse" && e.intensity != null).map(e => e.intensity);
    const avg = arr => arr.length ? Math.round((arr.reduce((s, v) => s + v, 0) / arr.length) * 10) / 10 : null;
    return { resistedAvg: avg(resisted), relapsedAvg: avg(relapsed) };
  }

  /** Only populated from the optional post-urge-surf rating (see
   *  recovery.js's _askSurfSatisfaction) — this is the person's own
   *  self-reported number, not anything the app infers, so the insight
   *  row built from it stays a direct readback rather than a claim. */
  function _satisfactionCompare(events) {
    const resisted = events.filter(e => e.type === "urge" && e.satisfaction != null).map(e => e.satisfaction);
    const relapsed = events.filter(e => e.type === "relapse" && e.satisfaction != null).map(e => e.satisfaction);
    const avg = arr => arr.length ? Math.round((arr.reduce((s, v) => s + v, 0) / arr.length) * 10) / 10 : null;
    if (resisted.length < 2 && relapsed.length < 2) return null;
    return { resistedAvg: avg(resisted), relapsedAvg: avg(relapsed) };
  }

  /* ── Mood correlations — only possible once journal entries carry a mood
     tag. Deliberately requires a handful of tagged entries per mood before
     saying anything, so an honest "not enough data yet" beats a false
     pattern read off two data points. */
  function _moodByDate() {
    const map = {};
    (window.Journal?.load?.() || []).forEach(e => { if (e.mood) map[e.date] = e.mood; });
    return map;
  }

  function _moodHabitCorrelation() {
    const moodByDate = _moodByDate();
    const byMood = {};
    Object.entries(moodByDate).forEach(([date, mood]) => {
      const ratio = _habitCompletionRatio(date);
      if (ratio == null) return;
      (byMood[mood] || (byMood[mood] = [])).push(ratio);
    });
    const avg = arr => Math.round((arr.reduce((s, v) => s + v, 0) / arr.length) * 100);
    const summary = Object.entries(byMood)
      .filter(([, arr]) => arr.length >= 2)
      .map(([mood, arr]) => ({ mood, avg: avg(arr), n: arr.length }));
    if (summary.length < 2) return null;
    summary.sort((a, b) => b.avg - a.avg);
    return { best: summary[0], worst: summary[summary.length - 1] };
  }

  function _moodRecoveryCorrelation(events) {
    const moodByDate = _moodByDate();
    const byMood = {};
    events.forEach(e => {
      const mood = moodByDate[_dateKey(e.ts)];
      if (!mood) return;
      const c = byMood[mood] || (byMood[mood] = { urge: 0, relapse: 0 });
      c[e.type === "relapse" ? "relapse" : "urge"]++;
    });
    const summary = Object.entries(byMood)
      .map(([mood, c]) => ({ mood, total: c.urge + c.relapse, resistRate: c.urge / (c.urge + c.relapse) }))
      .filter(x => x.total >= 3);
    if (summary.length < 2) return null;
    summary.sort((a, b) => b.resistRate - a.resistRate);
    return { best: summary[0], worst: summary[summary.length - 1] };
  }

  /* ── Sleep & weather correlations — same honesty rules as mood above:
     only speak up once there's a real sample on both sides, and this
     entire block is a no-op unless the person has opted in to Context
     tracking (see context.js). "Weather" here is the self-reported tag
     from that log, not fetched data — there's no external weather
     service involved anywhere in this app. */
  function _sleepHabitCorrelation() {
    if (!window.Context?.isEnabled?.()) return null;
    const ctxLog = window.Context.load().log || {};
    const rested = [], short = [];
    Object.entries(ctxLog).forEach(([date, entry]) => {
      if (entry.sleepHours == null) return;
      const ratio = _habitCompletionRatio(date);
      if (ratio == null) return;
      (entry.sleepHours >= 7 ? rested : short).push(ratio);
    });
    if (rested.length < 2 || short.length < 2) return null;
    const avg = arr => Math.round((arr.reduce((s, v) => s + v, 0) / arr.length) * 100);
    return { restedAvg: avg(rested), shortAvg: avg(short), restedN: rested.length, shortN: short.length };
  }

  function _sleepRecoveryCorrelation(events) {
    if (!window.Context?.isEnabled?.()) return null;
    const ctxLog = window.Context.load().log || {};
    const buckets = { rested: { urge: 0, relapse: 0 }, short: { urge: 0, relapse: 0 } };
    events.forEach(e => {
      const entry = ctxLog[_dateKey(e.ts)];
      if (!entry || entry.sleepHours == null) return;
      const b = entry.sleepHours >= 7 ? buckets.rested : buckets.short;
      b[e.type === "relapse" ? "relapse" : "urge"]++;
    });
    const restedTotal = buckets.rested.urge + buckets.rested.relapse;
    const shortTotal = buckets.short.urge + buckets.short.relapse;
    if (restedTotal < 3 || shortTotal < 3) return null;
    return {
      restedResist: Math.round((buckets.rested.urge / restedTotal) * 100),
      shortResist: Math.round((buckets.short.urge / shortTotal) * 100),
    };
  }

  function _weatherRecoveryCorrelation(events) {
    if (!window.Context?.isEnabled?.()) return null;
    const ctxLog = window.Context.load().log || {};
    const byWeather = {};
    events.forEach(e => {
      const entry = ctxLog[_dateKey(e.ts)];
      if (!entry || !entry.weather) return;
      const c = byWeather[entry.weather] || (byWeather[entry.weather] = { urge: 0, relapse: 0 });
      c[e.type === "relapse" ? "relapse" : "urge"]++;
    });
    const summary = Object.entries(byWeather)
      .map(([weather, c]) => ({ weather, total: c.urge + c.relapse, resistRate: c.urge / (c.urge + c.relapse) }))
      .filter(x => x.total >= 3);
    if (summary.length < 2) return null;
    summary.sort((a, b) => b.resistRate - a.resistRate);
    return { best: summary[0], worst: summary[summary.length - 1] };
  }

  /* ═══════════════════════ GROWTH RADAR ═══════════════════════
     Five axes, each 0–100, all derived from Grow's own local data:
       Consistency  — active-day ratio over the last 21 days
       Momentum     — identity-action volume, last 7d vs prior 7d
       Endurance    — how long habit streaks typically run
       Resistance   — urges resisted vs. reset, recency-weighted
       Resilience   — how fast you're back to active after a reset
  ═══════════════════════════════════════════════════════════════ */
  function _dailyActionCounts() {
    const counts = {};
    const bump = (date, n = 1) => { if (date) counts[date] = (counts[date] || 0) + n; };
    const h = window.Habits?.load?.() || { log: {} };
    Object.entries(h.log || {}).forEach(([d, arr]) => bump(d, arr.length));
    (window.Journal?.load?.() || []).forEach(e => bump(e.date, 1));
    Object.values(window.Recovery?.load?.().trackers || {}).forEach(t => {
      (t.urges || []).forEach(u => bump(_dateKey(u.ts), 1));
      (t.relapses || []).forEach(r => bump(_dateKey(r.ts), 1));
    });
    return counts;
  }

  function _consistencyScore() {
    const dates = new Set(Store.get("zg_active_dates", []));
    const last21 = _lastNDates(21);
    const activeDays = last21.filter(d => dates.has(d)).length;
    return Math.round((activeDays / 21) * 100);
  }

  function _momentum(counts) {
    const last14 = _lastNDates(14);
    const older = last14.slice(7).reduce((s, d) => s + (counts[d] || 0), 0);
    const recent = last14.slice(0, 7).reduce((s, d) => s + (counts[d] || 0), 0);
    if (older === 0) return { score: recent > 0 ? 82 : 55, direction: recent > 0 ? "new" : "flat", pct: 0 };
    const pct = Math.round(((recent - older) / older) * 100);
    const direction = pct > 15 ? "improving" : pct < -15 ? "declining" : "stable";
    const score = direction === "improving" ? Math.min(100, 75 + Math.min(25, Math.abs(pct) / 2))
      : direction === "declining" ? Math.max(0, 50 - Math.min(50, Math.abs(pct) / 2)) : 62;
    return { score: Math.round(score), direction, pct };
  }

  function _habitEndurance() {
    const h = window.Habits?.load?.();
    if (!h || !h.habits.length) return null;
    const streaks = h.habits.map(x => window.Habits.streakFor(x.id));
    const avg = streaks.reduce((s, v) => s + v, 0) / streaks.length;
    return Math.round(Math.min(100, (avg / 21) * 100));
  }

  function _resistanceScore(events) {
    if (!events.length) return null;
    const recent = events.slice(-30);
    let weighted = 0, total = 0;
    recent.forEach((e, i) => { const w = 0.5 + 0.5 * (i / recent.length); total += w; if (e.type === "urge") weighted += w; });
    return Math.round((weighted / total) * 100);
  }

  function _resilienceScore(events) {
    const relapses = events.filter(e => e.type === "relapse").map(e => e.ts).sort((a, b) => a - b);
    if (!relapses.length) return null;
    const activeDates = new Set(Store.get("zg_active_dates", []));
    const gaps = relapses.map(ts => {
      const base = new Date(ts);
      for (let i = 0; i <= 14; i++) {
        const d = new Date(base); d.setDate(d.getDate() + i);
        if (activeDates.has(d.toDateString())) return i;
      }
      return 14;
    });
    const avgGap = gaps.reduce((s, v) => s + v, 0) / gaps.length;
    const score = avgGap <= 0 ? 95 : avgGap <= 1 ? 88 : avgGap <= 2 ? 75 : avgGap <= 4 ? 60 : avgGap <= 7 ? 42 : 25;
    return { score, avgDays: Math.round(avgGap * 10) / 10, samples: gaps.length };
  }

  /* ── Depth — how much of recent activity was higher-effort vs a quick
     checkmark. Not a claim about measuring dopamine or neurochemistry —
     just a weighted ratio: a plain habit tap counts once, a journal entry
     or a resisted urge count for more, a weekly reflection or a completed
     challenge count for more still. Requires a little recent activity
     before it says anything, same honesty rule as the other axes. */
  function _depthScore(events) {
    const since = Date.now() - 21 * 86400000;

    const h = window.Habits?.load?.() || { log: {} };
    let habitCount = 0;
    Object.entries(h.log || {}).forEach(([dateStr, ids]) => {
      if (new Date(dateStr).getTime() >= since) habitCount += (ids || []).length;
    });

    const journalCount = (window.Journal?.load?.() || []).filter(e => (e.ts || 0) >= since).length;
    const reflectionCount = Store.get("zg_reflections", []).filter(r => (r.ts || 0) >= since).length;

    const recentEvents = events.filter(e => e.ts >= since);
    const urgeCount = recentEvents.filter(e => e.type === "urge").length;
    const surfBonusCount = recentEvents.filter(e => e.type === "urge" && (e.surfSeconds || 0) > 0).length;

    const challengeCount = (window.Challenges?.load?.().history || []).filter(c => c.completed && (c.endTs || 0) >= since).length;

    const shallowWeight = habitCount * 1;
    const deepWeight = journalCount * 2 + reflectionCount * 3 + urgeCount * 2 + surfBonusCount * 1 + challengeCount * 4;
    const totalWeight = shallowWeight + deepWeight;
    if (totalWeight < 5) return null;
    return Math.round((deepWeight / totalWeight) * 100);
  }

  function _computeRadar(events) {
    const counts = _dailyActionCounts();
    const consistency = _consistencyScore();
    const momentum = _momentum(counts);
    const endurance = _habitEndurance();
    const resistance = _resistanceScore(events);
    const resilience = _resilienceScore(events);
    const depth = _depthScore(events);
    return {
      consistency, momentum, endurance, resistance, resilience, depth,
      axes: [
        { label: "Consistency", value: consistency, display: `${consistency}` },
        { label: "Momentum", value: momentum.score, display: momentum.direction },
        { label: "Endurance", value: endurance ?? 0, display: endurance == null ? "—" : `${endurance}` },
        { label: "Resistance", value: resistance ?? 0, display: resistance == null ? "—" : `${resistance}` },
        { label: "Resilience", value: resilience ? resilience.score : 55, display: resilience ? `${resilience.avgDays}d` : "—" },
        { label: "Depth", value: depth ?? 0, display: depth == null ? "—" : `${depth}%` },
      ],
    };
  }

  /* ═══════════════════════ IDENTITY DNA ═══════════════════════
     A shareable read on how you actually show up: when, on what
     kind of action, and how consistently — matched to one of a
     handful of archetypes. Needs a bit more history than the rest
     of Insights so the read is honest rather than a coin flip.
  ═══════════════════════════════════════════════════════════════ */
  const ARCHETYPES = [
    { name: "Night Rebuilder", icon: "moon", cond: p => p.peakHour != null && (p.peakHour >= 20 || p.peakHour < 5) },
    { name: "Early Anchor", icon: "sunrise", cond: p => p.peakHour != null && p.peakHour >= 5 && p.peakHour < 10 },
    { name: "Quiet Fighter", icon: "shield", cond: p => p.dominantType === "recovery" },
    { name: "Deep Reflector", icon: "book", cond: p => p.dominantType === "journal" },
    { name: "Habit Stacker", icon: "check", cond: p => p.dominantType === "habits" },
    { name: "Steady Builder", icon: "growth", cond: p => p.consistency >= 65 },
    { name: "The Becoming", icon: "star", cond: () => true },
  ];
  function _fmtHour(h) { return `${h % 12 || 12}:00 ${h < 12 ? "AM" : "PM"}`; }

  function _computeDNA() {
    const totalActions = ZG.getTotalActions();
    if (totalActions < 15) return { insufficient: true, have: totalActions, need: 15 };

    const journal = window.Journal?.load?.() || [];
    const rec = window.Recovery?.load?.() || { trackers: {} };
    const recEvents = Object.values(rec.trackers).flatMap(t => [...(t.urges || []), ...(t.relapses || [])]);
    const timedEvents = [...journal.map(e => e.ts), ...recEvents.map(e => e.ts)];

    let peakHour = null, peakConfidence = 0;
    if (timedEvents.length >= 5) {
      const hourCounts = {};
      timedEvents.forEach(ts => { const hr = new Date(ts).getHours(); hourCounts[hr] = (hourCounts[hr] || 0) + 1; });
      const sorted = Object.entries(hourCounts).sort((a, b) => b[1] - a[1]);
      peakHour = parseInt(sorted[0][0], 10);
      peakConfidence = Math.round((sorted[0][1] / timedEvents.length) * 100);
    }

    const dayCounts = Array(7).fill(0);
    const h = window.Habits?.load?.() || { log: {} };
    Object.entries(h.log || {}).forEach(([d, arr]) => { dayCounts[new Date(d).getDay()] += arr.length; });
    journal.forEach(e => dayCounts[new Date(e.ts).getDay()]++);
    recEvents.forEach(e => dayCounts[new Date(e.ts).getDay()]++);
    const DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    const bestDay = DAYS[dayCounts.indexOf(Math.max(...dayCounts))];

    const habitTotal = Object.values(h.log || {}).reduce((s, arr) => s + arr.length, 0);
    const journalTotal = journal.length;
    const recoveryResistTotal = Object.values(rec.trackers).reduce((s, t) => s + (t.urges || []).length, 0);
    const typeCounts = { habits: habitTotal, journal: journalTotal, recovery: recoveryResistTotal };
    const dominantType = Object.entries(typeCounts).sort((a, b) => b[1] - a[1])[0][0];

    const consistency = _consistencyScore();
    const archetype = ARCHETYPES.find(a => a.cond({ peakHour, dominantType, consistency })) || ARCHETYPES[ARCHETYPES.length - 1];

    return { peakHour, peakHourLabel: peakHour != null ? _fmtHour(peakHour) : null, peakConfidence, bestDay, dominantType, consistency, archetype, totalActions };
  }

  function compute() {
    const events = _recoveryEvents();
    if (ZG.getTotalActions() < 5 && events.length < 3) return { insufficient: true };
    return {
      events,
      heatmap: _weekHeatmap(events),
      dayOfWeek: _dayOfWeekResist(events),
      habitCorr: _habitCorrelation(events),
      journalCorr: _journalCorrelation(events),
      moodHabitCorr: _moodHabitCorrelation(),
      moodRecoveryCorr: _moodRecoveryCorrelation(events),
      sleepHabitCorr: _sleepHabitCorrelation(),
      sleepRecoveryCorr: _sleepRecoveryCorrelation(events),
      weatherRecoveryCorr: _weatherRecoveryCorrelation(events),
      halt: _haltFrequency(events),
      intensity: _intensityCompare(events),
      satisfaction: _satisfactionCompare(events),
      radar: _computeRadar(events),
      dna: _computeDNA(),
      riskWindows: _riskWindows(events),
    };
  }

  /** Every per-signal row now lives in correlations.js's plugin registry
   *  (see that file's header for why) — this just runs them and supplies
   *  the one purely-UI fallback for a week with nothing to say yet. */
  function _insightRows(r) {
    const rows = window.CorrelationPlugins?.evaluate?.(r) || [];
    if (!rows.length) rows.push({ type: "neutral", text: "Keep logging urges and check-ins — patterns need a little more data to surface honestly." });
    return rows;
  }

  function _renderHeatmap(hm) {
    const CELL = 10, GAP = 2, ROW_H = 13, ROW = 15, TOP = 18, LABEL_W = 32, HOURS = 24;   // labels are 12.5px (the SVG shrinks on narrow cards), so rows are taller than they are wide
    const W = LABEL_W + HOURS * (CELL + GAP), H = 7 * ROW + TOP;
    const DAYS_S = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    let rows = "";
    [0, 6, 12, 18].forEach(h => {
      const x = LABEL_W + h * (CELL + GAP) + CELL / 2;
      const l = h === 0 ? "12a" : h === 12 ? "12p" : h < 12 ? `${h}a` : `${h - 12}p`;
      rows += `<text x="${x}" y="11" text-anchor="middle" class="ins-hm-label">${l}</text>`;
    });
    [1, 2, 3, 4, 5, 6, 0].forEach((dayIdx, row) => {
      const y = TOP + row * ROW;
      rows += `<text x="${LABEL_W - 5}" y="${y + ROW_H - 2}" text-anchor="end" class="ins-hm-label">${DAYS_S[dayIdx]}</text>`;
      for (let h = 0; h < HOURS; h++) {
        const v = hm.grid[dayIdx][h], ratio = hm.maxVal > 0 ? v / hm.maxVal : 0;
        const op = v === 0 ? 0.07 : 0.22 + ratio * 0.78;
        const x = LABEL_W + h * (CELL + GAP);
        rows += `<rect x="${x}" y="${y}" width="${CELL}" height="${ROW_H}" rx="2" class="ins-hm-cell" fill-opacity="${op.toFixed(2)}"><title>${DAYS_S[dayIdx]} ${h}:00 — ${v || "no logged moments"}</title></rect>`;
      }
    });
    return `<svg viewBox="0 0 ${W} ${H}" width="100%" height="${H}">${rows}</svg>`;
  }

  function _renderRadarSvg(axes) {
    const W = 290, H = 220, CX = 145, CY = 110, R = 78, N = axes.length;
    const angle = i => -Math.PI / 2 + i * (2 * Math.PI / N);
    const pt = (i, r) => ({ x: CX + r * Math.cos(angle(i)), y: CY + r * Math.sin(angle(i)) });
    const rings = [0.25, 0.5, 0.75, 1].map(s => `<polygon points="${Array.from({ length: N }, (_, i) => { const p = pt(i, R * s); return `${p.x},${p.y}`; }).join(" ")}" class="ins-radar-ring"/>`).join("");
    const axesLines = Array.from({ length: N }, (_, i) => { const p = pt(i, R); return `<line x1="${CX}" y1="${CY}" x2="${p.x}" y2="${p.y}" class="ins-radar-axis"/>`; }).join("");
    const dataPts = axes.map((a, i) => { const p = pt(i, (a.value / 100) * R); return `${p.x},${p.y}`; }).join(" ");
    const dots = axes.map((a, i) => { const p = pt(i, (a.value / 100) * R); return `<circle cx="${p.x}" cy="${p.y}" r="2.6" class="ins-radar-dot"/>`; }).join("");
    const labels = axes.map((a, i) => { const p = pt(i, R + 17); return `<text x="${p.x}" y="${p.y}" text-anchor="middle" class="ins-radar-label">${a.label}</text>`; }).join("");
    return `<svg viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" style="max-width:100%;height:auto">${rings}${axesLines}<polygon points="${dataPts}" class="ins-radar-area"/>${dots}${labels}</svg>`;
  }

  function _renderRadarPanel(radar) {
    return `
      <div class="ins-radar-wrap">${_renderRadarSvg(radar.axes)}</div>
      <div class="ins-radar-legend">
        ${radar.axes.map(a => `<div class="ins-radar-leg-row"><span>${a.label}</span><span class="ins-radar-leg-val">${a.display}</span></div>`).join("")}
      </div>
      <p class="fine-print" style="margin-top:10px">Endurance needs habits, Resistance and Resilience need recovery check-ins, Depth needs a bit of recent activity across the board — axes fill in as you use those sections.</p>`;
  }

  function _renderDnaPanel(dna) {
    if (dna.insufficient) {
      return `<p class="fine-print" style="margin-top:0">${dna.need - dna.have} more logged action${dna.need - dna.have === 1 ? "" : "s"} and your Identity DNA unlocks — the archetype that best matches how you actually show up.</p>`;
    }
    const a = dna.archetype;
    const typeLabel = { habits: "Habit check-offs", journal: "Journaling", recovery: "Resisted urges" }[dna.dominantType] || "—";
    return `
      <div class="ins-dna-card">
        <div class="ins-dna-icon">${window.Icons?.svg(a.icon) || ""}</div>
        <div class="ins-dna-info">
          <span class="ins-dna-name">${a.name}</span>
          <span class="ins-dna-sub">${dna.peakHourLabel ? `Peak ${dna.peakHourLabel} · ` : ""}${dna.bestDay}s · ${typeLabel}</span>
        </div>
      </div>
      <div class="ins-dna-grid">
        <div class="ins-dna-cell"><span class="ins-dna-val">${dna.peakHourLabel || "—"}</span><span class="ins-dna-lbl">Peak time</span></div>
        <div class="ins-dna-cell"><span class="ins-dna-val">${dna.bestDay}</span><span class="ins-dna-lbl">Strongest day</span></div>
        <div class="ins-dna-cell"><span class="ins-dna-val">${typeLabel}</span><span class="ins-dna-lbl">Leading action</span></div>
        <div class="ins-dna-cell"><span class="ins-dna-val">${dna.consistency}%</span><span class="ins-dna-lbl">Consistency</span></div>
      </div>`;
  }

  /* ═══════════════════════ HABIT TRENDS ═══════════════════════
     The habit list's own 21-day dot strip is great for "did I do
     this recently" but too short a window to show whether a habit
     is actually getting more or less consistent over time. This
     buckets completions by week over a longer stretch instead. ══ */
  function _weekStartOf(d) {
    const dt = new Date(d); const day = (dt.getDay() + 6) % 7; // Monday=0, matches the rest of the app
    dt.setHours(0, 0, 0, 0); dt.setDate(dt.getDate() - day);
    return dt;
  }

  function _habitWeeklyTrend(habitId, target, weeks = 12) {
    const h = window.Habits?.load?.() || { log: {} };
    const now = new Date();
    const thisWeekStart = _weekStartOf(now);
    const out = [];
    for (let w = weeks - 1; w >= 0; w--) {
      const start = new Date(thisWeekStart); start.setDate(start.getDate() - w * 7);
      let count = 0, elapsedDays = 0;
      for (let d = 0; d < 7; d++) {
        const dt = new Date(start); dt.setDate(dt.getDate() + d);
        if (dt > now) continue;
        elapsedDays++;
        if ((h.log[dt.toDateString()] || []).includes(habitId)) count++;
      }
      const isCurrentWeek = w === 0;
      const denom = isCurrentWeek ? Math.max(1, Math.min(target, elapsedDays)) : target;
      out.push({ weekStart: start, count, pct: Math.min(100, Math.round((count / denom) * 100)) });
    }
    return out;
  }

  function _renderHabitTrendSvg(trend, colorVar) {
    const W = 280, H = 62, gap = 3;
    const n = trend.length;
    const barW = (W - gap * (n - 1)) / n;
    const bars = trend.map((wk, i) => {
      const x = i * (barW + gap);
      const barH = Math.max(2, (wk.pct / 100) * (H - 12));
      const y = H - 12 - barH;
      const label = wk.weekStart.toLocaleDateString("en", { month: "short", day: "numeric" });
      return `<rect x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${barW.toFixed(1)}" height="${barH.toFixed(1)}" rx="2" fill="var(${colorVar})" fill-opacity="${i === n - 1 ? 1 : 0.5}"><title>Week of ${label}: ${wk.pct}%</title></rect>`;
    }).join("");
    return `<svg viewBox="0 0 ${W} ${H}" width="100%" height="${H}" preserveAspectRatio="none">${bars}<line x1="0" y1="${H - 12}" x2="${W}" y2="${H - 12}" class="ins-trend-baseline"/></svg>`;
  }

  function _renderHabitTrendsPanel() {
    const h = window.Habits?.load?.();
    if (!h || !h.habits.length) return "";
    return h.habits.map(habit => {
      const trend = _habitWeeklyTrend(habit.id, habit.weeklyTarget || 7, 12);
      const recentWeeks = trend.slice(-4), earlierWeeks = trend.slice(0, -4);
      const avg = arr => arr.length ? Math.round(arr.reduce((s, w) => s + w.pct, 0) / arr.length) : null;
      const recentAvg = avg(recentWeeks), earlierAvg = avg(earlierWeeks);
      let note;
      if (recentAvg == null) note = "Not enough history yet to show a trend.";
      else if (earlierAvg == null) note = `Averaging ${recentAvg}% over the last few weeks — a few more and this'll show direction, not just a number.`;
      else {
        const diff = recentAvg - earlierAvg;
        note = diff >= 10 ? `Trending up — averaging ${recentAvg}% the last 4 weeks, up from ${earlierAvg}% before.`
          : diff <= -10 ? `Trending down — averaging ${recentAvg}% the last 4 weeks, down from ${earlierAvg}% before. Worth a look, not a verdict.`
          : `Holding steady around ${recentAvg}% over the last 4 weeks.`;
      }
      return `
        <div class="ins-trend-row">
          <div class="ins-trend-head"><span class="ins-trend-name">${ZG.esc(habit.name)}</span>${recentAvg != null ? `<span class="ins-trend-avg">${recentAvg}% recent</span>` : ""}</div>
          <div class="scroll-x">${_renderHabitTrendSvg(trend, "--accent")}</div>
          <p class="fine-print" style="margin:6px 2px 0">${note}</p>
        </div>`;
    }).join("");
  }

  /* ═══════════════════════ CRAVING TRENDS ═══════════════════════
     Same Monday-aligned weekly-bucket idea as habit trends above,
     applied to Recovery: how often urges/resets show up per tracker,
     and what share of those logged moments were resisted. Stacked
     bar per week — accent segment = resisted, danger segment = reset —
     so frequency and outcome both read at a glance. */
  function _recoveryWeeklyTrend(trackerId, weeks = 12) {
    const rec = window.Recovery?.load?.() || { trackers: {} };
    const t = rec.trackers[trackerId];
    if (!t) return [];
    const now = new Date();
    const thisWeekStart = _weekStartOf(now);
    const out = [];
    for (let w = weeks - 1; w >= 0; w--) {
      const start = new Date(thisWeekStart); start.setDate(start.getDate() - w * 7);
      const end = new Date(start); end.setDate(end.getDate() + 7);
      const s = start.getTime(), e = end.getTime();
      const urgeCount = (t.urges || []).filter(u => u.ts >= s && u.ts < e).length;
      const relapseCount = (t.relapses || []).filter(r => r.ts >= s && r.ts < e).length;
      out.push({ weekStart: start, urgeCount, relapseCount, total: urgeCount + relapseCount });
    }
    return out;
  }

  function _renderRecoveryTrendSvg(trend, colorVar) {
    const W = 280, H = 62, gap = 3;
    const n = trend.length;
    const barW = (W - gap * (n - 1)) / n;
    const maxTotal = Math.max(1, ...trend.map(w => w.total));
    const baseY = H - 12;
    const scale = (H - 12) / maxTotal;
    const bars = trend.map((wk, i) => {
      const x = i * (barW + gap);
      const label = wk.weekStart.toLocaleDateString("en", { month: "short", day: "numeric" });
      const relapseH = wk.relapseCount * scale;
      const urgeH = wk.urgeCount * scale;
      const relapseY = baseY - relapseH;
      const urgeY = relapseY - urgeH;
      let rects = "";
      if (wk.relapseCount > 0) {
        rects += `<rect x="${x.toFixed(1)}" y="${relapseY.toFixed(1)}" width="${barW.toFixed(1)}" height="${Math.max(2, relapseH).toFixed(1)}" rx="1.5" fill="var(--danger)" fill-opacity="${i === n - 1 ? 1 : 0.55}"><title>Week of ${label}: ${wk.relapseCount} reset${wk.relapseCount === 1 ? "" : "s"}</title></rect>`;
      }
      if (wk.urgeCount > 0) {
        rects += `<rect x="${x.toFixed(1)}" y="${urgeY.toFixed(1)}" width="${barW.toFixed(1)}" height="${Math.max(2, urgeH).toFixed(1)}" rx="1.5" fill="var(${colorVar})" fill-opacity="${i === n - 1 ? 1 : 0.5}"><title>Week of ${label}: ${wk.urgeCount} resisted</title></rect>`;
      }
      return rects;
    }).join("");
    return `<svg viewBox="0 0 ${W} ${H}" width="100%" height="${H}" preserveAspectRatio="none">${bars}<line x1="0" y1="${baseY}" x2="${W}" y2="${baseY}" class="ins-trend-baseline"/></svg>`;
  }

  function _renderRecoveryTrendsPanel() {
    const rec = window.Recovery?.load?.() || { trackers: {} };
    const ids = Object.keys(rec.trackers);
    if (!ids.length) return "";
    const rows = ids.map(id => {
      const type = window.Recovery.TYPES[id];
      if (!type) return "";
      const trend = _recoveryWeeklyTrend(id, 12);
      const recentWeeks = trend.slice(-4), earlierWeeks = trend.slice(0, -4);
      const avgTotal = arr => arr.length ? Math.round((arr.reduce((s, w) => s + w.total, 0) / arr.length) * 10) / 10 : null;
      const recentAvg = avgTotal(recentWeeks), earlierAvg = avgTotal(earlierWeeks);
      const resistPct = weeks => { const u = weeks.reduce((s, w) => s + w.urgeCount, 0); const tot = weeks.reduce((s, w) => s + w.total, 0); return tot ? Math.round((u / tot) * 100) : null; };
      const recentResist = resistPct(recentWeeks);
      let note;
      if (!recentAvg && !earlierAvg) note = "Not enough logged activity yet to show a trend.";
      else if (earlierAvg == null) note = `Averaging ${recentAvg} logged moment${recentAvg === 1 ? "" : "s"}/week so far${recentResist != null ? `, ${recentResist}% resisted` : ""} — a few more weeks and this'll show direction.`;
      else {
        const diff = recentAvg - earlierAvg;
        note = Math.abs(diff) < 0.5
          ? `Holding steady — about ${recentAvg} logged moment${recentAvg === 1 ? "" : "s"}/week${recentResist != null ? `, ${recentResist}% resisted` : ""}.`
          : diff < 0
            ? `Showing up less often lately — down to ${recentAvg}/week from ${earlierAvg}/week${recentResist != null ? `, ${recentResist}% resisted` : ""}.`
            : `Showing up more often lately — ${recentAvg}/week vs ${earlierAvg}/week before${recentResist != null ? `, still ${recentResist}% resisted` : ""}. Worth a look, not a verdict.`;
      }
      return `
        <div class="ins-trend-row">
          <div class="ins-trend-head"><span class="ins-trend-name">${ZG.esc(type.label)}</span>${recentResist != null ? `<span class="ins-trend-avg">${recentResist}% resisted</span>` : ""}</div>
          <div class="scroll-x">${_renderRecoveryTrendSvg(trend, type.colorVar)}</div>
          <p class="fine-print" style="margin:6px 2px 0">${note}</p>
        </div>`;
    }).join("");
    if (!rows) return "";
    return `<p class="fine-print" style="margin-top:0">Bar height is logged moments per week — the colored segment marks a reset.</p>${rows}`;
  }

  /* ═══════════════════════ WEEKLY CHECK-IN TREND ═══════════════════════
     Reads Vitals' weekly self-rated craving/mood/energy pulse (see
     vitals.js) and turns it into an actual trend instead of a lone
     number — "am I actually getting better" needs a baseline to compare
     against, which per-event Insights rows above don't give on their own.
     Bar height is craving strength (taller = harder week); mood/energy
     ride along in the tooltip and the summary line rather than a second
     set of bars, to keep this one readable at this size. ══════════════ */
  function _renderVitalsTrendSvg(entries) {
    const W = 280, H = 70, gap = 3;
    const n = entries.length;
    const barW = (W - gap * (n - 1)) / n;
    const bars = entries.map((e, i) => {
      const x = i * (barW + gap);
      const barH = Math.max(2, (e.craving / 10) * (H - 14));
      const y = H - 12 - barH;
      const label = new Date(e.weekKey).toLocaleDateString("en", { month: "short", day: "numeric" });
      return `<rect x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${barW.toFixed(1)}" height="${barH.toFixed(1)}" rx="2" fill="var(--danger)" fill-opacity="${i === n - 1 ? 0.9 : 0.45}"><title>Week of ${label}: craving ${e.craving}/10, mood ${e.mood}/10, energy ${e.energy}/10</title></rect>`;
    }).join("");
    return `<svg viewBox="0 0 ${W} ${H}" width="100%" height="${H}" preserveAspectRatio="none">${bars}<line x1="0" y1="${H - 12}" x2="${W}" y2="${H - 12}" class="ins-trend-baseline"/></svg>`;
  }

  function _renderVitalsTrendsPanel() {
    const entries = (window.Vitals?.load?.() || []).slice().sort((a, b) => a.ts - b.ts).slice(-8);
    if (entries.length < 2) return "";
    const first = entries[0], last = entries[entries.length - 1];
    const cravingDiff = last.craving - first.craving;
    const moodDiff = last.mood - first.mood;
    let note;
    if (entries.length < 3) {
      note = `${entries.length} check-ins logged so far — a few more and this'll show real direction.`;
    } else {
      const cravingDir = cravingDiff <= -1 ? "trending down" : cravingDiff >= 1 ? "trending up" : "holding steady";
      const moodDir = moodDiff >= 1 ? "trending up" : moodDiff <= -1 ? "trending down" : "holding steady";
      note = `Craving ${cravingDir} (${first.craving} \u2192 ${last.craving}/10), mood ${moodDir} (${first.mood} \u2192 ${last.mood}/10) over ${entries.length} check-ins.`;
    }
    return `<div class="scroll-x">${_renderVitalsTrendSvg(entries)}</div><p class="fine-print" style="margin:6px 2px 0">${note} Bar height is craving strength — taller means a harder week.</p>`;
  }

  function _renderRiskWindowsPanel(rw) {
    const CONF_LABEL = { high: "Clearly stands out", medium: "A real but softer signal", low: "Worth noting, less certain" };
    const rows = rw.windows.map((w, i) => `
      <div class="ins-risk-row${i === 0 ? " ins-risk-row-top" : ""}">
        <span class="ins-risk-when"><b>${ZG.esc(w.dayLabel)}s</b> around ${ZG.esc(w.hourLabel)}</span>
        <span class="ins-risk-conf ins-risk-conf-${w.confidence}">${CONF_LABEL[w.confidence]}</span>
      </div>`).join("");
    return `
      <p class="fine-print" style="margin:0 0 10px">Weighted by how often urges/resets land here AND how recently — a pattern that's fading gets quieter over time instead of staying permanently as loud as the day it happened.</p>
      ${rows}
      <p class="fine-print" style="margin-top:10px">${window.ZG?.riskRemindersEnabled?.() ? "A local reminder is set for the top window above — change this anytime in Settings." : "Turn on \u201CRisk-window check-ins\u201D in Settings for a local reminder timed to the top window — nothing leaves your device."}</p>`;
  }

  function render() {
    const body = document.getElementById("insightsBody");
    if (!body) return;
    const r = compute();
    if (r.insufficient) {
      body.innerHTML = `<div class="card"><p class="empty-note" style="padding:30px 10px">A few more habit check-ins or recovery moments and this section starts reading your own patterns back to you — no guessing, just what actually happened.</p></div>`;
      return;
    }
    const hasEvents = r.events.length > 0;
    const habitTrendsHtml = _renderHabitTrendsPanel();
    const recoveryTrendsHtml = _renderRecoveryTrendsPanel();
    const vitalsTrendsHtml = _renderVitalsTrendsPanel();
    body.innerHTML = `
      <div class="gr-label">Growth Radar</div>
      <div class="card gr-block">${_renderRadarPanel(r.radar)}</div>

      ${habitTrendsHtml ? `
      <div class="gr-label">Habit trends</div>
      <div class="card gr-block">${habitTrendsHtml}</div>` : ""}

      ${recoveryTrendsHtml ? `
      <div class="gr-label">Craving trends</div>
      <div class="card gr-block">${recoveryTrendsHtml}</div>` : ""}

      ${vitalsTrendsHtml ? `
      <div class="gr-label">Weekly check-in trend</div>
      <div class="card gr-block">${vitalsTrendsHtml}</div>` : ""}

      <div class="gr-label">Identity DNA</div>
      <div class="card gr-block">${_renderDnaPanel(r.dna)}</div>

      <div class="card gr-block">
        <div class="card-eyebrow">What the data says</div>
        <div class="ins-row-list">${_insightRows(r).map(i => `<div class="ins-row ins-${i.type}">${ZG.esc(i.text)}</div>`).join("")}</div>
        ${!window.Context?.isEnabled?.() ? `<p class="fine-print" style="margin-top:10px">Want sleep- and weather-based patterns here too? Turn on Sleep &amp; context tracking in Settings — it's optional, and stays on this device like everything else.</p>` : ""}
      </div>

      ${r.riskWindows ? `
      <div class="gr-label">Highest-risk windows</div>
      <div class="card gr-block ins-risk-card">
        ${_renderRiskWindowsPanel(r.riskWindows)}
      </div>` : ""}

      ${hasEvents ? `
      <div class="gr-label">When urges &amp; resets happen</div>
      <div class="card gr-block">
        <div class="scroll-x">${_renderHeatmap(r.heatmap)}</div>
        <p class="fine-print" style="margin-top:8px">Darker = more logged moments at that hour. This is about awareness, not blame.</p>
      </div>` : ""}
    `;
  }

  ZG.sectionRenderers.habits = (() => {
    const prev = ZG.sectionRenderers.habits; // habits' own renderer, already set
    return () => { prev?.(); render(); };
  })();
  // Rendered on demand the first time Habits is opened, not on every page
  // load — see the matching note in journal.js. compute() alone (radar,
  // heatmap, correlations) is real work worth skipping until it's visible.

  return { compute, render };
})();
window.Insights = Insights;
