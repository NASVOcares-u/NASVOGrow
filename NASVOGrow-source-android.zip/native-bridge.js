"use strict";
/* ═══════════════════════════════════════════════════════════════
   NATIVE BRIDGE (v2) — the one seam between this web app and the
   Capacitor Android shell. Every function here checks for a native
   runtime first and quietly no-ops (or returns false) in a normal
   browser tab / PWA, so loading this file changes nothing there.

   No bundler, matching the rest of the app: Capacitor exposes native
   plugins on window.Capacitor.Plugins, so there is nothing to import.

   What lives here (all of it local to the device — no server):
     • notifications  — scheduled in advance with the OS alarm system,
                        so they fire with the app closed; channels and
                        action buttons; tap/action routing back into
                        the app (ZG.routeTo, see app.js)
     • back button, resume/pause events, deep links (nasvogrow://…)
     • export / share  — write to cache, open the Android share sheet
     • automatic backup to Documents/NASVOGrow (survives uninstall)
     • haptics, system-bar style, privacy screen, biometric unlock,
       home-screen widget snapshot (via the NasvoNative plugin)

   "Decide when to remind" stays in native-app.js / app.js; this file
   is only "how to deliver it".
═══════════════════════════════════════════════════════════════ */
const NativeBridge = (() => {
  const cap = () => window.Capacitor || null;

  function isNative() {
    const c = cap();
    return !!(c && typeof c.isNativePlatform === "function" && c.isNativePlatform());
  }

  const _reg = {};
  /** A native plugin proxy, or null when it isn't installed in this build. */
  function plug(name) {
    const c = cap();
    if (!c || !isNative()) return null;
    try {
      if (typeof c.isPluginAvailable === "function" && !c.isPluginAvailable(name)) return null;
      return c.Plugins?.[name] || (_reg[name] ||= c.registerPlugin?.(name)) || null;
    } catch { return null; }
  }
  const quiet = (p) => { try { Promise.resolve(p).catch(() => {}); } catch {} };

  /* ───────────────────────── notifications ───────────────────────── */
  const CH_HABITS = "nasvo_habits";
  const CH_RECOVERY = "nasvo_recovery";
  const ID_EVENING = 1000;   // 1000..1099 — one per upcoming evening
  const ID_RISK = 2000;      // 2000..2099 — one per weekly risk window
  const inOurRange = (id) => (id >= 1000 && id <= 1099) || (id >= 2000 && id <= 2099) || id === 1 || id === 2;

  let _setupP = null;
  function _setup() {
    return (_setupP ||= (async () => {
      const ln = plug("LocalNotifications");
      if (!ln) return;
      try {
        // Channel settings can't be changed by the app once created, so keep these conservative.
        await ln.createChannel({ id: CH_HABITS, name: "Habit reminders", description: "A gentle evening nudge if today is still open", importance: 3, visibility: 1 });
        // visibility 0 = private: on a locked phone Android hides the contents of these.
        await ln.createChannel({ id: CH_RECOVERY, name: "Check-ins", description: "Quiet check-ins around your own harder hours", importance: 3, visibility: 0 });
        await ln.registerActionTypes({ types: [
          { id: "nasvo_habits", actions: [{ id: "open_habits", title: "Open habits" }] },
          { id: "nasvo_risk", actions: [{ id: "ride_it_out", title: "Ride it out" }, { id: "quick_journal", title: "Journal" }] },
        ] });
      } catch { _setupP = null; }
    })());
  }

  async function requestPermission() {
    const ln = plug("LocalNotifications");
    if (!ln) return false;
    try { return (await ln.requestPermissions())?.display === "granted"; } catch { return false; }
  }

  async function hasPermission() {
    const ln = plug("LocalNotifications");
    if (!ln) return false;
    try { return (await ln.checkPermissions())?.display === "granted"; } catch { return false; }
  }

  /** Immediate notification (kept for the web-style "send now" path). */
  async function notifyNow({ id, title, body }) {
    const ln = plug("LocalNotifications");
    if (!ln) return false;
    try {
      await _setup();
      await ln.schedule({ notifications: [{ id: id ?? 1, title, body, channelId: CH_HABITS, isExactNotification: false, schedule: { at: new Date(Date.now() + 500) } }] });
      return true;
    } catch { return false; }
  }

  async function _cancelOurs() {
    const ln = plug("LocalNotifications");
    if (!ln) return;
    const pending = (await ln.getPending())?.notifications || [];
    const mine = pending.filter((n) => inOurRange(n.id)).map((n) => ({ id: n.id }));
    if (mine.length) await ln.cancel({ notifications: mine });
  }

  let _chain = Promise.resolve();
  /** Replace every reminder this app has scheduled with `plan`.
   *  plan = { title:{habits,recovery}, evening:[{n,at(ms),body}], risk:[{n,weekday(1=Sun..7=Sat),hour,minute,body}] }
   *  Calls are serialised so two quick syncs can't interleave cancel/schedule. */
  function syncReminders(plan) {
    _chain = _chain.then(async () => {
      const ln = plug("LocalNotifications");
      if (!ln) return false;
      try {
        await _setup();
        await _cancelOurs();
        const t = plan?.title || {};
        const list = [];
        for (const e of plan?.evening || []) {
          list.push({
            id: ID_EVENING + e.n, title: t.habits || "NASVOGrow", body: e.body,
            channelId: CH_HABITS, actionTypeId: "nasvo_habits", autoCancel: true,
            isExactNotification: false,                       // never send people to "Alarms & reminders" settings
            extra: { route: { section: "habits" } },
            schedule: { at: new Date(e.at), allowWhileIdle: true },
          });
        }
        for (const r of plan?.risk || []) {
          list.push({
            id: ID_RISK + r.n, title: t.recovery || "Reminder", body: r.body,
            channelId: CH_RECOVERY, actionTypeId: "nasvo_risk", autoCancel: true,
            isExactNotification: false,
            extra: { route: { section: "recovery" } },
            schedule: { on: { weekday: r.weekday, hour: r.hour, minute: r.minute || 0 }, allowWhileIdle: true },
          });
        }
        if (list.length) await ln.schedule({ notifications: list });
        return true;
      } catch { return false; }
    });
    return _chain;
  }

  function cancelReminders() {
    _chain = _chain.then(async () => { try { await _cancelOurs(); } catch {} return true; });
    return _chain;
  }

  /* ───────────── routing: notification taps, deep links, back ───────────── */
  let _pendingRoute = null;
  function _route(section, action) {
    _pendingRoute = { section, action };
    flushRoute();
  }
  /** app.js sets ZG.routeReady once first paint logic has run; until then a
   *  route from a cold-start notification/shortcut waits here. */
  function flushRoute() {
    if (!_pendingRoute || !window.ZG?.routeReady || typeof ZG.routeTo !== "function") return;
    const { section, action } = _pendingRoute;
    _pendingRoute = null;
    ZG.routeTo(section, action);
  }

  function _routeFromUrl(url) {
    try {
      const u = new URL(url);
      const section = u.searchParams.get("section");
      const action = u.searchParams.get("action");
      if (section || action) _route(section || "home", action || undefined);
    } catch {}
  }

  let _lastBack = 0;
  function _onBack() {
    if (window.ZG?.handleBack?.()) return;                    // closed a sheet / went Home
    const now = Date.now();
    if (now - _lastBack < 1800 || document.getElementById("zrLockModal")) { quiet(plug("App")?.exitApp?.()); return; }
    _lastBack = now;
    window.ZG?.toast?.("Press back again to exit");
  }

  /* ───────────────────────────── sharing / export ───────────────────────────── */
  async function saveFile({ filename, mime, text, base64, title }) {
    const fs = plug("Filesystem"), share = plug("Share");
    if (!fs || !share) return { ok: false, reason: "unavailable" };
    try {
      const args = { path: `export/${filename}`, directory: "CACHE", recursive: true };
      if (base64 != null) args.data = base64; else { args.data = text ?? ""; args.encoding = "utf8"; }
      const { uri } = await fs.writeFile(args);
      await share.share({ title: title || filename, dialogTitle: "Save or share", url: uri });
      return { ok: true, uri };
    } catch (e) {
      return { ok: false, reason: /cancel/i.test(String(e?.message || e)) ? "cancelled" : "failed" };
    }
  }

  /** Exports sit in the app's cache until now; journal text shouldn't linger there. */
  function _cleanupExports() {
    quiet(plug("Filesystem")?.rmdir?.({ path: "export", directory: "CACHE", recursive: true }));
  }

  /** WebView has no reliable Web Share API; give the app's existing
   *  navigator.share() call sites the real Android share sheet. */
  function _installSharePolyfill() {
    const share = plug("Share");
    if (!share) return;
    try {
      Object.defineProperty(navigator, "share", {
        configurable: true,
        value: (d) => share.share({ title: d?.title, text: d?.text, url: d?.url, dialogTitle: d?.title }).then(() => undefined),
      });
    } catch {}
  }

  /* ───────────────────── automatic backup (Documents) ───────────────────── */
  async function saveBackup(filename, text) {
    const p = plug("NasvoNative");
    if (!p) return { ok: false, message: "unavailable" };
    try { await p.saveBackupFile({ filename, text }); return { ok: true }; }
    catch (e) { return { ok: false, message: String(e?.message || e) }; }
  }
  async function pruneBackups(prefix, keep) {
    const p = plug("NasvoNative");
    if (!p) return;
    try { await p.pruneBackups({ prefix, keep }); } catch {}
  }
  const canBackupToDocuments = () => !!plug("NasvoNative");

  /* ───────────────────────── feel & chrome ───────────────────────── */
  /** @returns true when a native haptic was fired */
  function haptic(kind) {
    const h = plug("Haptics");
    if (!h) return false;
    quiet(kind === "success" ? h.notification({ type: "SUCCESS" }) : h.impact({ style: kind === "soft" ? "LIGHT" : "MEDIUM" }));
    return true;
  }

  const LIGHT_THEMES = ["light", "dune"];
  function setSystemBars(theme) {
    // SystemBars: "DARK" = light icons for a dark page, "LIGHT" = dark icons for a light page.
    quiet(plug("SystemBars")?.setStyle?.({ style: LIGHT_THEMES.includes(theme) ? "LIGHT" : "DARK" }));
  }

  const privacyScreenAvailable = () => !!plug("PrivacyScreen");
  async function setPrivacyScreen(on) {
    const p = plug("PrivacyScreen");
    if (!p) return false;
    try { if (on) await p.enable({ android: { preventScreenshots: true } }); else await p.disable(); return true; }
    catch { return false; }
  }

  async function biometricAvailable() {
    const p = plug("NasvoNative");
    if (!p) return false;
    try { return !!(await p.biometricStatus())?.available; } catch { return false; }
  }
  async function biometricAuth({ title, subtitle, cancel } = {}) {
    const p = plug("NasvoNative");
    if (!p) return false;
    try { await p.biometricAuthenticate({ title: title || "Unlock", subtitle: subtitle || "", cancel: cancel || "Use PIN" }); return true; }
    catch { return false; }
  }

  /** Today's numbers for the home-screen widget. Habits and streak only — nothing from Recovery. */
  function pushWidget(snapshot) { quiet(plug("NasvoNative")?.updateWidget?.(snapshot)); }

  /* ───────────────────────────── lifecycle ───────────────────────────── */
  let _inited = false;
  function init() {
    if (_inited || !isNative()) return;
    _inited = true;
    document.documentElement.classList.add("is-native");
    _installSharePolyfill();
    _cleanupExports();
    quiet(_setup());

    const app = plug("App");
    if (app) {
      quiet(app.addListener("backButton", _onBack));
      quiet(app.addListener("appStateChange", ({ isActive }) => window.dispatchEvent(new Event(isActive ? "nasvo:resume" : "nasvo:pause"))));
      quiet(app.addListener("appUrlOpen", ({ url }) => _routeFromUrl(url)));
      quiet(Promise.resolve(app.getLaunchUrl?.()).then((r) => { if (r?.url) _routeFromUrl(r.url); }));
    }
    const ln = plug("LocalNotifications");
    if (ln) {
      quiet(ln.addListener("localNotificationActionPerformed", (ev) => {
        const route = ev?.notification?.extra?.route || {};
        if (ev?.actionId === "ride_it_out") _route("recovery", "rideitout");
        else if (ev?.actionId === "quick_journal") _route("recovery", "journal");
        else _route(route.section || "home", route.action);
      }));
    }
  }
  init();

  return {
    isNative, plug, init, flushRoute,
    requestPermission, hasPermission, notifyNow, syncReminders, cancelReminders,
    saveFile, saveBackup, pruneBackups, canBackupToDocuments,
    haptic, setSystemBars, setPrivacyScreen, privacyScreenAvailable,
    biometricAvailable, biometricAuth, pushWidget,
  };
})();
window.NativeBridge = NativeBridge;
