"use strict";
/* ═══════════════════════════════════════════════════════════════
   NASVOGROW — Core
   Everything here is local-only (localStorage). No accounts, no
   servers, no fake sync — see the Settings fine print.
═══════════════════════════════════════════════════════════════ */

/* ── Storage helper ── */
const Store = {
  get(key, fallback) {
    try { const v = localStorage.getItem(key); return v !== null ? JSON.parse(v) : fallback; }
    catch { return fallback; }
  },
  set(key, val) { try { localStorage.setItem(key, JSON.stringify(val)); } catch {} },
};

/* ── Global namespace ── */
const ZG = (window.ZG = window.ZG || {});
ZG.sectionRenderers = {}; // populated by each module: ZG.sectionRenderers.habits = fn

/* ─────────────────────────────────────────────────────────────
   FEEDBACK PRIMITIVES — motion, haptics, count-up, burst
   Everything here is a no-op under prefers-reduced-motion or Calm mode, so
   polish never costs the people who need the app to stay quiet.
   ───────────────────────────────────────────────────────────── */
// Read the media query ONCE (evaluating it right after DOM writes can force a style flush) and keep it current via its change event.
const _reduceMq = matchMedia("(prefers-reduced-motion: reduce)");
let _reduceMotion = _reduceMq.matches;
_reduceMq.addEventListener?.("change", (e) => { _reduceMotion = e.matches; });
ZG.motionOK = () => !_reduceMotion && !document.body.classList.contains("calm-mode");
ZG.hapticsEnabled = () => Store.get("zg_haptics", true) !== false && !document.body.classList.contains("calm-mode");
ZG.haptic = (kind = "tap") => {
  if (!ZG.hapticsEnabled()) return;
  if (window.NativeBridge?.isNative?.() && NativeBridge.haptic(kind)) return;   // Android shell: real haptics
  if (typeof navigator.vibrate !== "function") return;
  try { navigator.vibrate(kind === "success" ? [14, 50, 22] : kind === "soft" ? 6 : 10); } catch { /* unsupported */ }
};
/** Set a numeric readout; counts up/down when it changes after first paint. */
ZG.setNum = (el, v) => {
  if (!el) return;
  const to = Number(v), from = Number(el.dataset.n);
  el.dataset.n = String(v);
  cancelAnimationFrame(el._numRaf);
  if (!Number.isFinite(to) || !Number.isFinite(from) || from === to || !ZG.motionOK()) { el.textContent = String(v); return; }
  const t0 = performance.now(), dur = Math.min(700, 220 + Math.abs(to - from) * 12);
  const step = (now) => {
    const k = Math.min(1, (now - t0) / dur), e = 1 - Math.pow(1 - k, 3);
    el.textContent = String(Math.round(from + (to - from) * e));
    if (k < 1) el._numRaf = requestAnimationFrame(step); else el.textContent = String(v);
  };
  el._numRaf = requestAnimationFrame(step);
};
/** Small confetti-style burst from a DOMRect. */
ZG.burst = (rect, n = 10) => {
  if (!rect || !ZG.motionOK()) return;
  const wrap = document.createElement("div");
  wrap.className = "burst"; wrap.setAttribute("aria-hidden", "true");
  wrap.style.left = rect.left + rect.width / 2 + "px"; wrap.style.top = rect.top + rect.height / 2 + "px";
  const colors = ["var(--accent)", "var(--gold)", "var(--clay)"];
  for (let i = 0; i < n; i++) {
    const p = document.createElement("i"), a = (Math.PI * 2 * i) / n + Math.random() * 0.6, d = 30 + Math.random() * (n > 12 ? 80 : 36);
    p.style.cssText = `background:${colors[i % 3]};--dx:${(Math.cos(a) * d).toFixed(0)}px;--dy:${(Math.sin(a) * d - 12).toFixed(0)}px;--rot:${(Math.random() * 360 - 180).toFixed(0)}deg`;
    wrap.appendChild(p);
  }
  document.body.appendChild(wrap);
  setTimeout(() => wrap.remove(), 950);
};
// Remember where the last habit was tapped (pointer or keyboard) so the burst starts there.
["click", "keydown"].forEach((evt) => document.addEventListener(evt, (e) => {
  if (evt === "keydown" && e.key !== " " && e.key !== "Enter") return;
  const t = e.target.closest?.(".habit-check, .today-row");
  if (t) ZG._tapRect = { r: t.getBoundingClientRect(), at: Date.now() };
}, true));
/** Called by Habits.toggle when something is checked ON. */
ZG.celebrateCheck = (allDone) => {
  const tap = ZG._tapRect && Date.now() - ZG._tapRect.at < 900 ? ZG._tapRect.r : null;
  ZG.haptic(allDone ? "success" : "tap");
  if (tap) ZG.burst(tap, allDone ? 24 : 8);
};

/* ─────────────────────────────────────────────────────────────
   TODAY CARD (Home): the one thing to do, right where you land.
   The last rendering is cached (zg_today_cache) and restored by an inline
   script in index.html before first paint, so there is no layout jump.
   ───────────────────────────────────────────────────────────── */
ZG.renderTodayCard = function () {
  const el = document.getElementById("todayCard");
  if (!el || !window.Habits) return;
  const d = Habits.load(), done = new Set((d.log || {})[_today()] || []), habits = d.habits || [];
  const total = habits.length, doneN = habits.filter((h) => done.has(h.id)).length, all = total > 0 && doneN === total;
  const C = 2 * Math.PI * 18, prev = ZG._todayPrev, target = total ? (doneN / total) * C : 0;
  let html;
  if (!total) {
    html = `<div class="today-head"><div><div class="card-eyebrow" id="todayEyebrow">Today</div><div class="today-count">Start with one small habit</div></div></div>
      <div class="today-empty"><p>One tiny, repeatable thing beats a perfect plan. It takes ten seconds to add.</p>
      <button type="button" class="btn-primary" data-today="add">Add your first habit</button></div>`;
  } else {
    const rows = habits.slice(0, 4).map((h) => {
      const isDone = done.has(h.id), st = Habits.streakFor(h.id);
      return `<li><button type="button" class="today-row${isDone ? " done" : ""}${ZG._justDone === h.id ? " just-done" : ""}" role="checkbox" aria-checked="${isDone}" data-habit="${ZG.esc(h.id)}">
        <span class="today-check" aria-hidden="true">${isDone ? window.Icons?.svg("check", 2.2) || "" : ""}</span>
        <span class="today-name">${ZG.esc(h.name)}</span>${st > 1 ? `<span class="today-streak">${st}d</span>` : ""}</button></li>`;
    }).join("");
    const rest = habits.slice(4).filter((h) => !done.has(h.id)).length;
    html = `<div class="today-head"><div><div class="card-eyebrow" id="todayEyebrow">Today</div>
        <div class="today-count">${all ? "All done" : `${doneN} of ${total}`} <small>${all ? "\u2014 nice work" : total === 1 ? "habit" : "habits"}</small></div></div>
      <svg class="today-ring" viewBox="0 0 44 44" aria-hidden="true"><circle cx="22" cy="22" r="18" fill="none" stroke="var(--accent)" stroke-opacity=".2" stroke-width="5"/>
        <circle class="today-ring-arc" data-to="${target.toFixed(1)} ${C.toFixed(1)}" cx="22" cy="22" r="18" fill="none" stroke="var(--accent)" stroke-width="5" stroke-linecap="round"
          stroke-dasharray="${(ZG.motionOK() && prev != null ? prev : target).toFixed(1)} ${C.toFixed(1)}" transform="rotate(-90 22 22)"/></svg></div>
      <ul class="today-list">${rows}</ul>
      <div class="today-foot"><span class="fine-print" style="margin:0">${rest ? `${rest} more to go` : ""}</span><button type="button" class="today-cta" data-today="goto">All habits \u2192</button></div>`;
  }
  if (el._html !== html) { el.innerHTML = html; el._html = html; }
  ZG._todayPrev = target;
  const arc = el.querySelector(".today-ring-arc");
  if (arc && arc.getAttribute("stroke-dasharray") !== arc.dataset.to) requestAnimationFrame(() => requestAnimationFrame(() => arc.setAttribute("stroke-dasharray", arc.dataset.to)));
  Store.set("zg_today_cache", { day: _today(), html: html.replace(/ just-done/g, "") });
};
document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("todayCard")?.addEventListener("click", (e) => {
    const row = e.target.closest(".today-row");
    if (row) { window.Habits?.toggle(row.dataset.habit); return; }
    const a = e.target.closest("[data-today]");
    if (!a) return;
    ZG.showSection("habits");
    if (a.dataset.today === "add") setTimeout(() => window.Habits?.openAddSheet?.(), 80);
  });

  // Haptics switch + "Install app" row (Settings)
  const ht = document.getElementById("hapticsToggle"), hRow = document.getElementById("hapticsRow");
  if (hRow && typeof navigator.vibrate !== "function" && !window.NativeBridge?.isNative?.()) hRow.hidden = true;   // e.g. iOS Safari has no Vibration API
  const syncHaptics = () => { const on = Store.get("zg_haptics", true) !== false; ht?.classList.toggle("on", on); ht?.setAttribute("aria-checked", String(on)); };
  syncHaptics();
  ht?.addEventListener("click", () => { Store.set("zg_haptics", Store.get("zg_haptics", true) === false); syncHaptics(); ZG.haptic("tap"); });

  let installEvt = null;
  const standalone = () => matchMedia("(display-mode: standalone)").matches || navigator.standalone === true;
  const iosHint = /iphone|ipad|ipod/i.test(navigator.userAgent) && !standalone();
  const syncInstall = () => {
    const row = document.getElementById("installRow"), btn = document.getElementById("installBtn"), sub = document.getElementById("installSub");
    if (!row) return;
    row.hidden = standalone() || !!window.NativeBridge?.isNative?.() || !(installEvt || iosHint);
    if (!installEvt && iosHint) { sub.textContent = "In Safari: tap the Share button, then \u201CAdd to Home Screen\u201D."; btn.hidden = true; } else btn.hidden = false;
  };
  addEventListener("beforeinstallprompt", (e) => { e.preventDefault(); installEvt = e; syncInstall(); });
  addEventListener("appinstalled", () => { installEvt = null; syncInstall(); ZG.toast("Installed \u2014 find NASVOGrow on your home screen"); });
  document.getElementById("installBtn")?.addEventListener("click", async () => {
    if (!installEvt) return;
    installEvt.prompt(); await installEvt.userChoice.catch(() => {}); installEvt = null; syncInstall();
  });
  syncInstall();
});

/* ─────────────────────────────────────────────────────────────
   SHEETS: swipe down to dismiss (phones). Works on every .modal and on form-style
   dialogs that have a Cancel/Close button. Drag only starts when the sheet is
   scrolled to its top, so normal scrolling and sliders are never hijacked.
   ───────────────────────────────────────────────────────────── */
(function sheetSwipe() {
  const dismissOf = (sheet) => {
    if (sheet.classList.contains("modal")) return () => ZG.closeModal(sheet.id);
    const btn = sheet.querySelector('[id$="Cancel"], [id$="Close"], [data-sheet-close]');
    return btn ? () => btn.click() : null;
  };
  document.addEventListener("touchstart", (e) => {
    if (!matchMedia("(max-width:639px)").matches || e.touches.length !== 1) return;
    const sheet = e.target.closest(".modal.show, .celebrate-card");
    if (!sheet || e.target.closest("input[type=range], textarea, select")) return;
    const dismiss = dismissOf(sheet);
    if (!dismiss) return;
    const base = sheet.classList.contains("modal") ? "translateX(-50%) " : "";
    const st = { y0: e.touches[0].clientY, dy: 0, t0: performance.now(), on: false };
    const move = (ev) => {
      const dy = ev.touches[0].clientY - st.y0;
      if (!st.on) { if (dy > 8 && sheet.scrollTop <= 0) { st.on = true; sheet.style.transition = "none"; } else if (dy < -8) return end(true); else return; }
      ev.preventDefault();
      st.dy = Math.max(0, dy);
      sheet.style.transform = `${base}translateY(${st.dy}px)`;
    };
    const end = (cancel) => {
      sheet.removeEventListener("touchmove", move); sheet.removeEventListener("touchend", end); sheet.removeEventListener("touchcancel", end);
      if (!st.on) return;
      const v = st.dy / Math.max(1, performance.now() - st.t0);
      sheet.style.transition = "";
      // dismiss on a long drag, or on a real flick that also travelled a meaningful distance
      if (!cancel && (st.dy > 110 || (st.dy > 60 && v > 0.8))) { sheet.style.transform = ""; ZG.haptic("soft"); dismiss(); }
      else sheet.style.transform = "";
    };
    sheet.addEventListener("touchmove", move, { passive: false });
    sheet.addEventListener("touchend", () => end(false), { passive: true });
    sheet.addEventListener("touchcancel", () => end(true), { passive: true });
  }, { passive: true });
})();

/* ─────────────────────────────────────────────────────────────
   ON-DEMAND FEATURE STYLES
   styles.css (inlined by the production build) carries everything the Home
   screen needs for first paint. styles-extra.css — Habits, Recovery, Growth,
   modal/drawer contents, lock screen, etc. — is fetched only when it is first
   needed: a first user interaction, a section switch, a modal opening, or an
   overlay being appended to <body>. In an un-built checkout the extra sheet is a
   normal <link data-extra> in index.html, so everything is simply ready at once.
   ───────────────────────────────────────────────────────────── */
ZG.extraCssReady = !!document.querySelector("link[data-extra]");
ZG.ensureExtraCss = (() => {
  let pending = null;
  return function () {
    if (ZG.extraCssReady) return Promise.resolve();
    if (pending) return pending;
    pending = new Promise((resolve) => {
      const link = document.createElement("link");
      link.rel = "stylesheet"; link.href = "styles-extra.css"; link.setAttribute("data-extra", "");
      const done = () => { ZG.extraCssReady = true; resolve(); };
      link.onload = done; link.onerror = done;   // a failed fetch must never leave the UI stuck
      document.head.appendChild(link);
    });
    return pending;
  };
})();
/** Run fn now if the feature styles are in, otherwise as soon as they are. */
ZG.withExtraCss = (fn) => { if (ZG.extraCssReady) fn(); else ZG.ensureExtraCss().then(fn); };
if (!ZG.extraCssReady) {
  const evs = ["pointerdown", "pointermove", "keydown", "touchstart", "focusin", "wheel"];
  let mo = null;
  const load = () => {
    evs.forEach((e) => removeEventListener(e, load, true));
    mo?.disconnect();
    ZG.ensureExtraCss();
  };
  evs.forEach((e) => addEventListener(e, load, { capture: true, passive: true }));
  // Safety net: any overlay/dialog built by script and appended straight to <body>.
  if (typeof MutationObserver === "function" && document.body) {
    mo = new MutationObserver((recs) => {
      for (const r of recs) for (const n of r.addedNodes) {
        if (n.nodeType === 1 && !/^(SCRIPT|LINK|STYLE|META)$/.test(n.tagName)) { load(); return; }
      }
    });
    mo.observe(document.body, { childList: true });
  }
}

/* ─────────────────────────────────────────────────────────────
   IDENTITY TIERS (ascension) — based on total identity actions,
   not on any timer/session data.
   ───────────────────────────────────────────────────────────── */
const TIERS = [
  { min: 0,   name: "Seed",        icon: "growth", color: "var(--muted-dim)" },
  { min: 5,   name: "Sprout",      icon: "growth", color: "color-mix(in srgb, var(--accent) 55%, var(--muted-dim))" },
  { min: 15,  name: "Sapling",     icon: "growth", color: "var(--accent)" },
  { min: 30,  name: "Rooted",      icon: "growth", color: "var(--accent-strong)" },
  { min: 60,  name: "Grove Keeper",icon: "growth", color: "color-mix(in srgb, var(--accent) 50%, var(--gold))" },
  { min: 100, name: "Deep Rooted", icon: "growth", color: "var(--gold)" },
  { min: 200, name: "Evergreen",   icon: "growth", color: "var(--gold)" },
];
ZG.TIERS = TIERS;
ZG.getTier = (total) => { let t = TIERS[0]; for (const tier of TIERS) if (total >= tier.min) t = tier; return t; };
ZG.getNextTier = (total) => TIERS.find(t => t.min > total) || null;

const STREAK_MILESTONES = [1, 3, 7, 14, 30, 60, 100, 200, 365];
ZG.STREAK_MILESTONES = STREAK_MILESTONES;
ZG.nextStreakMilestone = (streak) => {
  const prev = [...STREAK_MILESTONES].reverse().find(m => m <= streak) || 0;
  const next = STREAK_MILESTONES.find(m => m > streak) ?? null; // null once every milestone is passed
  return { prev, next };
};

/* ─────────────────────────────────────────────────────────────
   XP / TOTAL ACTIONS / STREAK
   ───────────────────────────────────────────────────────────── */
ZG.getXP = () => Store.get("zg_xp", 0);
ZG.getLevel = () => Math.floor(ZG.getXP() / 100) + 1;
ZG.getTotalActions = () => Store.get("zg_total_actions", 0);
ZG.getStreak = () => Store.get("zg_streak", 0);
ZG.getUnlockedSkills = () => Store.get("zg_unlocked_skills", []);
ZG.getAchievements = () => Store.get("zg_achievements", {});

function _today() { return new Date().toDateString(); }
function _yesterday() { return new Date(Date.now() - 86400000).toDateString(); }

/** Call whenever the person does anything identity-related. Handles
 *  streak bookkeeping, weekly-active-day tracking, and XP/level-up. */
ZG.addXP = function (amount, reason, opts = {}) {
  const cur = ZG.getXP();
  const next = cur + amount;
  Store.set("zg_xp", next);

  if (!opts.silent) {
    const total = ZG.getTotalActions() + 1;
    Store.set("zg_total_actions", total);
    _checkTierUp(total);
  }

  ZG.markActiveToday();
  _checkSkillUnlocks(next);
  _checkAchievements();

  if (reason) {
    // opts can carry the same icon/color/actionLabel/onAction ZG.toast()
    // already supports elsewhere (see recovery.js's relapse-undo toast) —
    // this just lets addXP's own toast opt into that instead of every
    // caller needing its own separate toast call for an undo affordance.
    ZG.toast(ZG.getCalmMode() ? reason : `+${amount} XP · ${reason}`, opts.toastDuration || 2600, {
      icon: opts.icon, color: opts.color, actionLabel: opts.actionLabel, onAction: opts.onAction,
    });
  }
  ZG.refreshChrome();
};

/** Marks today as an active day (streak + weekly-rhythm tracking). */
ZG.markActiveToday = function () {
  const today = _today();
  let streak = ZG.getStreak();
  const last = localStorage.getItem("zg_last_active_date");
  if (last !== today) {
    streak = last === _yesterday() ? streak + 1 : 1;
    Store.set("zg_streak", streak);
    localStorage.setItem("zg_last_active_date", today);
    const prevBest = Store.get("zg_longest_streak", 0);
    if (streak > prevBest) Store.set("zg_longest_streak", streak);
    _checkStreakMilestoneToast(streak);
  }
  const dates = new Set(Store.get("zg_active_dates", []));
  dates.add(today);
  // Keep last ~60 days only
  const arr = [...dates].sort();
  Store.set("zg_active_dates", arr.slice(-60));
};

function _checkStreakMilestoneToast(streak) {
  if (STREAK_MILESTONES.includes(streak)) {
    ZG.toast(`${streak}-day streak — that's a real pattern now`, 4200, { icon: "flame", color: "var(--gold)" });
  }
}

function _checkTierUp(total) {
  const prevTotal = total - 1;
  const before = ZG.getTier(prevTotal);
  const after = ZG.getTier(total);
  if (after.name !== before.name) {
    setTimeout(() => ZG.celebrate({
      icon: after.icon,
      color: after.color,
      title: after.name,
      sub: "New identity tier",
      body: `${total} identity actions logged. You've become someone who does this now.`,
    }), 350);
  }
}

/* ── Weekly rhythm (active days this week vs a target) ── */
ZG.getWeeklyGoalTarget = () => Store.get("zg_weekly_goal", 5);
ZG.setWeeklyGoalTarget = (n) => Store.set("zg_weekly_goal", Math.max(1, Math.min(7, n)));

/* ── Privacy veil (Recovery numbers blurred by default) ── */
ZG.getPrivacyVeil = () => Store.get("zg_privacy_veil", false);
ZG.setPrivacyVeil = (on) => {
  Store.set("zg_privacy_veil", !!on);
  document.body.classList.toggle("privacy-veil", !!on);
};

/* ── Calm mode — hides XP numbers, levels, the skill tree, and achievement
   toasts. Streaks, milestones, and tiers stay exactly as they are: this is
   a display setting, not a data setting, so nothing unlocked underneath is
   ever lost, and turning it back off picks up right where things were. */
ZG.getCalmMode = () => Store.get("zg_calm_mode", false);
ZG.setCalmMode = (on) => {
  Store.set("zg_calm_mode", !!on);
  document.body.classList.toggle("calm-mode", !!on);
};

function _weekStart(d = new Date()) {
  const dt = new Date(d); const day = (dt.getDay() + 6) % 7; // Monday=0
  dt.setHours(0, 0, 0, 0); dt.setDate(dt.getDate() - day);
  return dt;
}
ZG.activeDaysThisWeek = function () {
  const start = _weekStart();
  const dates = Store.get("zg_active_dates", []);
  return dates.filter(d => new Date(d) >= start).length;
};

/* ─────────────────────────────────────────────────────────────
   SKILL TREE hookup (definitions live in skilltree.js, but XP-unlock
   checking lives here so any module can trigger it via addXP)
   ───────────────────────────────────────────────────────────── */
function _checkSkillUnlocks(xp) {
  const nodes = ZG.SKILL_NODES || [];
  const unlocked = ZG.getUnlockedSkills();
  let changed = false;
  nodes.forEach(n => {
    if (xp >= n.xp && !unlocked.includes(n.id)) { unlocked.push(n.id); changed = true;
      if (!ZG.getCalmMode()) {
        setTimeout(() => ZG.celebrate({ icon: n.icon, color: `var(${n.colorVar})`, title: n.name, sub: "Skill unlocked", body: n.perk }), 500);
      }
    }
  });
  if (changed) Store.set("zg_unlocked_skills", unlocked);
}

/** Perk bonus: Discipline branch grants extra XP per habit completion. */
ZG.habitXpBonus = function () {
  const u = ZG.getUnlockedSkills();
  let bonus = 0;
  if (u.includes("foothold")) bonus += 1;
  if (u.includes("iron_root")) bonus += 3;
  return bonus;
};

function _checkAchievements() {
  const defs = ZG.ACHIEVEMENTS || [];
  const unlocked = ZG.getAchievements();
  let changed = false;
  defs.forEach(a => {
    if (!unlocked[a.id] && a.check()) { unlocked[a.id] = Date.now(); changed = true;
      if (!ZG.getCalmMode()) {
        setTimeout(() => ZG.toast(`Achievement — ${a.label}`, 4000, { icon: a.icon || "star", color: "var(--gold)" }), 200);
      }
    }
  });
  if (changed) Store.set("zg_achievements", unlocked);
}

/* ─────────────────────────────────────────────────────────────
   TOAST
   ───────────────────────────────────────────────────────────── */
let _toastTimer = null;
ZG.toast = function (text, duration = 2600, opts = {}) {
  const el = document.getElementById("toast");
  if (!el) return;
  const iconHtml = opts.icon
    ? `<span class="icon-chip sm" style="--chip-color:${opts.color || "var(--accent)"}">${window.Icons?.svg(opts.icon) || ""}</span>`
    : "";
  const actionHtml = opts.actionLabel ? `<button class="toast-action" id="toastActionBtn">${_esc(opts.actionLabel)}</button>` : "";
  el.innerHTML = `${iconHtml}<span class="toast-msg">${_esc(text)}</span>${actionHtml}`;
  el.classList.add("toast-flex");
  el.hidden = false;
  requestAnimationFrame(() => el.classList.add("show"));
  clearTimeout(_toastTimer);
  const dismiss = () => { el.classList.remove("show"); setTimeout(() => { el.hidden = true; }, 300); };
  if (opts.actionLabel && opts.onAction) {
    document.getElementById("toastActionBtn")?.addEventListener("click", () => {
      clearTimeout(_toastTimer);
      opts.onAction();
      dismiss();
    });
  }
  _toastTimer = setTimeout(dismiss, duration);
};

/* ── Celebration overlay (milestones, tier-ups, skill unlocks) ──
   Quiet on purpose: one icon-chip, no confetti, no giant emoji. */
ZG.celebrate = function ({ icon, color, title, sub, body }) {
  document.querySelector(".celebrate-wrap")?.remove();
  const wrap = document.createElement("div");
  wrap.className = "celebrate-wrap";
  wrap.innerHTML = `
    <div class="celebrate-card">
      <span class="icon-chip lg" style="--chip-color:${color || "var(--accent)"}">${window.Icons?.svg(icon) || ""}</span>
      <div style="font-size:0.6875rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--accent);margin-bottom:6px">${_esc(sub)}</div>
      <h3 role="heading" aria-level="2" style="font-size:1.5rem;margin-bottom:10px">${_esc(title)}</h3>
      <p style="font-size:0.8125rem;color:var(--muted);line-height:1.65;margin-bottom:22px">${_esc(body)}</p>
      <button class="btn-quiet" style="width:100%" id="zgCelebrateContinue">Continue</button>
    </div>`;
  document.body.appendChild(wrap);
  const done = () => { document.removeEventListener("keydown", onKey); wrap.remove(); };
  const onKey = (e) => { if (e.key === "Escape") done(); };
  wrap.querySelector("#zgCelebrateContinue").addEventListener("click", done);
  wrap.addEventListener("click", e => { if (e.target === wrap) done(); });
  document.addEventListener("keydown", onKey);
};

function _esc(str) {
  return String(str ?? "").replace(/[<>&"']/g, c => ({ "<": "&lt;", ">": "&gt;", "&": "&amp;", '"': "&quot;", "'": "&#39;" }[c]));
}
ZG.esc = _esc;

/* ─────────────────────────────────────────────────────────────
   CONFIRM / PROMPT — styled replacements for the browser's native
   confirm()/prompt(), which render as an unstyled "this page says"
   system dialog that breaks the app's whole visual language. Both
   reuse the same .celebrate-wrap/.celebrate-card overlay already
   used for milestones and the recovery check-in modals, and both
   return a Promise so call sites just `await` them instead of
   blocking. confirm() resolves true/false; prompt() resolves to the
   entered string, or null if cancelled — same null-means-cancelled
   contract as the native version, so existing `if (val != null)`
   checks keep working unchanged.
   ───────────────────────────────────────────────────────────── */
ZG.confirm = function ({ title, body = "", confirmLabel, cancelLabel, danger = false } = {}) {
  title = title ?? (ZG.t ? ZG.t("dialog_are_you_sure") : "Are you sure?");
  confirmLabel = confirmLabel ?? (ZG.t ? ZG.t("dialog_confirm") : "Confirm");
  cancelLabel = cancelLabel ?? (ZG.t ? ZG.t("dialog_cancel") : "Cancel");
  return new Promise(resolve => {
    document.getElementById("zgConfirmModal")?.remove();
    const wrap = document.createElement("div");
    wrap.id = "zgConfirmModal";
    wrap.className = "celebrate-wrap";
    wrap.innerHTML = `
      <div class="celebrate-card" style="text-align:left">
        <h3 role="heading" aria-level="2" style="text-align:center;margin-bottom:${body ? "8px" : "18px"}">${_esc(title)}</h3>
        ${body ? `<p style="font-size:0.78125rem;color:var(--muted);line-height:1.6;text-align:center;margin-bottom:18px">${_esc(body)}</p>` : ""}
        <div style="display:flex;gap:8px">
          <button class="btn-ghost" style="flex:1" id="zgConfirmCancel">${_esc(cancelLabel)}</button>
          <button class="${danger ? "btn-danger-ghost" : "btn-primary"}" style="flex:1" id="zgConfirmOk">${_esc(confirmLabel)}</button>
        </div>
      </div>`;
    document.body.appendChild(wrap);
    const done = (val) => { document.removeEventListener("keydown", onKey); wrap.remove(); resolve(val); };
    const onKey = (e) => { if (e.key === "Escape") done(false); if (e.key === "Enter") done(true); };
    wrap.querySelector("#zgConfirmCancel").addEventListener("click", () => done(false));
    wrap.querySelector("#zgConfirmOk").addEventListener("click", () => done(true));
    wrap.addEventListener("click", e => { if (e.target === wrap) done(false); });
    document.addEventListener("keydown", onKey);
    setTimeout(() => wrap.querySelector("#zgConfirmOk")?.focus(), 60);
  });
};

ZG.prompt = function ({ title = "", body = "", placeholder = "", value = "", confirmLabel, cancelLabel, type = "text", inputMode = null } = {}) {
  confirmLabel = confirmLabel ?? (ZG.t ? ZG.t("dialog_save") : "Save");
  cancelLabel = cancelLabel ?? (ZG.t ? ZG.t("dialog_cancel") : "Cancel");
  return new Promise(resolve => {
    document.getElementById("zgPromptModal")?.remove();
    const wrap = document.createElement("div");
    wrap.id = "zgPromptModal";
    wrap.className = "celebrate-wrap";
    wrap.innerHTML = `
      <div class="celebrate-card" style="text-align:left">
        <h3 role="heading" aria-level="2" style="text-align:center;margin-bottom:${body ? "8px" : "14px"}">${_esc(title)}</h3>
        ${body ? `<p style="font-size:0.78125rem;color:var(--muted);line-height:1.6;text-align:center;margin-bottom:14px">${_esc(body)}</p>` : ""}
        <input type="${type}" id="zgPromptInput" placeholder="${_esc(placeholder)}" value="${_esc(value)}"
               ${inputMode ? `inputmode="${inputMode}"` : ""} ${type === "password" ? 'pattern="[0-9]*" autocomplete="off"' : ""}/>
        <div style="display:flex;gap:8px;margin-top:16px">
          <button class="btn-ghost" style="flex:1" id="zgPromptCancel">${_esc(cancelLabel)}</button>
          <button class="btn-primary" style="flex:1" id="zgPromptOk">${_esc(confirmLabel)}</button>
        </div>
      </div>`;
    document.body.appendChild(wrap);
    const input = wrap.querySelector("#zgPromptInput");
    const done = (val) => { document.removeEventListener("keydown", onKey); wrap.remove(); resolve(val); };
    const onKey = (e) => { if (e.key === "Escape") done(null); };
    wrap.querySelector("#zgPromptCancel").addEventListener("click", () => done(null));
    wrap.querySelector("#zgPromptOk").addEventListener("click", () => done(input.value));
    input.addEventListener("keydown", e => { if (e.key === "Enter") done(input.value); });
    wrap.addEventListener("click", e => { if (e.target === wrap) done(null); });
    document.addEventListener("keydown", onKey);
    setTimeout(() => { input.focus(); if (type !== "password") input.select(); }, 60);
  });
};

/* ─────────────────────────────────────────────────────────────
   GROWTH RING — signature dial (weekly rhythm / streak / today)
   ───────────────────────────────────────────────────────────── */
ZG.renderGrowthRing = function (el) {
  if (!el) return;
  const target = ZG.getWeeklyGoalTarget();
  const activeDays = ZG.activeDaysThisWeek();
  const weeklyPct = Math.min(100, Math.round((activeDays / target) * 100));

  const streak = ZG.getStreak();
  const { prev, next } = ZG.nextStreakMilestone(streak);
  const streakPct = next != null ? Math.min(100, Math.round(((streak - prev) / (next - prev)) * 100)) : 100;

  const habitsToday = (window.Habits?.todayCounts?.()) || { done: 0, total: 0 };
  const todayPct = habitsToday.total > 0 ? Math.round((habitsToday.done / habitsToday.total) * 100)
                                          : (Store.get("zg_active_dates", []).includes(_today()) ? 100 : 0);

  const R1 = 78, R2 = 62, R3 = 46;
  // innerHTML replaces the circles, which would kill the CSS transition — so remember the
  // previous arc length per ring, draw from it, then move to the target on the next frames.
  const prevArcs = (ZG._ringPrev = ZG._ringPrev || {});
  const arc = (r, pct, color, width) => {
    const C = 2 * Math.PI * r;
    const dash = Math.max(0, Math.min(1, pct / 100)) * C;
    const from = ZG.motionOK() ? (prevArcs[r] ?? 0) : dash;
    prevArcs[r] = dash;
    return `<circle cx="86" cy="86" r="${r}" fill="none" stroke="${color}" stroke-opacity=".14" stroke-width="${width}"/>
      <circle class="ring-arc" data-to="${dash.toFixed(1)} ${C.toFixed(1)}" cx="86" cy="86" r="${r}" fill="none" stroke="${color}" stroke-width="${width}" stroke-linecap="round"
        stroke-dasharray="${from.toFixed(1)} ${C.toFixed(1)}" stroke-dashoffset="${(C / 4).toFixed(1)}"
        style="transition:stroke-dasharray .9s var(--ease-out)"/>`;
  };

  el.innerHTML = `
    <svg viewBox="0 0 172 172" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Growth rings">
      ${arc(R1, weeklyPct, "var(--accent)", 9)}
      ${arc(R2, streakPct, "var(--gold)", 8)}
      ${arc(R3, todayPct, "var(--clay)", 7)}
      <text x="86" y="80" text-anchor="middle" class="ring-center-num" style="font-size:2.125rem;fill:var(--text)">${streak}</text>
      <text x="86" y="99" text-anchor="middle" style="font-size:calc(0.6875rem * 172 / var(--dial, 172));fill:var(--muted-dim);letter-spacing:0;font-family:var(--font-body)">day streak</text>
    </svg>`;

  if (ZG.motionOK()) {
    requestAnimationFrame(() => requestAnimationFrame(() => el.querySelectorAll(".ring-arc").forEach((c) => c.setAttribute("stroke-dasharray", c.dataset.to))));
  } else el.querySelectorAll(".ring-arc").forEach((c) => c.setAttribute("stroke-dasharray", c.dataset.to));

  const setText = (id, v) => { const e = document.getElementById(id); if (e) e.textContent = v; };
  setText("legendWeekly", `${activeDays}/${target}`);
  setText("legendStreak", streak);
  setText("legendNextMs", next != null ? next : "\u2014"); // em dash once every milestone is passed
  setText("legendToday", habitsToday.total ? `${habitsToday.done}/${habitsToday.total}` : (todayPct ? "done" : "—"));
};

/* ─────────────────────────────────────────────────────────────
   HOME chrome refresh (stat row, insight line, ring)
   ───────────────────────────────────────────────────────────── */
const DAILY_LINES = [
  "You don't need a perfect week. You need today.",
  "The version of you that follows through is built in exactly these moments.",
  "Small and repeated beats big and occasional.",
  "Nobody sees the streak. Everyone eventually sees who it made you.",
  "Consistency is just kept promises, stacked.",
  "You're not behind. You're mid-story.",
  "The habit doesn't care how you feel about it today.",
  "Progress that doesn't announce itself is still progress.",
];

ZG.refreshChrome = function () {
  const xp = ZG.getXP(), level = ZG.getLevel(), total = ZG.getTotalActions();
  const tier = ZG.getTier(total);
  const name = Store.get("zg_name", "");

  const set = (id, v) => { const e = document.getElementById(id); if (e) e.textContent = v; };
  ZG.setNum(document.getElementById("statLevel"), level);
  ZG.setNum(document.getElementById("statXP"), xp);
  ZG.setNum(document.getElementById("statActions"), total);
  set("statTier", tier.name);

  const greetEl = document.getElementById("homeGreeting");
  if (greetEl) {
    const h = new Date().getHours();
    const base = h < 5 ? "Still up" : h < 12 ? "Good morning" : h < 17 ? "Good afternoon" : h < 21 ? "Good evening" : "One more line before bed";
    greetEl.textContent = name ? `${base}, ${name}` : base;
  }

  // Rewriting a node's text with an identical string still replaces the text
  // node, which shows up as a fresh (later) paint of the hero. Only write on change.
  const setIfChanged = (el, v) => { if (el.textContent !== v) el.textContent = v; };
  const idLine = document.getElementById("homeIdentityLine");
  if (idLine) {
    const streak = ZG.getStreak();
    setIfChanged(idLine, streak >= 30 ? "This is who you are now — not who you're trying to become."
      : streak >= 7 ? "Consistency is starting to feel less like effort."
      : streak >= 1 ? "Every day you choose is a vote for who you're becoming."
      : "Today is a perfectly good day to start.");
  }

  const insightEl = document.getElementById("homeInsight");
  if (insightEl) {
    const motto = window.Profile?.getMotto?.();
    if (motto) {
      setIfChanged(insightEl, "\u201C" + motto + "\u201D");
    } else {
      const key = "zg_daily_line_" + _today();
      let line = localStorage.getItem(key);
      if (!line) { line = DAILY_LINES[Math.floor(Math.random() * DAILY_LINES.length)]; localStorage.setItem(key, line); }
      setIfChanged(insightEl, "\u201C" + line + "\u201D");
    }
  }
  // Remember what the hero says so the next load can paint it immediately
  // (see the inline script after #homeInsight in index.html).
  if (idLine && insightEl) Store.set("zg_hero_cache", { day: _today(), line: idLine.textContent, ins: insightEl.textContent });

  ZG.renderGrowthRing(document.getElementById("growthRingWrap"));
  ZG.renderTodayCard();
  window.WeeklyDigest?.render?.();

  const cleanAllCard = document.getElementById("cleanAcrossCard");
  if (cleanAllCard) {
    const days = window.Recovery?.daysCleanAcrossAll?.();
    cleanAllCard.hidden = days == null;
    if (days != null) {
      const val = document.getElementById("cleanAcrossVal");
      if (val) val.textContent = days;
    }
  }
};

/* ─────────────────────────────────────────────────────────────
   NAVIGATION
   ───────────────────────────────────────────────────────────── */
function showSection(id) {
  // Home's styles are always present; every other section needs the feature sheet first.
  if (id !== "home" && !ZG.extraCssReady) { ZG.ensureExtraCss().then(() => _showSectionNow(id)); return; }
  _showSectionNow(id);
}
function _showSectionNow(id) {
  const prevId = document.querySelector(".app-section.active")?.id.replace("Section", "");
  document.querySelectorAll(".app-section").forEach(s => s.classList.remove("active"));
  const nextEl = document.getElementById(id + "Section");
  nextEl?.classList.add("active");
  document.getElementById("habitFab")?.classList.toggle("show", id === "habits");
  if (nextEl && prevId && prevId !== id && ZG.motionOK()) {
    // Slide in from the side the tab sits on (bottom-nav order), then drop the helper class.
    const order = [...document.querySelectorAll(".bottom-nav [data-sec]")].map((b) => b.dataset.sec);
    nextEl.classList.remove("dir-fwd", "dir-back");
    nextEl.classList.add(order.indexOf(id) > order.indexOf(prevId) ? "dir-fwd" : "dir-back");
    nextEl.addEventListener("animationend", () => nextEl.classList.remove("dir-fwd", "dir-back"), { once: true });
  }
  document.querySelectorAll("[data-sec]").forEach(b => b.classList.toggle("active", b.dataset.sec === id));
  localStorage.setItem("zg_last_section", id);
  if (id === "home") ZG.refreshChrome();
  // Mindful check-ins only ever apply to Growth (the gamified stats/streak
  // display) — every other section renders immediately, same as always.
  if (id === "growth" && window.Focus?.maybeShowCheckinCooldown) {
    Focus.maybeShowCheckinCooldown(() => ZG.sectionRenderers[id]?.());
  } else {
    ZG.sectionRenderers[id]?.();
  }
}
ZG.showSection = showSection;

/* ─────────────────────────────────────────────────────────────
   QUICK-LOG ACTIONS — the closest a static, backend-less PWA can get
   to a true interactive home-screen widget. A real iOS WidgetKit
   widget or an Android App Widget needs a native wrapper this project
   doesn't have (see netlify.toml: no server, no build tooling for
   that). What a PWA *can* do is a home-screen shortcut that deep-links
   straight past navigation into a ready-to-act screen — a manifest
   shortcut carries ?action=, and this runs it once the destination
   section has painted, landing the person one tap from actually
   logging something instead of just on the right screen. */
function _runQuickAction(action) {
  if (action === "addhabit") {
    window.Habits?.openAddSheet?.();
  } else if (action === "journal") {
    window.Recovery?.showTab?.("journal");
    document.getElementById("jrEntryInput")?.focus();
  } else if (action === "rideitout") {
    window.Recovery?.showTab?.("trackers");
    const ids = Object.keys(window.Recovery?.load?.().trackers || {});
    if (ids.length === 1) window.Recovery?.startUrgeSurf?.(ids[0]);
    else if (ids.length === 0) window.Recovery?.openOptions?.();
    // 2+ trackers: land on Recovery, where every card has its own "Ride it out" button.
  } else if (action === "urge") {
    window.Recovery?.showTab?.("trackers");
    const ids = Object.keys(window.Recovery?.load?.().trackers || {});
    if (ids.length === 1) window.Recovery?.showUrgeModal?.(ids[0]);
    else if (ids.length === 0) window.Recovery?.openOptions?.(); // nothing tracked yet — get them set up
    // 2+ trackers: already on Recovery with every card's "I resisted"
    // button visible — no safe way to guess which one they mean.
  }
}

/* ─────────────────────────────────────────────────────────────
   THEME
   ───────────────────────────────────────────────────────────── */
const THEMES = ["dark", "light", "forest", "dune", "slate"];
const THEME_STATUS_COLORS = { dark: "#15120d", light: "#edf0e5", forest: "#0b1710", dune: "#f2ead9", slate: "#10161c" };
function applyTheme(theme, silent) {
  document.body.classList.remove(...THEMES, "dusk");
  document.body.classList.add(theme === "dark" ? "dark" : theme);
  localStorage.setItem("zg_theme", theme);
  document.querySelectorAll(".theme-pill").forEach(p => p.classList.toggle("active", p.dataset.theme === theme));
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute("content", THEME_STATUS_COLORS[theme] || THEME_STATUS_COLORS.dark);
  window.NativeBridge?.setSystemBars?.(theme);
  if (!silent) ZG.toast(`Theme: ${theme[0].toUpperCase() + theme.slice(1)}`);
window.Growth?.syncTheme?.();
}
ZG.applyTheme = applyTheme;

/* ─────────────────────────────────────────────────────────────
   MODALS (generic open/close)
   ───────────────────────────────────────────────────────────── */
const backdrop = document.getElementById("modalBackdrop");
let _modalReturnFocus = null;
function openModal(id) {
  const m = document.getElementById(id);
  if (!m) return;
  _modalReturnFocus = document.activeElement;
  // Modal contents are styled by the feature sheet; show the modal only once it is in.
  ZG.withExtraCss(() => {
    backdrop.classList.add("show");
    document.body.style.overflow = "hidden";
    requestAnimationFrame(() => {
      m.classList.add("show");
      // Land keyboard/screen-reader focus inside the modal unless something
      // in there already claimed it (a few callers focus a specific input
      // right after opening — that should win over this generic fallback).
      if (!m.contains(document.activeElement)) {
        if (!m.hasAttribute("tabindex")) m.setAttribute("tabindex", "-1");
        m.focus({ preventScroll: true });
      }
    });
  });
}
function closeModal(id) {
  const m = id ? document.getElementById(id) : document.querySelector(".modal.show");
  if (!m) return;
  m.classList.remove("show");
  backdrop.classList.remove("show");
  document.body.style.overflow = "";
  // Give focus back to whatever opened this modal (a nav button, a card
  // action) instead of leaving it stranded on a now-hidden element.
  if (_modalReturnFocus && document.contains(_modalReturnFocus)) _modalReturnFocus.focus({ preventScroll: true });
  _modalReturnFocus = null;
}
backdrop?.addEventListener("click", () => closeModal());
// Escape closes whatever modal/drawer/sheet is open — standard dialog
// behavior every screen reader and keyboard user expects. The one
// exception is the fullscreen welcome onboarding: that flow is meant to
// be stepped through, not dismissed sight-unseen on first launch.
document.addEventListener("keydown", (e) => {
  if (e.key !== "Escape") return;
  const open = document.querySelector(".modal.show");
  if (open && !open.classList.contains("fullscreen")) closeModal();
});
ZG.openModal = openModal;
ZG.closeModal = closeModal;

/* ─────────────────────────────────────────────────────────────
   BACKUP — everything lives only in this browser, so an export is
   the only thing standing between someone and total data loss if
   the cache clears or the device changes. This nudges, it never
   forces or blocks.
   ───────────────────────────────────────────────────────────── */
function _renderBackupNote() {
  const el = document.getElementById("lastExportNote");
  if (!el) return;
  // The most recent of either a manual export or a silent auto-backup
  // counts — someone with auto-backup running shouldn't see a false
  // "you haven't backed up" warning just because they never clicked the
  // manual export button (see auto-backup.js).
  const manualTs = Store.get("zg_last_export_ts", null);
  const autoTs = window.AutoBackup?.isEnabled?.() ? window.AutoBackup.lastBackupTs() : null;
  const ts = [manualTs, autoTs].filter(Boolean).sort((a, b) => b - a)[0] || null;
  if (!ts) {
    const shouldWarn = ZG.getTotalActions() >= 10;
    el.textContent = shouldWarn ? "You haven't exported a backup yet — worth doing, since everything lives only in this browser." : "";
    el.classList.toggle("backup-warn", shouldWarn);
    return;
  }
  const days = Math.floor((Date.now() - ts) / 86400000);
  el.textContent = days === 0 ? "Backed up today." : `Last backup: ${days} day${days === 1 ? "" : "s"} ago.`;
  el.classList.toggle("backup-warn", days >= 30);
}
ZG.renderBackupNote = _renderBackupNote;

/* ─────────────────────────────────────────────────────────────
   LOCAL REMINDERS — best-effort only. Notifications fire while
   this tab/app is open; there's no push server behind this, so it
   won't wake a closed tab. The Settings copy says this plainly.
   ───────────────────────────────────────────────────────────── */
ZG.notificationsEnabled = () => Store.get("zg_notify_enabled", false);
ZG.setNotificationsEnabled = (on) => Store.set("zg_notify_enabled", !!on);

/** Same adaptive spirit as the recovery risk-window reminder below, applied
 *  to the general evening habit nudge: instead of one fixed hour for every
 *  person, fire a couple hours after THIS person's own typical finishing
 *  time (see habits.js's typicalCompletionHour, built from real completion
 *  history). Falls back to the original fixed 7pm until there's enough
 *  history to say anything — same "don't guess from too little data" rule
 *  used everywhere else in this app. Clamped to a sane evening window so a
 *  rare 2am catch-up outlier can't push the reminder to an unhelpful hour. */
ZG.reminderThresholdHour = function () {
  const typical = window.Habits?.typicalCompletionHour?.();
  if (typical == null) return 19;
  return Math.min(22, Math.max(17, typical + 2));
};

async function _requestNotifyPermission() {
  if (window.NativeBridge?.isNative?.()) return NativeBridge.requestPermission();
  if (!("Notification" in window)) return false;
  if (Notification.permission === "granted") return true;
  if (Notification.permission === "denied") return false;
  const res = await Notification.requestPermission();
  return res === "granted";
}

/** True when this device can actually receive a notification right
 *  now — native permission when running inside Capacitor, the Web
 *  Notification API's own permission state otherwise. Kept as one
 *  shared check so the two reminder functions below don't each
 *  reimplement the native-vs-web branch. */
async function _hasNotifyPermission() {
  if (window.NativeBridge?.isNative?.()) return NativeBridge.hasPermission();
  return ("Notification" in window) && Notification.permission === "granted";
}

/** Delivers a notification through whichever channel this device
 *  actually has: the OS's own notification system when running as a
 *  native app (can wake a closed app — see native-bridge.js's header
 *  for why that's worth the extra path), the Web Notifications API
 *  otherwise (best-effort, foreground-only, same ceiling this app has
 *  always had as a plain PWA). `id` is a small stable integer per
 *  reminder KIND, not per firing — see notifyNow()'s own note. */
async function _sendNotification({ id, body }) {
  if (window.NativeBridge?.isNative?.()) {
    const sent = await NativeBridge.notifyNow({ id, title: "NASVOGrow", body });
    if (sent) return;
  }
  try { new Notification("NASVOGrow", { body, icon: "/assets/icons/icon-192.png" }); } catch {}
}

async function _maybeSendReminder() {
  if (window.NativeBridge?.isNative?.()) return;   // Android: pre-scheduled by native-app.js instead
  if (!ZG.notificationsEnabled()) return;
  if (!(await _hasNotifyPermission())) return;
  const todayStr = _today();
  if (localStorage.getItem("zg_last_notify_date") === todayStr) return;
  if (new Date().getHours() < ZG.reminderThresholdHour()) return;
  const { done, total } = window.Habits?.todayCounts?.() || { done: 0, total: 0 };
  if (total > 0 && done === total) return; // already all done today
  const activeToday = Store.get("zg_active_dates", []).includes(todayStr);
  if (activeToday && total === 0) return; // nothing to nudge about
  localStorage.setItem("zg_last_notify_date", todayStr);
  await _sendNotification({
    id: 1,
    body: total > 0 ? `${total - done} habit${total - done === 1 ? "" : "s"} left today.` : "A quiet reminder — today's still open.",
  });
}
setInterval(_maybeSendReminder, 20 * 60000);

/* ─────────────────────────────────────────────────────────────
   RISK-WINDOW REMINDERS — a second, opt-in local reminder timed to
   the person's own highest-risk windows (see insights.js's
   _riskWindows, which reads the same local urge/relapse log
   everything else does — no server, no new data collection, just a
   different read of data already being logged). Checks against EVERY
   currently-qualifying window, not just a single best one, since a
   real secondary pattern shouldn't be silently dropped just because
   one window narrowly ranked first. Same delivery path as the general
   reminder above — native OS notification when wrapped as a native
   app, best-effort/foreground-only Web Notification otherwise. Gated
   behind Local reminders being on too, since that's what actually
   holds notification permission on either path.
   ───────────────────────────────────────────────────────────── */
ZG.riskRemindersEnabled = () => Store.get("zg_risk_notify_enabled", false);
ZG.setRiskRemindersEnabled = (on) => Store.set("zg_risk_notify_enabled", !!on);

async function _maybeSendRiskReminder() {
  if (window.NativeBridge?.isNative?.()) return;   // Android: pre-scheduled by native-app.js instead
  if (!ZG.riskRemindersEnabled() || !ZG.notificationsEnabled()) return;
  if (!(await _hasNotifyPermission())) return;
  const rw = window.Insights?.compute?.()?.riskWindows;
  if (!rw) return;
  const now = new Date();
  const match = rw.windows.find(w => w.dow === now.getDay() && w.hour === now.getHours());
  if (!match) return;
  const todayStr = _today();
  if (localStorage.getItem("zg_last_risk_notify_date") === todayStr) return;
  localStorage.setItem("zg_last_risk_notify_date", todayStr);
  await _sendNotification({ id: 2, body: "This has been a harder hour for you before — worth a quick check-in with yourself right now." });
}
setInterval(_maybeSendRiskReminder, 20 * 60000);

/* ─────────────────────────────────────────────────────────────
   BACKUP NUDGE — once per session, only if there's meaningful
   data at stake and it's genuinely been a while.
   ───────────────────────────────────────────────────────────── */
function _maybeNudgeBackup() {
  if (sessionStorage.getItem("zg_backup_nudged")) return;
  const ts = Store.get("zg_last_export_ts", null);
  const daysSince = ts ? Math.floor((Date.now() - ts) / 86400000) : Infinity;
  if (ZG.getTotalActions() >= 15 && daysSince >= 30) {
    sessionStorage.setItem("zg_backup_nudged", "1");
    setTimeout(() => ZG.toast("It's been a while — back up your data in Settings", 5000, { icon: "lock" }), 1800);
  }
}

/* ─────────────────────────────────────────────────────────────
   ONBOARDING — a short 3-step flow instead of a single static
   screen, so a first-time visitor leaves with an actual habit and
   a weekly goal set, not just a blurb they clicked past.
   ───────────────────────────────────────────────────────────── */
function initOnboarding() {
  const modal = document.getElementById("welcomeModal");
  if (!modal) return;
  const allSteps = [...modal.querySelectorAll(".welcome-step")]; // hero, intent, habit, recovery, goal
  const dots = [...modal.querySelectorAll(".welcome-dot")];

  // "both" by default (the "Both" chip starts pre-selected in the markup)
  // so someone who clicks straight through without choosing still gets the
  // full setup instead of silently losing the recovery step.
  let intent = "both";
  let idx = 0;

  /** The visible step sequence changes based on intent — a "Build habits"
   *  person never sees the recovery-tracker step and vice versa, so this
   *  is recomputed every time Next/Back moves, rather than a fixed list. */
  function sequence() {
    const seq = ["hero", "intent"];
    if (intent === "habits" || intent === "both") seq.push("habit");
    if (intent === "recovery" || intent === "both") seq.push("recovery");
    seq.push("goal");
    return seq;
  }

  function show(i) {
    const seq = sequence();
    i = Math.max(0, Math.min(seq.length - 1, i));
    idx = i;
    const activeKey = seq[i];
    allSteps.forEach(s => { s.hidden = s.dataset.step !== activeKey; });
    dots.forEach((d, di) => { d.hidden = di >= seq.length; d.classList.toggle("done", di < i); d.classList.toggle("current", di === i); });
  }
  show(0);

  modal.querySelectorAll("[data-wnext]").forEach(b => b.addEventListener("click", () => show(idx + 1)));
  modal.querySelectorAll("[data-wback]").forEach(b => b.addEventListener("click", () => show(idx - 1)));

  const intentChips = [...modal.querySelectorAll("[data-onb-intent]")];
  intentChips.forEach(chip => chip.addEventListener("click", () => {
    intent = chip.dataset.onbIntent;
    intentChips.forEach(c => c.classList.toggle("selected", c === chip));
  }));

  const habitInput = document.getElementById("onbHabitInput");
  const habitChips = [...modal.querySelectorAll("[data-onb-habit]")];
  habitChips.forEach(chip => chip.addEventListener("click", () => {
    if (habitInput) habitInput.value = chip.dataset.onbHabit;
    habitChips.forEach(c => c.classList.toggle("selected", c === chip));
  }));
  habitInput?.addEventListener("input", () => {
    habitChips.forEach(c => c.classList.toggle("selected", c.dataset.onbHabit === habitInput.value));
  });

  // Recovery-tracker chips are built from Recovery.TYPES rather than
  // hardcoded, so this step never drifts out of sync with the actual
  // tracker list in recovery.js.
  const recoveryChipsWrap = document.getElementById("onbRecoveryChips");
  let selectedTrackerId = null;
  if (recoveryChipsWrap) {
    const types = window.Recovery?.TYPES || {};
    recoveryChipsWrap.innerHTML = Object.values(types).map(t =>
      `<button type="button" class="onb-chip" data-onb-tracker="${t.id}">${t.label}</button>`).join("");
    const trackerChips = [...recoveryChipsWrap.querySelectorAll("[data-onb-tracker]")];
    trackerChips.forEach(chip => chip.addEventListener("click", () => {
      selectedTrackerId = chip.dataset.onbTracker;
      trackerChips.forEach(c => c.classList.toggle("selected", c === chip));
    }));
  }

  const goalInput = document.getElementById("onbGoalInput");
  goalInput?.addEventListener("input", () => {
    const r = document.getElementById("onbGoalReadout");
    if (r) r.textContent = goalInput.value;
  });

  document.getElementById("welcomeStartBtn")?.addEventListener("click", () => {
    const wantsHabit = intent === "habits" || intent === "both";
    const wantsRecovery = intent === "recovery" || intent === "both";

    const habitName = document.getElementById("onbHabitInput")?.value.trim();
    if (wantsHabit && habitName) {
      // The 3 quick-pick chips have obvious categories; anything typed
      // freehand just falls back to "general" via Habits.add()'s own default.
      const presetCategory = { "Drink water first thing": "health", "Move your body": "health", "Read a few pages": "mind" }[habitName];
      window.Habits?.add?.(habitName, presetCategory);
    }
    if (wantsRecovery && selectedTrackerId) window.Recovery?.addTracker?.(selectedTrackerId);

    ZG.setWeeklyGoalTarget(Number(goalInput?.value || 5));
    localStorage.setItem("zg_onboarded", "1");
    closeModal("welcomeModal");
    ZG.refreshChrome();

    // A "Break something" person landing on the generic Home screen after
    // setup reads oddly if they never touch Habits — send them straight
    // into Recovery instead of assuming Home is the right first stop.
    if (intent === "recovery") ZG.showSection?.("recovery");
  });
}

/* ─────────────────────────────────────────────────────────────
   EXPORT FORMATS — the full .json backup is the only one that can
   be re-imported (it's a byte-for-byte snapshot of localStorage).
   The others are one-way exports meant for reading elsewhere:
   spreadsheets for the CSVs, a notes app for the Markdown journal.
   ───────────────────────────────────────────────────────────── */
function _csvEscape(v) {
  const s = String(v ?? "");
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}
function _csvRows(rows) { return rows.map(r => r.map(_csvEscape).join(",")).join("\n"); }

function _downloadBlob(content, filename, mime) {
  if (window.NativeBridge?.isNative?.()) {
    NativeBridge.saveFile({ filename, mime, text: String(content) }).then((r) => {
      if (!r.ok && r.reason !== "cancelled") ZG.toast("Couldn't open the share sheet — try again");
    });
    return;
  }
  const blob = new Blob([content], { type: mime });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
}

function _buildHabitsCsv() {
  const h = window.Habits?.load?.() || { habits: [], log: {} };
  const rows = [["date", "habit", "category", "completed"]];
  Object.keys(h.log).sort().forEach(date => {
    h.habits.forEach(habit => {
      if ((h.log[date] || []).includes(habit.id)) rows.push([date, habit.name, window.Habits?.categoryLabel?.(habit.category) || "General", "1"]);
    });
  });
  return _csvRows(rows);
}

function _buildJournalCsv() {
  const entries = window.Journal?.load?.() || [];
  const rows = [["date", "prompt", "entry"]];
  entries.slice().reverse().forEach(e => rows.push([e.date, e.prompt, e.text]));
  return _csvRows(rows);
}

function _buildJournalMd() {
  const entries = window.Journal?.load?.() || [];
  const lines = ["# NASVOGrow — Journal", ""];
  entries.slice().reverse().forEach(e => { lines.push(`## ${e.date}`, `*${e.prompt}*`, "", e.text, ""); });
  return lines.join("\n");
}

function _buildRecoveryCsv() {
  const rec = window.Recovery?.load?.() || { trackers: {} };
  const rows = [["date", "tracker", "kind", "halt_tags", "intensity", "note"]];
  Object.entries(rec.trackers).forEach(([id, t]) => {
    const label = window.Recovery?.TYPES?.[id]?.label || id;
    (t.urges || []).forEach(u => rows.push([new Date(u.ts).toISOString(), label, "resisted", (u.halt || []).join("|"), u.intensity ?? "", u.note || ""]));
    (t.relapses || []).forEach(r => rows.push([new Date(r.ts).toISOString(), label, "reset", (r.halt || []).join("|"), r.intensity ?? "", r.note || ""]));
  });
  return _csvRows(rows);
}

function _buildVitalsCsv() {
  const entries = (window.Vitals?.load?.() || []).slice().sort((a, b) => a.ts - b.ts);
  const rows = [["week_of", "craving", "mood", "energy"]];
  entries.forEach(v => rows.push([v.weekKey, v.craving, v.mood, v.energy]));
  return _csvRows(rows);
}

function _exportData() {
  const format = document.getElementById("exportFormatSelect")?.value || "json";
  const stamp = new Date().toISOString().slice(0, 10);
  const labels = {
    json: "Backup exported", portable_json: "Portable backup exported", habits_csv: "Habits exported (CSV)", journal_csv: "Journal exported (CSV)",
    journal_md: "Journal exported (Markdown)", recovery_csv: "Recovery log exported (CSV)", vitals_csv: "Weekly check-ins exported (CSV)",
  };
  if (format === "json") {
    const data = {};
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k?.startsWith("zg_")) data[k] = localStorage.getItem(k);
    }
    _downloadBlob(JSON.stringify(data, null, 2), `nasvo-grow-backup-${stamp}.json`, "application/json");
    Store.set("zg_last_export_ts", Date.now());
    _renderBackupNote();
  } else if (format === "portable_json") {
    // A stable, documented, key-name-decoupled alternative to the raw
    // localStorage dump above — see portable-export.js and
    // portable-schema.md. Counts as a real backup for the "last backup"
    // note same as the format above.
    _downloadBlob(JSON.stringify(window.PortableExport.build(), null, 2), `nasvo-grow-portable-${stamp}.json`, "application/json");
    Store.set("zg_last_export_ts", Date.now());
    _renderBackupNote();
  } else if (format === "habits_csv") {
    _downloadBlob(_buildHabitsCsv(), `nasvo-grow-habits-${stamp}.csv`, "text/csv");
  } else if (format === "journal_csv") {
    _downloadBlob(_buildJournalCsv(), `nasvo-grow-journal-${stamp}.csv`, "text/csv");
  } else if (format === "journal_md") {
    _downloadBlob(_buildJournalMd(), `nasvo-grow-journal-${stamp}.md`, "text/markdown");
  } else if (format === "recovery_csv") {
    _downloadBlob(_buildRecoveryCsv(), `nasvo-grow-recovery-${stamp}.csv`, "text/csv");
  } else if (format === "vitals_csv") {
    _downloadBlob(_buildVitalsCsv(), `nasvo-grow-weekly-checkins-${stamp}.csv`, "text/csv");
  }
  ZG.toast(labels[format] || "Exported");
}

/* ─────────────────────────────────────────────────────────────
   SETTINGS
   ───────────────────────────────────────────────────────────── */
function initSettings() {
  const weeklyGoalInput = document.getElementById("weeklyGoalInput");
  const weeklyGoalReadout = document.getElementById("weeklyGoalReadout");

  const openSettings = () => {
    weeklyGoalInput.value = ZG.getWeeklyGoalTarget();
    weeklyGoalReadout.textContent = weeklyGoalInput.value;
    privacyToggle?.classList.toggle("on", ZG.getPrivacyVeil());
    privacyToggle?.setAttribute("aria-checked", String(ZG.getPrivacyVeil()));
    notifyToggle?.classList.toggle("on", ZG.notificationsEnabled());
    notifyToggle?.setAttribute("aria-checked", String(ZG.notificationsEnabled()));
    riskReminderToggle?.classList.toggle("on", ZG.riskRemindersEnabled());
    riskReminderToggle?.setAttribute("aria-checked", String(ZG.riskRemindersEnabled()));
    calmToggle?.classList.toggle("on", ZG.getCalmMode());
    calmToggle?.setAttribute("aria-checked", String(ZG.getCalmMode()));
    contextToggle?.classList.toggle("on", !!window.Context?.isEnabled?.());
    contextToggle?.setAttribute("aria-checked", String(!!window.Context?.isEnabled?.()));
    mindfulCheckinsToggle?.classList.toggle("on", !!window.Focus?.mindfulCheckinsEnabled?.());
    mindfulCheckinsToggle?.setAttribute("aria-checked", String(!!window.Focus?.mindfulCheckinsEnabled?.()));
    mindfulPauseToggle?.classList.toggle("on", !!window.Focus?.mindfulPauseEnabled?.());
    mindfulPauseToggle?.setAttribute("aria-checked", String(!!window.Focus?.mindfulPauseEnabled?.()));
    window.Safety?.renderSettingsBlock?.();
    window.AutoBackup?.renderSettingsBlock?.();
    window.NativeApp?.renderSettings?.();
    _renderBackupNote();
    openModal("settingsModal");
  };
  const privacyToggle = document.getElementById("privacyToggle");
  privacyToggle?.addEventListener("click", () => {
    const next = !ZG.getPrivacyVeil();
    ZG.setPrivacyVeil(next);
    privacyToggle.classList.toggle("on", next);
    privacyToggle.setAttribute("aria-checked", String(next));
  });

  const notifyToggle = document.getElementById("notifyToggle");
  notifyToggle?.addEventListener("click", async () => {
    const turningOn = !ZG.notificationsEnabled();
    if (turningOn) {
      const granted = await _requestNotifyPermission();
      if (!granted) { ZG.toast(window.NativeBridge?.isNative?.() ? "Notifications blocked — allow them in Android Settings › Apps › NASVOGrow" : "Notifications blocked — enable them in your browser settings"); return; }
    }
    ZG.setNotificationsEnabled(turningOn);
    notifyToggle.classList.toggle("on", turningOn);
    notifyToggle.setAttribute("aria-checked", String(turningOn));
    ZG.toast(turningOn ? "Local reminders on" : "Local reminders off");
  });

  const riskReminderToggle = document.getElementById("riskReminderToggle");
  riskReminderToggle?.addEventListener("click", () => {
    const next = !ZG.riskRemindersEnabled();
    ZG.setRiskRemindersEnabled(next);
    riskReminderToggle.classList.toggle("on", next);
    riskReminderToggle.setAttribute("aria-checked", String(next));
    ZG.toast(next ? "Risk-window check-ins on" : "Risk-window check-ins off");
  });

  const calmToggle = document.getElementById("calmModeToggle");
  calmToggle?.addEventListener("click", () => {
    const next = !ZG.getCalmMode();
    ZG.setCalmMode(next);
    calmToggle.classList.toggle("on", next);
    calmToggle.setAttribute("aria-checked", String(next));
    ZG.toast(next ? "Calm mode on" : "Calm mode off");
    window.Growth?.render?.(); // refresh Growth tab immediately if it's the active section
  });

  const contextToggle = document.getElementById("contextToggle");
  contextToggle?.addEventListener("click", () => {
    const next = !window.Context?.isEnabled?.();
    window.Context?.setEnabled?.(next);
    contextToggle.classList.toggle("on", next);
    contextToggle.setAttribute("aria-checked", String(next));
    ZG.toast(next ? "Sleep & context tracking on" : "Sleep & context tracking off");
    window.Insights?.render?.(); // a fresh toggle should surface/hide its Insights rows right away too
  });

  const mindfulCheckinsToggle = document.getElementById("mindfulCheckinsToggle");
  mindfulCheckinsToggle?.addEventListener("click", () => {
    const next = !window.Focus?.mindfulCheckinsEnabled?.();
    window.Focus?.setMindfulCheckins?.(next);
    mindfulCheckinsToggle.classList.toggle("on", next);
    mindfulCheckinsToggle.setAttribute("aria-checked", String(next));
    ZG.toast(next ? "Mindful check-ins on" : "Mindful check-ins off");
  });

  const mindfulPauseToggle = document.getElementById("mindfulPauseToggle");
  mindfulPauseToggle?.addEventListener("click", () => {
    const next = !window.Focus?.mindfulPauseEnabled?.();
    window.Focus?.setMindfulPause?.(next);
    mindfulPauseToggle.classList.toggle("on", next);
    mindfulPauseToggle.setAttribute("aria-checked", String(next));
    ZG.toast(next ? "Mindful pause on" : "Mindful pause off");
  });

  const printMonthInput = document.getElementById("printMonthInput");
  if (printMonthInput && !printMonthInput.value) {
    const now = new Date();
    printMonthInput.value = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
  }
  document.getElementById("printSummaryBtn")?.addEventListener("click", () => {
    window.ExportPdf?.openPrintSummary?.(printMonthInput?.value);
  });

  document.getElementById("settingsBtnDesktop")?.addEventListener("click", openSettings);
  document.getElementById("settingsBtnMobile")?.addEventListener("click", openSettings);
  document.getElementById("closeSettingsBtn")?.addEventListener("click", () => closeModal("settingsModal"));

  weeklyGoalInput?.addEventListener("input", () => {
    weeklyGoalReadout.textContent = weeklyGoalInput.value;
    ZG.setWeeklyGoalTarget(Number(weeklyGoalInput.value));
    ZG.refreshChrome();
  });

  document.querySelectorAll(".theme-pill").forEach(pill => {
    pill.addEventListener("click", () => applyTheme(pill.dataset.theme));
  });

  document.getElementById("exportDataBtn")?.addEventListener("click", _exportData);

  document.getElementById("importDataBtn")?.addEventListener("click", () => {
    document.getElementById("importDataFile")?.click();
  });

  document.getElementById("importDataFile")?.addEventListener("change", (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      let parsed;
      try { parsed = JSON.parse(reader.result); }
      catch { ZG.toast("That file doesn't look like a valid backup"); return; }

      // Auto-detect which of the two backup formats this is (see
      // portable-export.js) rather than needing a second import button —
      // both are just "a backup file," and the person shouldn't have to
      // remember which kind they made.
      if (parsed?.schema === window.PortableExport?.SCHEMA_ID) {
        const errors = window.PortableExport.validate(parsed);
        if (errors.length) { ZG.toast(errors[0]); return; }
        const ok = await ZG.confirm({ title: "Import this portable backup?", body: "This replaces everything currently on this device — export a fresh backup first if you're not sure.", confirmLabel: "Import & replace", danger: true });
        if (!ok) return;
        window.PortableExport.apply(parsed, { mode: "replace" });
        ZG.toast("Data imported");
        setTimeout(() => location.reload(), 600);
        return;
      }

      const keys = Object.keys(parsed).filter(k => k.startsWith("zg_"));
      if (!keys.length) { ZG.toast("No NASVOGrow data found in that file"); return; }
      const ok = await ZG.confirm({ title: `Import ${keys.length} data field${keys.length === 1 ? "" : "s"}?`, body: "This replaces everything currently on this device — export a fresh backup first if you're not sure.", confirmLabel: "Import & replace", danger: true });
      if (!ok) return;
      Object.keys(localStorage).filter(k => k.startsWith("zg_")).forEach(k => localStorage.removeItem(k));
      keys.forEach(k => localStorage.setItem(k, parsed[k]));
      ZG.toast("Data imported");
      setTimeout(() => location.reload(), 600);
    };
    reader.onerror = () => ZG.toast("Couldn't read that file");
    reader.readAsText(file);
    e.target.value = "";
  });

  document.getElementById("importHabitsBtn")?.addEventListener("click", () => {
    document.getElementById("importHabitsFile")?.click();
  });

  document.getElementById("importHabitsFile")?.addEventListener("change", (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      const cats = window.Habits?.CATEGORIES || {};
      const parsed = String(reader.result).split(/\r?\n/)
        .map(l => l.split(","))
        .map(cols => ({
          name: (cols[0] || "").trim().replace(/^"|"$/g, ""),
          category: (cols[1] || "").trim().toLowerCase().replace(/^"|"$/g, ""),
        }))
        .filter(r => r.name && !["habit", "name", "habits"].includes(r.name.toLowerCase()));
      const seen = new Set();
      const rows = parsed.filter(r => { const k = r.name.toLowerCase(); if (seen.has(k)) return false; seen.add(k); return true; });
      if (!rows.length) { ZG.toast("No habit names found in that file"); return; }
      const existing = new Set((window.Habits?.load?.().habits || []).map(h => h.name.toLowerCase()));
      const fresh = rows.filter(r => !existing.has(r.name.toLowerCase()));
      if (!fresh.length) { ZG.toast("Those habits are already on your list"); return; }
      const ok = await ZG.confirm({ title: `Add ${fresh.length} habit${fresh.length === 1 ? "" : "s"}?`, body: `${fresh.slice(0, 5).map(r => r.name).join(", ")}${fresh.length > 5 ? "…" : ""}`, confirmLabel: "Add" });
      if (!ok) return;
      fresh.forEach(r => window.Habits?.add?.(r.name, cats[r.category] ? r.category : undefined));
      ZG.toast(`${fresh.length} habit${fresh.length === 1 ? "" : "s"} added`);
    };
    reader.onerror = () => ZG.toast("Couldn't read that file");
    reader.readAsText(file);
    e.target.value = "";
  });

  document.getElementById("resetDataBtn")?.addEventListener("click", async () => {
    const ok = await ZG.confirm({ title: "Reset all data?", body: "This can't be undone.", confirmLabel: "Reset everything", danger: true });
    if (!ok) return;
    Object.keys(localStorage).filter(k => k.startsWith("zg_")).forEach(k => localStorage.removeItem(k));
    ZG.toast("Data reset");
    setTimeout(() => location.reload(), 600);
  });
}

/* ─────────────────────────────────────────────────────────────
   INIT
   ───────────────────────────────────────────────────────────── */
document.addEventListener("DOMContentLoaded", () => {
  // Best-effort request not to have this origin's storage evicted under disk
  // pressure. Support varies by browser and it can silently no-op, but it
  // costs nothing to ask — this data is worth protecting.
  navigator.storage?.persist?.().catch(() => {});

  applyTheme(localStorage.getItem("zg_theme") || "dark", true);
  document.body.classList.toggle("privacy-veil", ZG.getPrivacyVeil());
  document.body.classList.toggle("calm-mode", ZG.getCalmMode());

  document.querySelectorAll("[data-sec]").forEach(btn => {
    btn.addEventListener("click", () => showSection(btn.dataset.sec));
  });
  document.querySelectorAll("[data-goto]").forEach(btn => {
    btn.addEventListener("click", () => showSection(btn.dataset.goto));
  });

  initSettings();
  initOnboarding();

  // First-run welcome
  if (!localStorage.getItem("zg_onboarded")) {
    openModal("welcomeModal");
  } else {
    setTimeout(_maybeNudgeBackup, 1200);
    setTimeout(_maybeSendReminder, 4000);
    setTimeout(_maybeSendRiskReminder, 4200);
    setTimeout(() => window.AutoBackup?.maybeRunDailyBackup?.(), 1500);
  }

  const validSections = ["home", "habits", "recovery", "growth"];
  const legacySectionMap = { challenges: "recovery", journal: "recovery", insights: "habits" };

  // Manifest shortcuts (long-press the home-screen icon) land here as
  // /index.html?section=habits etc. — honor that over the remembered
  // last section, then strip it from the URL so a refresh/share doesn't
  // keep re-triggering it. A shortcut can also carry ?action=, handled
  // by _runQuickAction below once the destination section has painted.
  const shortcutParams = new URLSearchParams(location.search);
  const shortcutSection = shortcutParams.get("section");
  const shortcutAction = shortcutParams.get("action");
  if (shortcutSection || shortcutAction) history.replaceState(null, "", location.pathname);

  const last = shortcutSection || localStorage.getItem("zg_last_section") || "home";
  const resolved = legacySectionMap[last] || last;
  showSection(validSections.includes(resolved) ? resolved : "home");
  ZG.refreshChrome();
  if (shortcutAction) setTimeout(() => _runQuickAction(shortcutAction), 260);

  // Native shell (Capacitor): from here on, notification taps / shortcuts / deep links may route in.
  ZG.routeReady = true;
  window.NativeBridge?.flushRoute?.();
});

/** Go to a section (and optionally run a quick action) — used by notification taps,
 *  launcher shortcuts and nasvogrow:// links in the Android app. Goes through the
 *  guarded showSection, so a PIN-locked Recovery still asks for the PIN. */
ZG.routeTo = function (section, action) {
  const valid = ["home", "habits", "recovery", "growth"];
  (window.showSection || showSection)(valid.includes(section) ? section : "home");
  if (action) setTimeout(() => _runQuickAction(action), 260);
};

/** Android back button: close the top sheet/dialog, else go Home. Returns true when it
 *  handled the press; false lets the shell show "press back again to exit". */
ZG.handleBack = function () {
  if (document.getElementById("zrLockModal")) return false;            // locked: leave the app, never dismiss the lock
  const wraps = document.querySelectorAll(".celebrate-wrap");
  if (wraps.length) {
    const top = wraps[wraps.length - 1];
    const btn = top.querySelector('[id$="Cancel"], [id$="Close"], [data-sheet-close]');
    if (btn) btn.click();
    else document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
    return true;
  }
  const modal = document.querySelector(".modal.show");
  if (modal) { if (modal.classList.contains("fullscreen")) return false; closeModal(); return true; }
  const sec = document.querySelector(".app-section.active")?.id.replace("Section", "");
  if (sec && sec !== "home") { (window.showSection || showSection)("home"); return true; }
  return false;
};

/* ─────────────────────────────────────────────────────────────
   OFFLINE — register the service worker so the installed app
   still opens (from cache) with no connection, not just faster.
   ───────────────────────────────────────────────────────────── */
if ("serviceWorker" in navigator && !window.NativeBridge?.isNative?.()) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/sw.js").catch(() => {});
  });
}
