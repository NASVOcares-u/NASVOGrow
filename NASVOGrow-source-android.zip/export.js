"use strict";
/* ═══════════════════════════════════════════════════════════════
   EXPORT — a printable, one-page monthly summary.

   Why this uses window.print() instead of a PDF library: Grow is a
   static, no-build, dependency-free site on purpose (see netlify.toml
   and app.js's Store/addXP comments) — pulling in a PDF-generation
   library would mean vendoring real weight for something the browser
   already does for free. Every browser's print dialog has "Save as
   PDF" built in, works fully offline, and needs zero new dependencies
   or CSP changes. The trade-off is real: this can't do pixel-perfect
   custom layout the way a PDF library could, and it leans on whatever
   the browser/OS print pipeline does. For a plain, readable monthly
   summary, that trade-off is worth it here.

   Nothing here is sent anywhere — the summary is built from data
   already in localStorage and rendered straight into a hidden
   #printSummary container that only becomes visible to print media
   (see styles.css's print section).
═══════════════════════════════════════════════════════════════ */
const ExportPdf = (() => {
  const MOOD_LABELS = window.Journal?.MOODS
    ? Object.fromEntries(Object.entries(window.Journal.MOODS).map(([k, v]) => [k, v.label]))
    : { good: "Good", okay: "Okay", heavy: "Heavy", rough: "Rough" };

  function _monthLabel(y, mIdx) { return new Date(y, mIdx, 1).toLocaleDateString("en", { month: "long", year: "numeric" }); }
  function _inMonthTs(ts, y, mIdx) { const d = new Date(ts); return d.getFullYear() === y && d.getMonth() === mIdx; }
  function _inMonthDateStr(dateStr, y, mIdx) { const d = new Date(dateStr); return d.getFullYear() === y && d.getMonth() === mIdx; }

  function _buildSummaryHtml(y, mIdx) {
    const esc = ZG.esc;
    const calm = ZG.getCalmMode();
    const name = Store.get("zg_name", "");
    const total = ZG.getTotalActions();
    const tier = ZG.getTier(total);
    const streak = ZG.getStreak();

    const h = window.Habits?.load?.() || { habits: [], log: {} };
    const habitRows = h.habits.map(habit => {
      const count = Object.keys(h.log).filter(d => _inMonthDateStr(d, y, mIdx) && (h.log[d] || []).includes(habit.id)).length;
      return { name: habit.name, category: window.Habits?.categoryLabel?.(habit.category) || "General", count };
    });

    const rec = window.Recovery?.load?.() || { trackers: {} };
    const recRows = Object.entries(rec.trackers).map(([id, t]) => {
      const type = window.Recovery.TYPES[id];
      const urges = (t.urges || []).filter(u => _inMonthTs(u.ts, y, mIdx)).length;
      const relapses = (t.relapses || []).filter(rl => _inMonthTs(rl.ts, y, mIdx)).length;
      return { label: type?.label || id, urges, relapses, isEating: !!type?.isEating };
    });

    const entries = window.Journal?.load?.() || [];
    const monthEntries = entries.filter(e => _inMonthDateStr(e.date, y, mIdx));
    const moodCounts = {};
    monthEntries.forEach(e => { if (e.mood) moodCounts[e.mood] = (moodCounts[e.mood] || 0) + 1; });
    const reflections = Store.get("zg_reflections", []).filter(rf => _inMonthDateStr(rf.date, y, mIdx));

    const ch = window.Challenges?.load?.() || { history: [] };
    const monthChallenges = (ch.history || []).filter(c => c.completed && _inMonthTs(c.endTs, y, mIdx));

    const vitalsEntries = (window.Vitals?.load?.() || []).filter(v => _inMonthDateStr(v.weekKey, y, mIdx)).sort((a, b) => a.ts - b.ts);

    // Name, username, and motto are the "shown to others" identity fields —
    // the private "why" field is deliberately left out of every export,
    // print included, since its whole point is that it's for the person
    // alone (see profile.js).
    const username = window.Profile?.getUsername?.() || "";
    const motto = window.Profile?.getMotto?.() || "";
    const avatarUrl = window.Profile?.getAvatar?.() || "";

    return `
      <div class="print-page">
        <div class="print-head">
          ${avatarUrl ? `<img class="print-avatar" src="${avatarUrl}" alt=""/>` : ""}
          <div>
            <div class="print-brand">NASVOGrow</div>
            <div class="print-title">Monthly Summary — ${esc(_monthLabel(y, mIdx))}</div>
            ${(name || username) ? `<div class="print-sub">${[name, username ? `@${username}` : ""].filter(Boolean).map(esc).join(" · ")}</div>` : ""}
          </div>
        </div>
        ${motto ? `<p class="print-motto">“${esc(motto)}”</p>` : ""}

        <div class="print-section">
          <div class="print-section-title">Overview</div>
          <div class="print-stat-row">
            <div class="print-stat"><b>${streak}</b><span>Current streak (days)</span></div>
            ${!calm ? `<div class="print-stat"><b>${esc(tier.name)}</b><span>Identity tier</span></div>` : ""}
            ${!calm ? `<div class="print-stat"><b>${total}</b><span>Total identity actions</span></div>` : ""}
          </div>
        </div>

        <div class="print-section">
          <div class="print-section-title">Habits</div>
          ${habitRows.length ? `
          <table class="print-table">
            <thead><tr><th>Habit</th><th>Category</th><th>Days this month</th></tr></thead>
            <tbody>${habitRows.map(rrow => `<tr><td>${esc(rrow.name)}</td><td>${esc(rrow.category)}</td><td>${rrow.count}</td></tr>`).join("")}</tbody>
          </table>` : `<p class="print-empty">No habits tracked.</p>`}
        </div>

        <div class="print-section">
          <div class="print-section-title">Recovery</div>
          ${recRows.length ? `
          <table class="print-table">
            <thead><tr><th>Tracker</th><th>Resisted</th><th>${"Reset / episode"}</th></tr></thead>
            <tbody>${recRows.map(rr => `<tr><td>${esc(rr.label)}</td><td>${rr.urges}</td><td>${rr.relapses}</td></tr>`).join("")}</tbody>
          </table>` : `<p class="print-empty">No recovery trackers active.</p>`}
        </div>

        <div class="print-section">
          <div class="print-section-title">Journal</div>
          <p>${monthEntries.length} entr${monthEntries.length === 1 ? "y" : "ies"} written${reflections.length ? `, ${reflections.length} weekly reflection${reflections.length === 1 ? "" : "s"}` : ""}.</p>
          ${Object.keys(moodCounts).length ? `<p class="print-moods">${Object.entries(moodCounts).map(([k, v]) => `${esc(MOOD_LABELS[k] || k)}: ${v}`).join(" · ")}</p>` : ""}
        </div>

        <div class="print-section">
          <div class="print-section-title">Weekly check-in</div>
          ${vitalsEntries.length ? `
          <table class="print-table">
            <thead><tr><th>Week of</th><th>Craving</th><th>Mood</th><th>Energy</th></tr></thead>
            <tbody>${vitalsEntries.map(v => `<tr><td>${new Date(v.weekKey).toLocaleDateString("en", { month: "short", day: "numeric" })}</td><td>${v.craving}/10</td><td>${v.mood}/10</td><td>${v.energy}/10</td></tr>`).join("")}</tbody>
          </table>` : `<p class="print-empty">No weekly check-ins this month.</p>`}
        </div>

        <div class="print-section">
          <div class="print-section-title">Challenges completed</div>
          ${monthChallenges.length ? `<ul class="print-list">${monthChallenges.map(c => `<li>${esc(window.Challenges?.DEFS?.[c.id]?.name || c.id)} — ${new Date(c.endTs).toLocaleDateString("en", { month: "short", day: "numeric" })}</li>`).join("")}</ul>` : `<p class="print-empty">None this month.</p>`}
        </div>

        <div class="print-foot">Generated locally in your browser on ${new Date().toLocaleDateString("en", { month: "short", day: "numeric", year: "numeric" })} — nothing left this device to create this page.</div>
      </div>`;
  }

  function openPrintSummary(monthStr) {
    const parts = (monthStr || "").split("-").map(Number);
    if (parts.length !== 2 || !parts[0] || !parts[1]) { ZG.toast("Pick a month first"); return; }
    const [y, m] = parts;
    const container = document.getElementById("printSummary");
    if (!container) return;
    container.innerHTML = _buildSummaryHtml(y, m - 1);
    window.print();
  }

  window.addEventListener("afterprint", () => {
    const container = document.getElementById("printSummary");
    if (container) container.innerHTML = "";
  });

  return { openPrintSummary };
})();
window.ExportPdf = ExportPdf;
