package __APP_ID__;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.widget.RemoteViews;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Home-screen widget: today's habits and the streak. It can't read the WebView's localStorage,
 * so the web app pushes a tiny snapshot (see NativeApp.pushWidgetNow) into SharedPreferences.
 * Habits and streak only. Nothing from Recovery or the journal ever reaches the widget.
 */
public class NasvoWidgetProvider extends AppWidgetProvider {

    private static final String PREFS = "nasvo_widget";

    static void store(Context c, boolean enabled, int done, int total, int streak, String date, String title) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean("enabled", enabled)
            .putInt("done", done)
            .putInt("total", total)
            .putInt("streak", streak)
            .putString("date", date == null ? "" : date)
            .putString("title", title == null || title.isEmpty() ? "NASVOGrow" : title)
            .apply();
        refreshAll(c);
    }

    static void refreshAll(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] ids = m.getAppWidgetIds(new ComponentName(c, NasvoWidgetProvider.class));
        for (int id : ids) m.updateAppWidget(id, build(c));
    }

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) m.updateAppWidget(id, build(c));
    }

    static RemoteViews build(Context c) {
        SharedPreferences p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.nasvo_widget);

        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        String date = p.getString("date", "");
        boolean enabled = p.getBoolean("enabled", false);
        int done = p.getInt("done", 0), total = p.getInt("total", 0), streak = p.getInt("streak", 0);

        v.setTextViewText(R.id.nasvo_widget_title, p.getString("title", "NASVOGrow"));

        if (!enabled && !date.isEmpty()) {
            v.setTextViewText(R.id.nasvo_widget_main, "Widget is off");
            v.setTextViewText(R.id.nasvo_widget_sub, "Turn it on in the app's Settings");
        } else if (date.isEmpty()) {
            v.setTextViewText(R.id.nasvo_widget_main, "Open the app");
            v.setTextViewText(R.id.nasvo_widget_sub, "to set up today");
        } else if (!date.equals(today)) {
            // The snapshot is from an earlier day; don't show yesterday's numbers as if they were today's.
            v.setTextViewText(R.id.nasvo_widget_main, "A new day");
            v.setTextViewText(R.id.nasvo_widget_sub, "Open the app to update");
        } else if (total == 0) {
            v.setTextViewText(R.id.nasvo_widget_main, "No habits yet");
            v.setTextViewText(R.id.nasvo_widget_sub, streak > 0 ? streak + "-day streak" : "Tap to add one");
        } else {
            v.setTextViewText(R.id.nasvo_widget_main, done + " of " + total + (total == 1 ? " habit" : " habits"));
            v.setTextViewText(R.id.nasvo_widget_sub, streak > 0 ? streak + "-day streak" : (done == total ? "All done today" : "Still open today"));
        }

        Intent open = new Intent(Intent.ACTION_VIEW, Uri.parse("nasvogrow://open?section=habits"));
        open.setClassName(c.getPackageName(), c.getPackageName() + ".MainActivity");
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pi = PendingIntent.getActivity(c, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        v.setOnClickPendingIntent(R.id.nasvo_widget_root, pi);
        return v;
    }
}
