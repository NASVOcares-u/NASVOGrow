package __APP_ID__;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;

/**
 * Small local plugin for the things the official Capacitor plugins don't cover:
 *   - saveBackupFile / pruneBackups : automatic backups in Documents/NASVOGrow (Android 10+, no permission needed)
 *   - biometricStatus / biometricAuthenticate : fingerprint / face on the PIN screen (androidx.biometric)
 *   - updateWidget : today's numbers for the home-screen widget
 * Everything stays on the device.
 */
@CapacitorPlugin(name = "NasvoNative")
public class NasvoNativePlugin extends Plugin {

    private static final String BACKUP_DIR = "NASVOGrow";
    private static final String NAME_RE = "[A-Za-z0-9._-]{1,90}";

    /* ───────────────────────── backups ───────────────────────── */

    @PluginMethod
    public void saveBackupFile(PluginCall call) {
        String filename = call.getString("filename");
        String text = call.getString("text");
        if (filename == null || text == null || !filename.matches(NAME_RE)) {
            call.reject("bad arguments");
            return;
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            call.reject("Automatic backup needs Android 10 or newer");
            return;
        }
        try {
            ContentResolver cr = getContext().getContentResolver();
            Uri collection = MediaStore.Files.getContentUri("external");
            String relPath = Environment.DIRECTORY_DOCUMENTS + "/" + BACKUP_DIR;

            // A second backup on the same day replaces the first instead of making "name (1).json".
            for (long id : findOwnFiles(cr, collection, relPath, filename, true)) {
                cr.delete(ContentUris.withAppendedId(collection, id), null, null);
            }

            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, filename);
            v.put(MediaStore.MediaColumns.MIME_TYPE, "application/json");
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, relPath);
            Uri uri = cr.insert(collection, v);
            if (uri == null) throw new IOException("MediaStore insert returned null");
            try (OutputStream os = cr.openOutputStream(uri, "wt")) {
                if (os == null) throw new IOException("could not open output stream");
                os.write(text.getBytes(StandardCharsets.UTF_8));
            }
            call.resolve();
        } catch (Exception e) {
            call.reject(String.valueOf(e.getMessage()), e);
        }
    }

    @PluginMethod
    public void pruneBackups(PluginCall call) {
        String prefix = call.getString("prefix");
        int keep = call.getInt("keep", 14);
        if (prefix == null || !prefix.matches(NAME_RE) || keep < 1) {
            call.reject("bad arguments");
            return;
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            call.resolve();
            return;
        }
        try {
            ContentResolver cr = getContext().getContentResolver();
            Uri collection = MediaStore.Files.getContentUri("external");
            String relPath = Environment.DIRECTORY_DOCUMENTS + "/" + BACKUP_DIR;
            // Names are prefix + ISO date, so sorting by name == sorting by age.
            List<long[]> ordered = new ArrayList<>();
            String[] proj = {MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME};
            String sel = MediaStore.MediaColumns.DISPLAY_NAME + " LIKE ? AND " + MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ?";
            String[] args = {prefix + "%", relPath + "%"};
            try (Cursor c = cr.query(collection, proj, sel, args, MediaStore.MediaColumns.DISPLAY_NAME + " ASC")) {
                while (c != null && c.moveToNext()) {
                    ordered.add(new long[]{c.getLong(0)});
                }
            }
            for (int i = 0; i < ordered.size() - keep; i++) {
                cr.delete(ContentUris.withAppendedId(collection, ordered.get(i)[0]), null, null);
            }
            call.resolve();
        } catch (Exception e) {
            call.reject(String.valueOf(e.getMessage()), e);
        }
    }

    private long[] findOwnFiles(ContentResolver cr, Uri collection, String relPath, String name, boolean exact) {
        List<Long> ids = new ArrayList<>();
        String[] proj = {MediaStore.MediaColumns._ID};
        String sel = MediaStore.MediaColumns.DISPLAY_NAME + (exact ? " = ?" : " LIKE ?") + " AND " + MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ?";
        String[] args = {name, relPath + "%"};
        try (Cursor c = cr.query(collection, proj, sel, args, null)) {
            while (c != null && c.moveToNext()) ids.add(c.getLong(0));
        }
        long[] out = new long[ids.size()];
        for (int i = 0; i < out.length; i++) out[i] = ids.get(i);
        return out;
    }

    /* ───────────────────────── biometrics ───────────────────────── */

    @PluginMethod
    public void biometricStatus(PluginCall call) {
        int r = BiometricManager.from(getContext()).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG);
        JSObject o = new JSObject();
        o.put("available", r == BiometricManager.BIOMETRIC_SUCCESS);
        call.resolve(o);
    }

    @PluginMethod
    public void biometricAuthenticate(final PluginCall call) {
        if (!(getActivity() instanceof FragmentActivity)) {
            call.reject("no activity");
            return;
        }
        final FragmentActivity activity = (FragmentActivity) getActivity();
        final String title = call.getString("title", "Unlock");
        final String subtitle = call.getString("subtitle", "");
        final String cancel = call.getString("cancel", "Use PIN");
        final Executor executor = ContextCompat.getMainExecutor(activity);

        activity.runOnUiThread(() -> {
            try {
                BiometricPrompt prompt = new BiometricPrompt(activity, executor, new BiometricPrompt.AuthenticationCallback() {
                    @Override
                    public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                        call.resolve();
                    }

                    @Override
                    public void onAuthenticationError(int errorCode, CharSequence errString) {
                        call.reject(String.valueOf(errString), String.valueOf(errorCode));
                    }
                    // onAuthenticationFailed (a non-matching finger) is deliberately ignored: the system prompt stays up and lets them retry.
                });
                BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                    .setTitle(title)
                    .setSubtitle(subtitle)
                    .setNegativeButtonText(cancel)
                    .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
                    .build();
                prompt.authenticate(info);
            } catch (Exception e) {
                call.reject(String.valueOf(e.getMessage()), e);
            }
        });
    }

    /* ───────────────────────── widget ───────────────────────── */

    @PluginMethod
    public void updateWidget(PluginCall call) {
        NasvoWidgetProvider.store(
            getContext(),
            Boolean.TRUE.equals(call.getBoolean("enabled", false)),
            call.getInt("done", 0),
            call.getInt("total", 0),
            call.getInt("streak", 0),
            call.getString("date", ""),
            call.getString("title", "NASVOGrow")
        );
        call.resolve();
    }
}
