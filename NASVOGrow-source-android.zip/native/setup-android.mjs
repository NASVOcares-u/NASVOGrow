#!/usr/bin/env node
// NASVOGrow — applies the native layer to the generated android/ project.
//
//   npx cap add android        (once, creates android/)
//   node native/setup-android.mjs
//   npx cap sync android
//
// Safe to re-run: every patch checks for its own "NASVO" marker first. Re-run it any time
// android/ is recreated, or after bumping "version" in package.json (it sets versionCode/Name).
//
// What it does
//   • copies icons, splash colour, notification icon, widget layout and strings into res/
//   • adds the NasvoNative plugin, widget provider and MainActivity (package = your app id)
//   • writes launcher shortcuts (long-press the icon) that open nasvogrow:// links
//   • AndroidManifest: nasvogrow:// link filter, shortcuts, widget receiver, permissions,
//     android:allowBackup (see settings below)
//   • app/build.gradle: androidx.biometric, release signing from environment variables,
//     versionCode/versionName from package.json
//
// It only ever touches files under android/. If an anchor it expects isn't found (Capacitor
// changed its template) it prints a WARN line saying what to add by hand rather than guessing.
import fs from 'node:fs';
import path from 'node:path';

/* ───────────── settings you may want to change ───────────── */
// Android's Auto Backup copies app data (including the WebView's localStorage, i.e. everything
// here) to the person's Google account. privacy.html says data never leaves the device, so the
// default is OFF. Turn it on only if you also change that wording.
const ALLOW_AUTO_BACKUP = false;
// The app never goes online by itself. Removing INTERNET makes that a hard guarantee, but it is
// an untested combination with Capacitor's WebView, so it is OFF until you've tried it on a device.
const REMOVE_INTERNET_PERMISSION = false;
// Long-press launcher shortcuts. Delete 'urge' if you don't want that label visible on a home screen.
const SHORTCUTS = [
  { id: 'addhabit', short: 'nasvo_sc_addhabit_short', long: 'nasvo_sc_addhabit_long', url: 'nasvogrow://open?section=habits&action=addhabit' },
  { id: 'journal',  short: 'nasvo_sc_journal_short',  long: 'nasvo_sc_journal_long',  url: 'nasvogrow://open?section=recovery&action=journal' },
  { id: 'urge',     short: 'nasvo_sc_urge_short',     long: 'nasvo_sc_urge_long',     url: 'nasvogrow://open?section=recovery&action=urge' },
];
/* ─────────────────────────────────────────────────────────── */

const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const ANDROID = path.join(ROOT, 'android');
const MAIN = path.join(ANDROID, 'app/src/main');
const RES = path.join(MAIN, 'res');
const NATIVE = path.join(ROOT, 'native');

const log = { ok: (m) => console.log('  ok   ' + m), skip: (m) => console.log('  skip ' + m), warn: (m) => { warnings.push(m); console.log('  WARN ' + m); } };
const warnings = [];
const read = (p) => fs.readFileSync(p, 'utf8');
const write = (p, s) => { fs.mkdirSync(path.dirname(p), { recursive: true }); fs.writeFileSync(p, s); };

if (!fs.existsSync(ANDROID)) {
  console.error('android/ not found. Run:  npx cap add android   (then re-run this script)');
  process.exit(1);
}
const cfg = JSON.parse(read(path.join(ROOT, 'capacitor.config.json')));
const pkgJson = JSON.parse(read(path.join(ROOT, 'package.json')));
const APP_ID = cfg.appId;
if (!/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/.test(APP_ID || '')) {
  console.error(`capacitor.config.json appId "${APP_ID}" is not a valid Android package name`);
  process.exit(1);
}

/* ── 1. resources ── */
console.log('Resources');
const copyTree = (src, dst) => {
  for (const e of fs.readdirSync(src, { withFileTypes: true })) {
    const s = path.join(src, e.name), d = path.join(dst, e.name);
    if (e.isDirectory()) copyTree(s, d);
    else { fs.mkdirSync(path.dirname(d), { recursive: true }); fs.copyFileSync(s, d); }
  }
};
copyTree(path.join(NATIVE, 'android-res'), RES);
// The template ships a branded splash.png in several drawable-* folders; replace each with the flat colour.
let splashCount = 0;
for (const d of fs.readdirSync(RES)) {
  const f = path.join(RES, d, 'splash.png');
  if (d.startsWith('drawable') && fs.existsSync(f)) { fs.copyFileSync(path.join(NATIVE, 'android-res/drawable/splash.png'), f); splashCount++; }
}
log.ok(`icons, adaptive icon, notification icon, widget layout/strings; splash replaced in ${splashCount} folder(s)`);

/* ── 2. Java sources ── */
console.log('Java sources');
const javaRoot = path.join(MAIN, 'java');
const findMain = (dir) => {
  if (!fs.existsSync(dir)) return null;
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) { const r = findMain(p); if (r) return r; }
    else if (e.name === 'MainActivity.java' || e.name === 'MainActivity.kt') return p;
  }
  return null;
};
const existingMain = findMain(javaRoot);
let pkgName = APP_ID;
let javaDir = path.join(javaRoot, ...APP_ID.split('.'));
if (existingMain) {
  if (existingMain.endsWith('.kt')) log.warn('MainActivity is Kotlin; replace it with native/java/MainActivity.java or add registerPlugin(NasvoNativePlugin.class) before super.onCreate by hand.');
  const m = /^\s*package\s+([\w.]+)\s*;/m.exec(read(existingMain));
  if (m) { pkgName = m[1]; javaDir = path.dirname(existingMain); }
  if (pkgName !== APP_ID) log.warn(`MainActivity's package (${pkgName}) differs from appId (${APP_ID}); using ${pkgName} for the new classes.`);
}
for (const f of ['NasvoNativePlugin.java', 'NasvoWidgetProvider.java', 'MainActivity.java']) {
  if (f === 'MainActivity.java' && existingMain?.endsWith('.kt')) continue;
  write(path.join(javaDir, f), read(path.join(NATIVE, 'java', f)).replaceAll('__APP_ID__', pkgName));
}
log.ok(`NasvoNativePlugin, NasvoWidgetProvider, MainActivity -> ${path.relative(ANDROID, javaDir)}`);

/* ── 3. shortcuts.xml (needs the real package name, so it's generated) ── */
const sc = SHORTCUTS.map((s) => `    <shortcut
        android:shortcutId="${s.id}"
        android:enabled="true"
        android:icon="@mipmap/ic_launcher"
        android:shortcutShortLabel="@string/${s.short}"
        android:shortcutLongLabel="@string/${s.long}">
        <intent
            android:action="android.intent.action.VIEW"
            android:targetPackage="${APP_ID}"
            android:targetClass="${pkgName}.MainActivity"
            android:data="${s.url.replaceAll('&', '&amp;')}" />
    </shortcut>`).join('\n');
write(path.join(RES, 'xml/shortcuts.xml'), `<?xml version="1.0" encoding="utf-8"?>\n<!-- generated by native/setup-android.mjs -->\n<shortcuts xmlns:android="http://schemas.android.com/apk/res/android">\n${sc}\n</shortcuts>\n`);
log.ok(`launcher shortcuts: ${SHORTCUTS.map((s) => s.id).join(', ')}`);

/* ── 4. AndroidManifest.xml ── */
console.log('AndroidManifest.xml');
const manifestPath = path.join(MAIN, 'AndroidManifest.xml');
let mf = read(manifestPath);
const mfOrig = mf;

// 4a. Auto Backup
if (/android:allowBackup="/.test(mf)) {
  const want = String(ALLOW_AUTO_BACKUP);
  if (!mf.includes(`android:allowBackup="${want}"`)) { mf = mf.replace(/android:allowBackup="[^"]*"/, `android:allowBackup="${want}"`); log.ok(`allowBackup=${want}`); }
  else log.skip(`allowBackup already ${want}`);
} else {
  mf = mf.replace(/<application\b/, `<application android:allowBackup="${ALLOW_AUTO_BACKUP}"`);
  log.ok(`allowBackup=${ALLOW_AUTO_BACKUP} added`);
}

// 4b. deep link + shortcuts on MainActivity
if (!mf.includes('NASVO:deeplink')) {
  const re = /<activity\b[^>]*android:name="[^"]*MainActivity"[^>]*[^/]>/;
  if (re.test(mf)) {
    mf = mf.replace(re, (open) => `${open}
            <!-- NASVO:deeplink : nasvogrow://open?section=…&action=… (launcher shortcuts, widget) -->
            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="nasvogrow" />
            </intent-filter>
            <meta-data android:name="android.app.shortcuts" android:resource="@xml/shortcuts" />`);
    log.ok('nasvogrow:// link filter and shortcuts meta-data added to MainActivity');
  } else log.warn('Could not find the MainActivity <activity> tag. Add the nasvogrow:// intent-filter and the android.app.shortcuts meta-data by hand (see ANDROID.md).');
} else log.skip('deep link filter already present');

// 4c. widget receiver
if (!mf.includes('NASVO:widget')) {
  if (mf.includes('</application>')) {
    mf = mf.replace('</application>', `
        <!-- NASVO:widget -->
        <receiver android:name=".NasvoWidgetProvider" android:exported="false">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
            </intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/nasvo_widget_info" />
        </receiver>
    </application>`);
    log.ok('widget receiver added');
  } else log.warn('No </application> found; add the widget <receiver> by hand.');
} else log.skip('widget receiver already present');

// 4d. permissions
const wantPerms = ['android.permission.POST_NOTIFICATIONS', 'android.permission.USE_BIOMETRIC'];
const addPerms = wantPerms.filter((p) => !mf.includes(`"${p}"`));
if (addPerms.length) {
  mf = mf.replace('</manifest>', `${addPerms.map((p) => `    <uses-permission android:name="${p}" />`).join('\n')}\n</manifest>`);
  log.ok(`permissions: ${addPerms.map((p) => p.split('.').pop()).join(', ')}`);
} else log.skip('permissions already present');

if (REMOVE_INTERNET_PERMISSION && !mf.includes('NASVO:no-internet')) {
  if (!mf.includes('xmlns:tools=')) mf = mf.replace(/<manifest\b/, '<manifest xmlns:tools="http://schemas.android.com/tools"');
  mf = mf.replace('</manifest>', `    <!-- NASVO:no-internet -->\n    <uses-permission android:name="android.permission.INTERNET" tools:node="remove" />\n</manifest>`);
  log.ok('INTERNET permission removed');
}
if (mf !== mfOrig) write(manifestPath, mf);

/* ── 5. app/build.gradle ── */
console.log('app/build.gradle');
const gradlePath = fs.existsSync(path.join(ANDROID, 'app/build.gradle')) ? path.join(ANDROID, 'app/build.gradle') : path.join(ANDROID, 'app/build.gradle.kts');
if (gradlePath.endsWith('.kts')) {
  log.warn('app/build.gradle.kts (Kotlin DSL) isn\'t patched automatically. Add androidx.biometric:biometric:1.1.0 and the signing config by hand (see ANDROID.md).');
} else {
  let g = read(gradlePath);
  const gOrig = g;
  // biometric dependency
  if (!g.includes('NASVO:biometric')) {
    if (/^dependencies\s*\{/m.test(g)) { g = g.replace(/^dependencies\s*\{/m, (m) => `${m}\n    implementation "androidx.biometric:biometric:1.1.0" // NASVO:biometric`); log.ok('androidx.biometric dependency'); }
    else log.warn('No top-level dependencies { } block in app/build.gradle; add implementation "androidx.biometric:biometric:1.1.0".');
  } else log.skip('biometric dependency already present');
  // release signing from environment variables (so keys never live in the repo)
  if (!g.includes('NASVO:signing')) {
    const btIdx = g.search(/buildTypes\s*\{/);
    const bt = btIdx < 0 ? -1 : g.lastIndexOf('\n', btIdx) + 1;   // start of that line
    if (bt >= 0) {
      const signing = `    // NASVO:signing — set NASVO_KEYSTORE (+ _PASSWORD, NASVO_KEY_ALIAS, NASVO_KEY_PASSWORD) to sign release builds
    signingConfigs {
        release {
            if (System.getenv("NASVO_KEYSTORE")) {
                storeFile file(System.getenv("NASVO_KEYSTORE"))
                storePassword System.getenv("NASVO_KEYSTORE_PASSWORD")
                keyAlias System.getenv("NASVO_KEY_ALIAS")
                keyPassword System.getenv("NASVO_KEY_PASSWORD")
            }
        }
    }
`;
      g = g.slice(0, bt) + signing + '\n' + g.slice(bt);
      const after = g.slice(g.indexOf('NASVO:signing'));
      const rel = /buildTypes\s*\{\s*release\s*\{/.exec(after);
      if (rel) {
        const idx = g.indexOf('NASVO:signing') + rel.index + rel[0].length;
        g = g.slice(0, idx) + '\n            if (System.getenv("NASVO_KEYSTORE")) { signingConfig signingConfigs.release }' + g.slice(idx);
        log.ok('release signing from environment variables');
      } else log.warn('Added signingConfigs but could not find buildTypes { release { to attach it; add: signingConfig signingConfigs.release');
    } else log.warn('No buildTypes block found; release signing not added (see ANDROID.md).');
  } else log.skip('signing config already present');
  // versionCode / versionName from package.json
  const [maj = 0, min = 0, pat = 0] = String(pkgJson.version || '1.0.0').split('.').map((n) => parseInt(n, 10) || 0);
  const vCode = maj * 10000 + min * 100 + pat, vName = String(pkgJson.version || '1.0.0');
  if (/versionCode\s+\d+/.test(g) && /versionName\s+"[^"]*"/.test(g)) {
    g = g.replace(/versionCode\s+\d+/, `versionCode ${vCode}`).replace(/versionName\s+"[^"]*"/, `versionName "${vName}"`);
    log.ok(`versionCode ${vCode}, versionName ${vName} (from package.json)`);
  } else log.warn('versionCode / versionName not found in the expected form; set them by hand before uploading to Play.');
  if (g !== gOrig) write(gradlePath, g);
}

/* ── 6. splash background for Android 12+ (best effort) ── */
const stylesPath = path.join(RES, 'values/styles.xml');
if (fs.existsSync(stylesPath)) {
  let st = read(stylesPath);
  if (!st.includes('windowSplashScreenBackground') && /<style\s+name="AppTheme\.NoActionBarLaunch"[^>]*SplashScreen[^>]*>/.test(st)) {
    st = st.replace(/(<style\s+name="AppTheme\.NoActionBarLaunch"[^>]*>)/, '$1\n        <item name="windowSplashScreenBackground">@color/ic_launcher_background</item>');
    write(stylesPath, st); log.ok('splash background colour');
  } else log.skip('splash theme left as generated');
}

console.log(warnings.length ? `\nDone with ${warnings.length} warning(s) — read the WARN lines above.` : '\nDone. Next: npx cap sync android');
