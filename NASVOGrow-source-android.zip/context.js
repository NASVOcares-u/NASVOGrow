"use strict";
/* ═══════════════════════════════════════════════════════════════
   CONTEXT — an optional, opt-in daily log of sleep and weather,
   used only to power a couple of extra correlation rows in Insights.

   Why this exists and why it's shaped this way:
     • Sleep and weather are two of the better-evidenced external
       correlates of both habit consistency and craving/relapse risk,
       so they're worth a place in Insights alongside mood — but
       unlike mood (already collected as a journal side-effect), this
       is a second thing to fill in most days, so it's opt-in rather
       than on by default.
     • "Weather" here is self-reported, not fetched — this app has no
       server and no network calls (see netlify.toml's CSP:
       connect-src 'self'), and real weather data means an external
       API. Asking the person to tap what it's like outside keeps
       this fully local and consistent with everything else Grow
       does, at the cost of it being a lighter signal than true
       weather data would be.
     • Gated behind an explicit Settings toggle (off by default) —
       this is a second daily log asking about details of someone's
       life beyond what the rest of the app already tracks, so it
       stays opt-in even though, like everything else, it never
       leaves the device either way.
     • Lives inside the Recovery & Journal section, so it inherits
       that section's own PIN-lock scope automatically — no separate
       lock logic needed here.
═══════════════════════════════════════════════════════════════ */
const Context = (() => {
  const KEY = "zg_context";

  const WEATHER = { sunny: "Sunny", cloudy: "Cloudy", rainy: "Rainy", cold: "Cold", hot: "Hot" };
  const QUALITY = { 1: "Poor", 2: "Fair", 3: "Okay", 4: "Good", 5: "Great" };

  function load() { return Store.get(KEY, { enabled: false, log: {} }); }
  function save(s) { Store.set(KEY, s); }
  function today() { return new Date().toDateString(); }

  function isEnabled() { return !!load().enabled; }
  function setEnabled(on) {
    const s = load();
    s.enabled = !!on;
    save(s);
    render();
  }

  function todayEntry() { return load().log[today()] || null; }

  function logToday({ sleepHours, sleepQuality, weather }) {
    const s = load();
    const t = today();
    const existing = s.log[t] || {};
    s.log[t] = {
      sleepHours: sleepHours != null ? sleepHours : (existing.sleepHours ?? null),
      sleepQuality: sleepQuality != null ? sleepQuality : (existing.sleepQuality ?? null),
      weather: weather !== undefined ? weather : (existing.weather ?? null),
      ts: Date.now(),
    };
    save(s);
    ZG.toast("Logged for today");
    render();
  }

  function _wire() {
    const hoursInput = document.getElementById("ctxSleepHours");
    const readout = document.getElementById("ctxSleepReadout");
    hoursInput?.addEventListener("input", () => { if (readout) readout.textContent = hoursInput.value; });

    const qBtns = [...document.querySelectorAll("#ctxQualityRow .halt-chip")];
    qBtns.forEach(b => b.addEventListener("click", () => { qBtns.forEach(x => x.classList.remove("on")); b.classList.add("on"); }));

    const wBtns = [...document.querySelectorAll("#ctxWeatherRow .halt-chip")];
    wBtns.forEach(b => b.addEventListener("click", () => {
      const was = b.classList.contains("on");
      wBtns.forEach(x => x.classList.remove("on"));
      if (!was) b.classList.add("on");
    }));

    document.getElementById("ctxSaveBtn")?.addEventListener("click", () => {
      const sleepHours = hoursInput ? Number(hoursInput.value) : null;
      const qOn = document.querySelector("#ctxQualityRow .halt-chip.on");
      const wOn = document.querySelector("#ctxWeatherRow .halt-chip.on");
      logToday({ sleepHours, sleepQuality: qOn ? Number(qOn.dataset.q) : null, weather: wOn ? wOn.dataset.w : null });
    });
  }

  function render() {
    const wrap = document.getElementById("contextSection");
    if (!wrap) return;
    if (!isEnabled()) { wrap.innerHTML = ""; return; }
    const entry = todayEntry() || {};
    const hours = entry.sleepHours ?? 7;
    wrap.innerHTML = `
      <div class="gr-label">Sleep &amp; context</div>
      <div class="card">
        <label class="field-label" style="margin-top:0" for="ctxSleepHours">Hours slept last night — <span id="ctxSleepReadout">${hours}</span>h</label>
        <input type="range" id="ctxSleepHours" min="0" max="12" step="0.5" value="${hours}"/>
        <div class="field-label">Sleep quality</div>
        <div class="halt-row" id="ctxQualityRow">${Object.entries(QUALITY).map(([k, l]) => `<button type="button" class="halt-chip${String(entry.sleepQuality) === k ? " on" : ""}" data-q="${k}">${l}</button>`).join("")}</div>
        <div class="field-label">Weather today</div>
        <div class="halt-row" id="ctxWeatherRow">${Object.entries(WEATHER).map(([k, l]) => `<button type="button" class="halt-chip${entry.weather === k ? " on" : ""}" data-w="${k}">${l}</button>`).join("")}</div>
        <button class="btn-secondary" style="width:100%;margin-top:4px" id="ctxSaveBtn">Save today's log</button>
        <p class="fine-print" style="margin-bottom:0">Self-reported, not fetched — no weather service is ever called. Feeds a couple of extra rows in Insights once there's enough logged.</p>
      </div>`;
    _wire();
  }

  ZG.sectionRenderers.recovery = (() => {
    const prev = ZG.sectionRenderers.recovery;
    return () => { prev?.(); render(); };
  })();
  // Rendered on demand the first time Recovery is opened, not on every page
  // load — see the matching note in journal.js.

  return { isEnabled, setEnabled, logToday, todayEntry, load, WEATHER, QUALITY, render };
})();
window.Context = Context;
