"use strict";
/* ═══════════════════════════════════════════════════════════════
   BUDDY CODE — a second, deliberately narrower relative of sync.js's
   sync code. Same trust model (you choose the channel — a message, a
   share sheet, whatever — nothing ever touches a server), but a
   completely different shape of data and a completely different use:

     • sync.js moves YOUR OWN data between two of YOUR OWN devices,
       and merges it in. A buddy code is a read-only SNAPSHOT of
       someone ELSE's progress, shared with you — it never touches
       your own habits/streak/XP/anything. Buddies live in their own
       small local list (zg_buddies), never merged into your data.
     • The snapshot is strictly three aggregate numbers — current
       streak, this week's rhythm percentage, challenges completed
       this week — never raw logs, never journal text, never a
       tracker's "why." A name is the ONE optional field, and it's
       off by default: the code stays anonymous unless the person
       generating it explicitly turns "Include my name" on.

   This is genuinely all the data model needs to be: no ids that
   could correlate across codes, no timestamps finer than "when this
   snapshot was generated," nothing that adds up to more than what it
   says on the label.
═══════════════════════════════════════════════════════════════ */
const Buddy = (() => {
  const CODE_PREFIX = "NGBUD1:";
  const STORE_KEY = "zg_buddies";
  const MAX_BUDDIES = 20;

  function _weekStart(d = new Date()) {
    const dt = new Date(d); const day = (dt.getDay() + 6) % 7; // Monday=0, same convention as the rest of the app
    dt.setHours(0, 0, 0, 0); dt.setDate(dt.getDate() - day);
    return dt;
  }

  /** The entire payload a buddy code can ever contain — see this file's
   *  header for why it stops exactly here. */
  function _snapshot({ includeName = false } = {}) {
    const streak = ZG.getStreak();
    const target = ZG.getWeeklyGoalTarget();
    const activeDays = ZG.activeDaysThisWeek();
    const weeklyPct = target > 0 ? Math.round((activeDays / target) * 100) : 0;

    const weekStartMs = _weekStart().getTime();
    const challengesThisWeek = (window.Challenges?.load?.().history || [])
      .filter(h => h.completed && h.endTs >= weekStartMs).length;

    const snap = { v: 1, streak, weeklyPct, challengesThisWeek, generatedAt: Date.now() };
    if (includeName) {
      const name = window.Profile?.getName?.();
      if (name) snap.name = name;
    }
    return snap;
  }

  function generateCode(opts) {
    const json = JSON.stringify(_snapshot(opts));
    return CODE_PREFIX + btoa(unescape(encodeURIComponent(json)));
  }

  function decodeCode(code) {
    code = (code || "").trim();
    if (!code.startsWith(CODE_PREFIX)) throw new Error("That doesn't look like a buddy code.");
    let snap;
    try { snap = JSON.parse(decodeURIComponent(escape(atob(code.slice(CODE_PREFIX.length))))); }
    catch { throw new Error("That buddy code looks corrupted — check you copied all of it."); }
    if (snap.v !== 1) throw new Error("This buddy code is from a version of NASVOGrow this app doesn't recognize.");
    if (typeof snap.streak !== "number" || typeof snap.weeklyPct !== "number" || typeof snap.challengesThisWeek !== "number") {
      throw new Error("That buddy code is missing data it needs.");
    }
    return snap;
  }

  function loadBuddies() { return Store.get(STORE_KEY, []); }
  function saveBuddies(list) { Store.set(STORE_KEY, list); }

  /** Decodes a code and files it as a new buddy entry — a label the
   *  person adding it chooses themselves (falling back to the sender's
   *  name if they included one, then a generic default), never anything
   *  that could double as an identifier on its own. */
  function addFromCode(code, label) {
    const snap = decodeCode(code);
    const list = loadBuddies();
    const entry = {
      id: "b" + Date.now(),
      label: (label || snap.name || "Buddy").trim().slice(0, 30) || "Buddy",
      streak: snap.streak, weeklyPct: snap.weeklyPct, challengesThisWeek: snap.challengesThisWeek,
      generatedAt: snap.generatedAt, receivedAt: Date.now(),
    };
    list.unshift(entry);
    saveBuddies(list.slice(0, MAX_BUDDIES));
    return entry;
  }

  function removeBuddy(id) { saveBuddies(loadBuddies().filter(b => b.id !== id)); }

  /* ── Settings UI ── */
  function _renderBuddyList() {
    const body = document.getElementById("buddyListBody");
    if (!body) return;
    const list = loadBuddies();
    if (!list.length) { body.innerHTML = `<p class="fine-print" style="margin-top:0">No buddies added yet.</p>`; return; }
    body.innerHTML = list.map(b => {
      const age = Math.floor((Date.now() - b.generatedAt) / 86400000);
      const ageLabel = age <= 0 ? "today" : `${age}d ago`;
      return `
        <div class="contact-row">
          <span class="icon-chip sm" style="--chip-color:var(--gold);--chip-bg:rgba(var(--gold-rgb),.14)">${window.Icons?.svg("flame") || ""}</span>
          <span class="contact-name">${ZG.esc(b.label)} — ${b.streak}d streak, ${b.weeklyPct}% this week, ${b.challengesThisWeek} challenge${b.challengesThisWeek === 1 ? "" : "s"} <span style="color:var(--muted-dim)">(snapshot from ${ageLabel})</span></span>
          <button class="habit-del" data-rm-buddy="${b.id}" aria-label="Remove buddy">✕</button>
        </div>`;
    }).join("");
    body.querySelectorAll("[data-rm-buddy]").forEach(btn =>
      btn.addEventListener("click", () => { removeBuddy(btn.dataset.rmBuddy); _renderBuddyList(); }));
  }

  function _renderGetCodePanel() {
    const panel = document.getElementById("buddyPanel");
    if (!panel) return;
    const includeName = !!document.getElementById("buddyIncludeNameToggle")?.classList.contains("on");
    const code = generateCode({ includeName });
    panel.innerHTML = `
      <textarea id="buddyCodeOutput" rows="3" readonly style="font-family:var(--font-mono);font-size:0.6875rem">${code}</textarea>
      <p class="fine-print">Just your streak, this week's rhythm, and challenges completed this week${includeName ? ", plus your name" : " — no name, fully anonymous"}. Never your logs, journal, or a tracker's "why."</p>
      <div class="settings-actions">
        <button class="btn-primary" style="flex:1" id="buddyCopyBtn">Copy code</button>
        ${navigator.share ? `<button class="btn-secondary" style="flex:1" id="buddyShareBtn">Share…</button>` : ""}
      </div>`;
    document.getElementById("buddyCopyBtn")?.addEventListener("click", async () => {
      try { await navigator.clipboard.writeText(code); ZG.toast("Copied — send it however you'd share anything else"); }
      catch { ZG.toast("Couldn't copy — select the text above manually"); }
    });
    document.getElementById("buddyShareBtn")?.addEventListener("click", async () => {
      try { await navigator.share({ title: "My NASVOGrow buddy code", text: code }); } catch {}
    });
  }

  function _renderAddCodePanel() {
    const panel = document.getElementById("buddyPanel");
    if (!panel) return;
    panel.innerHTML = `
      <input type="text" id="buddyLabelInput" placeholder="What should we call them? (optional)" maxlength="30" style="margin-bottom:8px"/>
      <textarea id="buddyCodeInput" rows="3" placeholder="Paste their buddy code…" style="font-family:var(--font-mono);font-size:0.6875rem"></textarea>
      <div class="settings-actions">
        <button class="btn-primary" style="flex:1" id="buddyAddConfirmBtn">Add buddy</button>
      </div>`;
    document.getElementById("buddyAddConfirmBtn")?.addEventListener("click", () => {
      const code = document.getElementById("buddyCodeInput")?.value.trim();
      const label = document.getElementById("buddyLabelInput")?.value.trim();
      if (!code) { ZG.toast("Paste a code first"); return; }
      try {
        const entry = addFromCode(code, label);
        ZG.toast(`${entry.label} added`);
        panel.innerHTML = "";
        _renderBuddyList();
      } catch (err) {
        ZG.toast(err.message || "That code didn't work");
      }
    });
  }

  document.addEventListener("DOMContentLoaded", () => {
    const nameToggle = document.getElementById("buddyIncludeNameToggle");
    nameToggle?.addEventListener("click", () => {
      const next = !nameToggle.classList.contains("on");
      nameToggle.classList.toggle("on", next);
      nameToggle.setAttribute("aria-checked", String(next));
    });
    document.getElementById("buddyGetCodeBtn")?.addEventListener("click", _renderGetCodePanel);
    document.getElementById("buddyAddCodeBtn")?.addEventListener("click", _renderAddCodePanel);
    _renderBuddyList();
  });

  return { generateCode, decodeCode, loadBuddies, addFromCode, removeBuddy };
})();
window.Buddy = Buddy;
