# NASVOGrow as an Android app (Capacitor)

The web app is unchanged for Netlify/PWA users. This adds a second target: the same code, wrapped as an
Android app with native reminders, share-sheet export, back-button handling, biometric unlock, a home-screen
widget and more. Everything stays on the phone; there is still no server.

## What was verified, and what wasn't

| Verified here | **Not** verified here (needs a phone) |
|---|---|
| 19 unit tests of the JS bridge and the reminder rules (`npm run test:native`) | An APK has never been built from this code. The sandbox had no Android SDK or network. |
| 51-step browser test of the real app against a *simulated* Capacitor (`python3 qa/native-e2e.py`) | Whether notifications actually fire with the app closed, after a reboot, and under Doze |
| Web/PWA build regression check (`python3 qa/native-e2e.py dist --web`) | Widget, launcher shortcuts, biometric prompt, Documents backup, back gesture, edge-to-edge layout |
| The Java (plugin, widget, MainActivity) compiles against hand-written stubs of the Android APIs | The Java against the *real* Android SDK; `setup-android.mjs` against the real Capacitor 8 template (tested on a mock of it) |
| `build.mjs --native`, `setup-android.mjs` (twice: idempotent) | npm package versions (no network to check them) |

Treat the first build as a test build and walk through the checklist at the bottom.

## Option A: build on your computer

You need Node 22+, JDK 21 and Android Studio (current stable) with an Android SDK installed.

```bash
npm install
npm run native:add          # cap add android → apply native layer → build → cap sync
npm run native:apk          # android/app/build/outputs/apk/debug/app-debug.apk
adb install -r android/app/build/outputs/apk/debug/app-debug.apk     # or copy the APK to your phone
```

Optional, hides the app in the recent-apps switcher and blocks screenshots (shown in Settings only if installed):

```bash
npm install @capacitor/privacy-screen && npm run native:sync
```

After changing web code: `npm run native:sync` (rebuilds `dist-native/` and copies it into the app).
If `android/` is ever deleted and recreated, run `npm run native:setup` again; it is safe to re-run.

## Option B: no Android Studio, let GitHub build it

1. Put this folder in a GitHub repository.
2. Actions → **Android build** → Run workflow. About 5–10 minutes.
3. Download `nasvogrow-debug-apk` from the run's Artifacts and install it on your phone.

## Before you publish: decisions that are yours

| Setting | Where | Default here |
|---|---|---|
| **App ID** (permanent once on Google Play) | `capacitor.config.json` → `appId` | `app.nasvogrow.mobile`. Change it *before* `npm run native:add`. Your old `assetlinks.json` is for the TWA package and isn't used by Capacitor. |
| Android Auto Backup | `native/setup-android.mjs` → `ALLOW_AUTO_BACKUP` | **off**. When on, Android copies the app's data to the person's Google account, which contradicts "nothing leaves your device" in `privacy.html`. |
| Remove the INTERNET permission | `REMOVE_INTERNET_PERMISSION` | off, because it is untested with Capacitor's WebView. Try it on a device; if the app works, turn it on and say so in the Data safety form. |
| Launcher shortcuts | `SHORTCUTS` | Add a habit, Quick journal, **Log an urge**. The last label is visible on a home screen; delete that entry if that matters to you. |
| Version | `package.json` → `version` | `1.0.0` becomes versionName `1.0.0`, versionCode `10000`. Bump it for every Play upload. |

### Release signing (Google Play)
```bash
keytool -genkeypair -v -keystore nasvogrow.jks -alias nasvogrow -keyalg RSA -keysize 2048 -validity 10000
```
Keep that file and its passwords somewhere safe **outside** the repo; losing it means you can't update the app.
Locally: `NASVO_KEYSTORE=/path/nasvogrow.jks NASVO_KEYSTORE_PASSWORD=… NASVO_KEY_ALIAS=nasvogrow NASVO_KEY_PASSWORD=… npm run native:release`
(output: `app-release.apk` and `bundle/release/app-release.aab`; Play wants the `.aab`).
On GitHub: add the four secrets named at the top of `.github/workflows/android.yml`.

Play Console: you'll need the privacy policy URL (`privacy.html`), the Data safety form, and the target-API / testing
requirements current at the time. Check those on Play Console itself; they change.

## What the app does differently from the web version

* **Reminders** are scheduled with Android's alarm system for the next 7 evenings plus weekly "harder hour" check-ins,
  and re-planned whenever habits change or the app is opened. Today's reminder disappears once every habit is done.
  Delivery is *inexact* (can slip a few minutes under battery saver); that avoids the "Alarms & reminders" permission.
  Limits: future evenings can only say something generic, and risk windows refresh when you open the app.
* **Private notifications** (on by default): check-in channel hides its contents on a locked screen, wording is neutral,
  and a disguised app uses the disguise name as the title.
* **Back button:** closes the top sheet, else goes Home, else "press back again to exit". On the PIN screen it leaves the app.
* **Export, backups, streak card** open the Android share sheet (Drive, Files, email…). The web "download" doesn't work in a WebView.
* **Automatic backup** writes `Documents/NASVOGrow/nasvo-grow-autobackup-*.json` (Android 10+), keeping the newest 14.
  Unlike app data, these files survive an uninstall.
* **Fingerprint / face** on the PIN screen (the PIN always still works), **hide in recent apps & block screenshots**,
  **widget** (today's habits and streak only; nothing from Recovery or the journal), **long-press shortcuts**,
  native haptics, system-bar colours that follow the theme.
* No service worker or install prompt inside the app (files ship in the APK).
* `.toast[hidden]` fix in `styles.css` (also in the web build): a dismissed toast left an invisible box over the top-right
  corner that swallowed taps on the Settings button until the next toast appeared.

## Where things live

| File | Role |
|---|---|
| `native-bridge.js` | The only code that talks to Capacitor plugins; no-ops in a browser |
| `native-app.js` | Decides reminders, widget data, re-lock on resume, "On this phone" settings |
| `native/java/*.java` | `NasvoNative` plugin (backup, biometrics, widget data), widget provider, MainActivity |
| `native/android-res/` | Icons, adaptive icon, notification icon, widget layout, strings |
| `native/setup-android.mjs` | Applies all of the above to the generated `android/` project (idempotent) |
| `build.mjs --native` | Writes `dist-native/` (CSP meta tag, safe-area fallback, no sw/_headers) |
| `capacitor.config.json` | App id, name, plugin settings |
| `qa/native-bridge.test.mjs`, `qa/native-e2e.py` | The tests described above |

## First-run checklist on a real phone (Android 13+ if you can, plus an older one)

1. App opens; status bar and gesture bar don't cover the header or bottom navigation; the keyboard doesn't hide inputs.
2. Settings → Local reminders → allow notifications. Denying shows the "allow them in Android Settings" message.
3. **Scheduled reminder, app closed.** Connect the phone, open `chrome://inspect`, and in the app's console run
   `NativeBridge.syncReminders({title:{habits:"NASVOGrow"},evening:[{n:0,at:Date.now()+60000,body:"test"}],risk:[]})`,
   then swipe the app away and wait a minute. (If the app isn't listed, set `webContentsDebuggingEnabled` to `true` for the test build.)
   Repeat after a reboot.
4. Tap the notification and its buttons: they should open Habits / Recovery / "Ride it out" / Journal.
5. Long-press the icon: the three shortcuts open the right screens, both from a cold start and while the app is running.
6. Add the widget; tick a habit and watch it update; next morning it should say "A new day / Open the app to update".
7. PIN lock on → background the app → return: PIN screen and the biometric prompt appear; cancelling the prompt leaves the PIN usable.
8. Settings → Automatic backup → on; check Files → Documents → NASVOGrow; uninstall/reinstall and confirm the file is still there.
9. Export (JSON/CSV/portable) and the streak card open the share sheet.
10. Back button/gesture from a sheet, from Growth, from Home, and on the PIN screen.
11. With privacy-screen installed and enabled: the recent-apps thumbnail is blank and screenshots are blocked.

If something fails, the quickest diagnostics are `adb logcat | grep -i -E "capacitor|nasvo"` and the console in `chrome://inspect`.
