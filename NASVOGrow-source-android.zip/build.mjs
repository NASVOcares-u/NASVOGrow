// NASVOGrow production build  ->  dist/   (or dist-native/ with --native)
//   node build.mjs            web build: what you deploy to Netlify
//   node build.mjs --native   same app, packaged for the Capacitor Android shell -> dist-native/
//                             (no service worker / _headers / .well-known; a CSP <meta> instead of the
//                              header; safe-area insets fall back to Capacitor's --safe-area-inset-* vars)
//
// The repo root stays the readable source of truth and still runs as-is (open it with any
// static server). This script turns it into the site you deploy:
//   * minifies every <script defer src> from index.html in place (default), or with
//     `--bundle` concatenates them, IN THE ORDER LISTED, into one app.min.js. Bundling is
//     behaviour-preserving (all files are strict-mode classic scripts with no clashing names)
//     but Lighthouse's "Reduce unused JavaScript" then sees one big file and flags it, so the
//     per-file mode is the default.
//   * minifies fonts.css + styles.css and INLINES them in index.html (no render-blocking request)
//   * minifies styles-extra.css and ships it as a file that app.js loads on first need
//   * rewrites sw.js's precache list to match the built output, minifies it
//   * copies everything else (assets, manifest, _headers, .well-known, ...) untouched
import { transform } from 'esbuild';
import fs from 'node:fs';
import path from 'node:path';

const ROOT = path.dirname(new URL(import.meta.url).pathname);
const NATIVE = process.argv.includes('--native');
const OUT = path.join(ROOT, NATIVE ? 'dist-native' : 'dist');
const read = (f) => fs.readFileSync(path.join(ROOT, f), 'utf8');
const write = (f, data) => { const p = path.join(OUT, f); fs.mkdirSync(path.dirname(p), { recursive: true }); fs.writeFileSync(p, data); };
// Android WebViews older than v140 report wrong env(safe-area-inset-*); Capacitor's SystemBars plugin injects
// correct --safe-area-inset-* variables, so the native build reads those first and falls back to env().
const safeArea = (css) => NATIVE ? css.replace(/env\(safe-area-inset-(top|bottom|left|right)\)/g, 'var(--safe-area-inset-$1,env(safe-area-inset-$1,0px))') : css;
const NATIVE_CSP = "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; font-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'";
const kb = (n) => (n / 1024).toFixed(1) + ' KB';

fs.rmSync(OUT, { recursive: true, force: true });
fs.mkdirSync(OUT, { recursive: true });

let html = read('index.html');

// ── 1. scripts -> one bundle ─────────────────────────────────────────────
const scriptRe = /[ \t]*<script defer src="([^"]+\.js)"><\/script>[ \t]*\r?\n?/g;
const scripts = [...html.matchAll(scriptRe)].map((m) => m[1]);
if (!scripts.length) throw new Error('No <script defer src> tags found in index.html');
const BUNDLE = process.argv.includes('--bundle');
const jsOpts = { minify: true, target: 'es2020', legalComments: 'none', charset: 'utf8' };
let rawJs = 0, outJs = 0;
const sources = scripts.map((f) => { const src = read(f); rawJs += Buffer.byteLength(src); return [f, src]; });
for (const [f, src] of sources) if (!/^\s*(\/\*[\s\S]*?\*\/\s*)?["']use strict["'];?/.test(src)) throw new Error(`${f}: expected a "use strict" script`);
if (BUNDLE) {
  const parts = sources.map(([f, src]) => `/* ${f} */\n${src.replace(/^\s*(\/\*[\s\S]*?\*\/\s*)?["']use strict["'];?/, '$1')}`);
  const bundle = await transform('"use strict";\n' + parts.join('\n;\n'), jsOpts);
  write('app.min.js', bundle.code); outJs = bundle.code.length;
  let first = true;
  html = html.replace(scriptRe, () => { if (first) { first = false; return '<script defer src="app.min.js"></script>\n'; } return ''; });
} else {
  for (const [f, src] of sources) { const out = await transform(src, jsOpts); write(f, out.code); outJs += out.code.length; }
}

// ── 2. CSS: core inlined, extra deferred ─────────────────────────────────
const minCss = async (f) => (await transform(read(f), { loader: 'css', minify: true, legalComments: 'none' })).code.trim();
const fontsCss = await minCss('fonts.css');
const coreCss = fontsCss + await minCss('styles.css');
const extraCss = await minCss('styles-extra.css');
write('styles-extra.css', safeArea(extraCss));
html = html.replace(/<!-- build:core-css[\s\S]*?<!-- \/build:core-css -->/, () => `<style>${coreCss}</style>`);
html = html.replace(/<!-- build:extra-css[\s\S]*?<!-- \/build:extra-css -->\s*/, '');
if (html.includes('href="styles.css"') || html.includes('data-extra')) throw new Error('CSS markers were not replaced');

// strip HTML comments (outside <script>/<style>, none of which contain any)
html = html.replace(/<!--(?!\[if)[\s\S]*?-->/g, '').replace(/\n{3,}/g, '\n\n');
if (NATIVE) {
  html = safeArea(html);
  html = html.replace(/<link rel="manifest"[^>]*>\s*/, '');                       // no service worker / install flow in the app
  if (!html.includes('<head>')) throw new Error('index.html: <head> not found for the CSP meta');
  html = html.replace('<head>', `<head>\n<meta http-equiv="Content-Security-Policy" content="${NATIVE_CSP}"/>`);   // _headers doesn't exist inside the app
}
write('index.html', html);

// ── 3. service worker: precache exactly what the build ships (web build only) ──
if (!NATIVE) {
const imgs = fs.readdirSync(path.join(ROOT, 'assets/img')).map((f) => `/assets/img/${f}`);
const fonts = fs.readdirSync(path.join(ROOT, 'assets/fonts')).filter((f) => f.endsWith('.woff2')).map((f) => `/assets/fonts/${f}`);
const precache = ['/', '/index.html', '/styles-extra.css', ...(BUNDLE ? ['/app.min.js'] : scripts.map((f) => '/' + f)), '/site.webmanifest', '/404.html', '/privacy.html', ...imgs, ...fonts];
let sw = read('sw.js');
if (!/const CORE_ASSETS = \[[\s\S]*?\n\];/.test(sw)) throw new Error('sw.js CORE_ASSETS block not found');
sw = sw.replace(/const CORE_ASSETS = \[[\s\S]*?\n\];/, `const CORE_ASSETS = ${JSON.stringify(precache)};`);
write('sw.js', (await transform(sw, { minify: true, target: 'es2020', legalComments: 'none', charset: 'utf8' })).code);
}

// ── 4. everything else, verbatim ─────────────────────────────────────────
const SKIP = new Set(['node_modules', 'dist', '.git', 'build.mjs', 'package.json', 'package-lock.json', 'index.html', 'sw.js', 'styles.css', 'styles-extra.css', 'CHANGES.md', 'gallery.html', 'qa', 'dist-native', 'android', 'native', '.github', 'capacitor.config.json', 'ANDROID.md', '.gitignore',
  ...(NATIVE ? ['_headers', '.well-known', 'robots.txt', 'llms.txt', '404.html', 'site.webmanifest'] : []),
  ...(BUNDLE ? scripts.map((s) => s.split('/')[0]) : [])]);
const copy = (rel) => {
  const abs = path.join(ROOT, rel), st = fs.statSync(abs);
  if (st.isDirectory()) { for (const c of fs.readdirSync(abs)) copy(path.join(rel, c)); return; }
  if (rel.endsWith('.js') && scripts.includes(rel.replace(/\\/g, '/'))) return;   // already written (bundled or minified)
  if (rel.replace(/\\/g, '/').startsWith('.well-known/appspecific')) return;        // Chrome DevTools probe file, not for production
  write(rel, fs.readFileSync(abs));
};
for (const e of fs.readdirSync(ROOT)) {
  if (SKIP.has(e)) continue;
  copy(e);
}
// content/ holds bundled scripts only; ship nothing from it unless it has non-script files
console.log(`scripts : ${scripts.length} files, ${kb(rawJs)} -> ${kb(outJs)} (${BUNDLE ? 'one bundle' : 'minified per file'})`);
console.log(`core css: ${kb(read('styles.css').length)} -> ${kb(coreCss.length)} (inlined)`);
console.log(`extra   : ${kb(read('styles-extra.css').length)} -> ${kb(extraCss.length)} (on demand)`);
console.log(`${path.basename(OUT)}/ written`);
