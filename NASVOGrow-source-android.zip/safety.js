"use strict";
/* ═══════════════════════════════════════════════════════════════
   SAFETY — five quiet layers of protection, all local-only:
     1. A PIN lock on Recovery (or the whole app) — a courtesy lock
        against a shoulder-glance, not encryption. Nothing here is
        sent anywhere; "forgot PIN" simply removes the lock.
     2. Disguise mode — swaps the tab title/icon/brand name for
        something plain, for the moment the phone is on a table.
     3. Trusted contacts — one-tap call/text/email to someone you
        already chose, with no server or account in between.
     4. A grounding tool — the standard 5-4-3-2-1 sensory technique,
        one tap away from a button in the sidebar/topbar on every
        screen, not buried inside Recovery. It deliberately bypasses
        the PIN lock entirely (it opens as an overlay, never through
        showSection) — if the whole app is locked, a person in a
        spiking moment shouldn't have to unlock it first to calm down.
     5. Localized crisis line — a small, curated, on-device table of
        real national crisis lines (verified against official/primary
        sources at the time this was written). It never shows a specific
        country's numbers on a silent guess: browser language reflects
        language preference, not location (plenty of non-US phones report
        bare "en", which Intl happily maximizes to "US"), so the note
        asks once, offering the local guess only as a one-tap suggestion
        inside the picker itself. Countries outside the curated table
        still get a direct link to findahelpline.com's page for that
        country instead of silence — findahelpline.com is only ever
        linked as a normal clickable URL here, never fetched by the app.
═══════════════════════════════════════════════════════════════ */
const Safety = (() => {
  const SEC_KEY = "zg_security";
  const CONTACTS_KEY = "zg_trusted_contacts";
  const COUNTRY_KEY = "zg_country";
  const AUTOLOCK_MS = 5 * 60000;
  let _unlockedApp = false;
  let _unlockedRecovery = false;
  let _lockTimer = null;

  function loadSec() { return Store.get(SEC_KEY, { enabled: false, scope: "recovery", hash: null, disguise: false, disguiseName: "" }); }
  function saveSec(s) { Store.set(SEC_KEY, s); }

  async function _sha256(text) {
    const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
    return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, "0")).join("");
  }

  async function setPin(pin, scope) {
    const s = loadSec();
    s.enabled = true; s.hash = await _sha256(pin); s.scope = scope || "recovery";
    saveSec(s);
    _unlockedApp = true; _unlockedRecovery = true; // don't lock the person out right after setting it
    _resetAutoLockTimer();
  }

  async function verifyPin(pin) {
    const s = loadSec();
    if (!s.hash) return false;
    return (await _sha256(pin || "")) === s.hash;
  }

  function disable() { const s = loadSec(); s.enabled = false; s.hash = null; saveSec(s); }
  function isEnabled() { const s = loadSec(); return !!(s.enabled && s.hash); }
  function scope() { return loadSec().scope; }

  /* ── Crisis line — localized, on-device, no network ──
     A small curated table beats a hardcoded single-country number, but
     it can never cover every country honestly — so it's paired with a
     live link to findahelpline.com for anything outside the table. Every
     number below is a national line (call/text), checked against an
     official or primary source when this was written; helplines do
     change, which is exactly why "wrong? fix it in Settings" and the
     findahelpline.com link both exist alongside the table, not just as
     a fallback for unlisted countries. */
  const COUNTRIES = {
    US: { name: "United States", org: "988 Suicide & Crisis Lifeline", lines: [
      { label: "Call 988", tel: "988" }, { label: "Text 988", sms: "988" } ] },
    CA: { name: "Canada", org: "988 Suicide Crisis Helpline", lines: [
      { label: "Call 988", tel: "988" }, { label: "Text 988", sms: "988" } ] },
    GB: { name: "United Kingdom", org: "Samaritans", lines: [
      { label: "Call 116 123", tel: "116123" }, { label: "Text SHOUT to 85258", sms: "85258", smsBody: "SHOUT" } ] },
    IE: { name: "Ireland", org: "Samaritans", lines: [
      { label: "Call 116 123", tel: "116123" } ] },
    AU: { name: "Australia", org: "Lifeline Australia", lines: [
      { label: "Call 13 11 14", tel: "131114" } ] },
    NZ: { name: "New Zealand", org: "Need to Talk?", lines: [
      { label: "Call 1737", tel: "1737" }, { label: "Text 1737", sms: "1737" } ] },
    IN: { name: "India", org: "Tele-MANAS (Govt. of India)", lines: [
      { label: "Call 14416", tel: "14416" }, { label: "Call 1800-891-4416", tel: "18008914416" } ] },
    PH: { name: "Philippines", org: "National Center for Mental Health Crisis Hotline", lines: [
      { label: "Call 1553", tel: "1553" }, { label: "Call 0917-899-8727", tel: "09178998727" } ] },
    SG: { name: "Singapore", org: "Samaritans of Singapore", lines: [
      { label: "Call 1-767", tel: "1767" } ] },
    ZA: { name: "South Africa", org: "SADAG", lines: [
      { label: "Call 0800 567 567", tel: "0800567567" } ] },
    DE: { name: "Germany", org: "TelefonSeelsorge", lines: [
      { label: "Call 0800 111 0 111", tel: "08001110111" }, { label: "Call 0800 111 0 222", tel: "08001110222" } ] },
    FR: { name: "France", org: "3114 — Numéro national de prévention du suicide", lines: [
      { label: "Call 3114", tel: "3114" } ] },
    BR: { name: "Brazil", org: "CVV — Centro de Valorização da Vida", lines: [
      { label: "Call 188", tel: "188" } ] },
    MX: { name: "Mexico", org: "SAPTEL", lines: [
      { label: "Call 800 472 7835", tel: "8004727835" } ] },
  };

  /** Pulls a 2-letter region out of a BCP-47 language tag ("en-US" -> "US").
   *  For a bare language tag with no region ("en", "hi"), asks Intl.Locale
   *  to fill one in via CLDR "likely subtags" — still fully local, just a
   *  standard lookup table shipped in the browser, no network involved. */
  function _regionFromTag(tag) {
    if (!tag) return null;
    const parts = String(tag).split("-");
    if (parts.length > 1) {
      const last = parts[parts.length - 1];
      if (/^[A-Za-z]{2}$/.test(last)) return last.toUpperCase();
    }
    try {
      if (typeof Intl !== "undefined" && Intl.Locale) {
        const region = new Intl.Locale(tag).maximize().region;
        if (region) return region.toUpperCase();
      }
    } catch { /* older browser, or an unparseable tag — fall through */ }
    return null;
  }

  function _detectCountry() {
    const tags = [
      ...(navigator.languages && navigator.languages.length ? navigator.languages : []),
      navigator.language,
    ].filter(Boolean);
    for (const tag of tags) {
      const region = _regionFromTag(tag);
      if (region) return region;
    }
    return null;
  }

  function getCountryPref() { return Store.get(COUNTRY_KEY, ""); }
  function setCountryPref(code) { Store.set(COUNTRY_KEY, code || ""); }

  /** The country to show right now — but ONLY once someone has actually
   *  answered the "which country" question (pref is non-empty). An unset
   *  pref resolves to null on purpose: browser language is a preference,
   *  not a location — plenty of phones worldwide report bare "en" and
   *  Intl maximizes that to "US" (see _regionFromTag above), which is
   *  exactly the silent-wrong-default this is built to avoid. The guess
   *  is only ever offered as a one-tap suggestion inside the picker
   *  itself; nothing is shown on its strength alone. "auto" is what gets
   *  stored once someone actually picks that suggestion — from then on
   *  it keeps re-guessing fresh (so a later language change is still
   *  picked up), but as a confirmed choice, not an unagreed-to one.
   *  "other" is a separate confirmed "none of these" answer. */
  function resolvedCountry() {
    const pref = getCountryPref();
    if (!pref || pref === "other") return null;
    if (pref === "auto") return _detectCountry();
    return pref;
  }

  function countryName(code) {
    if (!code) return "";
    if (COUNTRIES[code]) return COUNTRIES[code].name;
    try {
      if (typeof Intl !== "undefined" && Intl.DisplayNames) {
        const name = new Intl.DisplayNames(["en"], { type: "region" }).of(code);
        if (name && name !== code) return name;
      }
    } catch { /* fall through to the bare code below */ }
    return code;
  }

  function crisisLines(code) { return (code && COUNTRIES[code]) || null; }

  function _findAHelplineUrl(code) {
    return "https://findahelpline.com" + (code ? `/countries/${code.toLowerCase()}` : "");
  }

  /** The <option>s shared by the Settings dropdown and the inline
   *  "set your country" prompt, so the two can never drift apart. When
   *  pref is empty, a disabled placeholder sits selected in front so
   *  nothing is silently pre-picked. */
  function _countryOptionsHtml(pref) {
    const detected = _detectCountry();
    const detectedLabel = detected ? countryName(detected) : null;
    const rows = Object.entries(COUNTRIES).sort((a, b) => a[1].name.localeCompare(b[1].name));
    return `
      ${!pref ? `<option value="" disabled selected>Choose your country…</option>` : ""}
      <option value="auto"${pref === "auto" ? " selected" : ""}>Detect automatically${detectedLabel ? ` (guess: ${ZG.esc(detectedLabel)})` : ""}</option>
      ${rows.map(([code, c]) => `<option value="${code}"${pref === code ? " selected" : ""}>${ZG.esc(c.name)}</option>`).join("")}
      <option value="other"${pref === "other" ? " selected" : ""}>Not listed — show me the full directory</option>`;
  }

  /** Fired by the inline picker's onchange — that picker lives inside HTML
   *  Recovery injects via innerHTML, so there's no element to attach a
   *  real listener to ahead of time. This follows the same inline
   *  onclick/onchange pattern already used throughout habits.js/
   *  recovery.js/challenges.js for exactly that reason. */
  function applyAskedCountry(value) {
    if (!value) return;
    setCountryPref(value);
    window.Recovery?.render?.();
    renderCrisisSettingsBlock(); // harmless no-op if Settings isn't open
  }

  function _renderCrisisAskNote(context) {
    const selId = `crisisAskSelect-${context}`;
    return `
      <div class="zr-disclaimer crisis-note" style="margin-bottom:12px">
        <span class="icon-chip sm" style="flex-shrink:0"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8z"/></svg></span>
        <div style="flex:1;min-width:0">
          <span>In crisis right now? Set your country and this shows the right line for where you are — nothing leaves this device.</span>
          <select id="${selId}" name="${selId}" aria-label="Your country" class="field-select" style="margin-top:8px" onchange="Safety.applyAskedCountry(this.value)">${_countryOptionsHtml("")}</select>
        </div>
      </div>`;
  }

  /** Renders the persistent "in crisis right now" note — used both above
   *  active Recovery trackers and inside the Settings preview, which can
   *  both be present in the DOM at once (Settings is a persistent drawer,
   *  not removed when closed). `context` keeps the ask-picker's id/name
   *  unique between the two so they never collide. Nobody sees a specific
   *  country's number until they answer the picker at least once — see
   *  resolvedCountry() for why. */
  function renderCrisisNote(context = "note") {
    const pref = getCountryPref();
    if (!pref) return _renderCrisisAskNote(context);

    const code = resolvedCountry();
    const data = crisisLines(code);
    const name = countryName(code);
    const dirLink = `<a href="${_findAHelplineUrl(code)}" target="_blank" rel="noopener">findahelpline.com</a>`;
    let inner;
    if (data) {
      const chips = data.lines.map(l => {
        const href = l.tel ? `tel:${l.tel}` : `sms:${l.sms}${l.smsBody ? "?body=" + encodeURIComponent(l.smsBody) : ""}`;
        return `<a class="contact-chip" href="${href}">${ZG.esc(l.label)}</a>`;
      }).join("");
      inner = `
        <span>In crisis right now? <b>${ZG.esc(data.org)}</b>${name ? ` — ${ZG.esc(name)}` : ""}</span>
        <div class="contact-chip-row" style="margin-top:8px">${chips}</div>
        <p class="fine-print" style="margin:8px 0 0">${pref === "auto" ? "Auto-detected from your browser. " : ""}Wrong? Change it under Settings → Crisis line. Full directory: ${dirLink}.</p>`;
    } else {
      inner = `
        <span>In crisis right now? We don't have a saved line for ${name ? ZG.esc(name) : "that country"} yet.</span>
        <p class="fine-print" style="margin:8px 0 0">Find a verified local line at ${dirLink}, or change your country under Settings → Crisis line.</p>`;
    }
    return `
      <div class="zr-disclaimer crisis-note" style="margin-bottom:12px">
        <span class="icon-chip sm" style="flex-shrink:0"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8z"/></svg></span>
        <div style="flex:1;min-width:0">${inner}</div>
      </div>`;
  }

  function renderCrisisSettingsBlock() {
    const body = document.getElementById("crisisSettingsBody");
    if (!body) return;
    const pref = getCountryPref();
    body.innerHTML = `
      <select id="crisisCountrySelect" class="field-select">${_countryOptionsHtml(pref)}</select>
      <div id="crisisPreview" style="margin-top:10px">${renderCrisisNote("settingsPreview")}</div>`;
    document.getElementById("crisisCountrySelect")?.addEventListener("change", (e) => {
      setCountryPref(e.target.value);
      renderCrisisSettingsBlock();
      window.Recovery?.render?.();
    });
  }

  /** Does this section need a PIN right now? */
  function needsLock(section) {
    if (!isEnabled()) return false;
    return scope() === "app" ? !_unlockedApp : (section === "recovery" && !_unlockedRecovery);
  }

  function markUnlocked() { _unlockedApp = true; _unlockedRecovery = true; _resetAutoLockTimer(); }
  function _relock() { _unlockedApp = false; _unlockedRecovery = false; }
  function _resetAutoLockTimer() { clearTimeout(_lockTimer); _lockTimer = setTimeout(_relock, AUTOLOCK_MS); }

  document.addEventListener("visibilitychange", () => { if (document.hidden) _relock(); });
  window.addEventListener("nasvo:pause", _relock);   // Android shell: WebView doesn't always report "hidden"
  ["click", "keydown", "touchstart"].forEach(evt =>
    document.addEventListener(evt, () => { if (_unlockedApp || _unlockedRecovery) _resetAutoLockTimer(); }, { passive: true }));

  /* ── Lock screen ── */
  function showLockScreen(onUnlock) {
    document.getElementById("zrLockModal")?.remove();
    const wrap = document.createElement("div");
    wrap.id = "zrLockModal";
    wrap.className = "celebrate-wrap";
    wrap.innerHTML = `
      <div class="celebrate-card lock-card">
        <span class="icon-chip lg" style="margin:0 auto 14px">${window.Icons?.svg("lock") || ""}</span>
        <h3 role="heading" aria-level="2">Enter your PIN</h3>
        <p class="lock-sub">Just for you — no one else needs to see this.</p>
        <input type="password" inputmode="numeric" pattern="[0-9]*" id="lockPinInput" maxlength="8" autocomplete="off" placeholder="••••"/>
        <div class="lock-error" id="lockError" hidden>That's not it — try again.</div>
        <button class="btn-primary" style="width:100%;margin-top:14px" id="lockUnlockBtn">Unlock</button>
        <button class="btn-quiet" style="width:100%;margin-top:8px" id="lockForgotBtn">Forgot PIN?</button>
      </div>`;
    document.body.appendChild(wrap);
    const input = wrap.querySelector("#lockPinInput");
    setTimeout(() => input.focus(), 60);

    // Android app: offer fingerprint / face as a shortcut past the PIN (the PIN always still works).
    if (window.NativeBridge?.isNative?.() && Store.get("zg_native_biometric", true)) {
      NativeBridge.biometricAvailable().then((ok) => {
        if (!ok || !wrap.isConnected) return;
        const btn = document.createElement("button");
        btn.className = "btn-secondary"; btn.id = "lockBioBtn"; btn.style.cssText = "width:100%;margin-top:8px";
        btn.textContent = "Use fingerprint / face";
        wrap.querySelector("#lockUnlockBtn").after(btn);
        const go = async () => {
          if (await NativeBridge.biometricAuth({ title: "Unlock", subtitle: "Confirm it's you", cancel: "Use PIN" })) {
            markUnlocked(); wrap.remove(); onUnlock?.();
          }
        };
        btn.addEventListener("click", go);
        go();
      });
    }
    const tryUnlock = async () => {
      if (await verifyPin(input.value)) { markUnlocked(); wrap.remove(); onUnlock?.(); return; }
      wrap.querySelector("#lockError").hidden = false;
      input.value = "";
      const card = wrap.querySelector(".lock-card");
      card.classList.add("shake");
      setTimeout(() => card.classList.remove("shake"), 380);
    };
    wrap.querySelector("#lockUnlockBtn").addEventListener("click", tryUnlock);
    input.addEventListener("keydown", e => { if (e.key === "Enter") tryUnlock(); });
    wrap.querySelector("#lockForgotBtn").addEventListener("click", async () => {
      const ok = await ZG.confirm({ title: "Remove your PIN lock?", body: "Your habits, recovery history, and journal stay exactly as they are — nothing is deleted.", confirmLabel: "Remove lock", danger: true });
      if (ok) { disable(); wrap.remove(); onUnlock?.(); }
    });
  }

  /* ── Disguise mode ── */
  const _origTitle = document.title;
  function applyDisguise() {
    const s = loadSec();
    const brandEls = document.querySelectorAll(".brand-name, .topbar-brand");
    if (s.disguise && s.disguiseName) {
      document.title = s.disguiseName;
      brandEls.forEach(el => { if (!el.dataset.orig) el.dataset.orig = el.innerHTML; el.textContent = s.disguiseName; });
      _setFavicon(_plainFaviconHref());
    } else {
      document.title = _origTitle;
      brandEls.forEach(el => { if (el.dataset.orig) el.innerHTML = el.dataset.orig; });
      _setFavicon(null);
    }
  }
  function _plainFaviconHref() {
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><rect width="24" height="24" rx="6" fill="#5b5648"/><path d="M7 12h10M12 7v10" stroke="#f4ecdd" stroke-width="2" stroke-linecap="round"/></svg>`;
    return "data:image/svg+xml;base64," + btoa(svg);
  }
  function _setFavicon(href) {
    const link = document.querySelector('link[rel="icon"]');
    if (!link) return;
    if (!link.dataset.orig) link.dataset.orig = link.getAttribute("href");
    link.setAttribute("href", href || link.dataset.orig);
  }
  function setDisguise(enabled, name) {
    const s = loadSec(); s.disguise = enabled; s.disguiseName = (name || "Notes").trim() || "Notes"; saveSec(s); applyDisguise();
  }

  /* ── Trusted contacts ── */
  function getContacts() { return Store.get(CONTACTS_KEY, []); }
  function addContact({ name, phone, email, message }) {
    const list = getContacts();
    list.push({ id: "c" + Date.now(), name: name.trim(), phone: (phone || "").trim(), email: (email || "").trim(), message: (message || "").trim() });
    Store.set(CONTACTS_KEY, list);
  }
  function removeContact(id) { Store.set(CONTACTS_KEY, getContacts().filter(c => c.id !== id)); }

  function reachOutLinks(c) {
    const body = encodeURIComponent(c.message || "Hey — could use a distraction right now, you free to talk for a few minutes?");
    const digits = (c.phone || "").replace(/[^\d+]/g, "");
    const links = [];
    if (digits) links.push({ label: "Call", href: `tel:${digits}` });
    if (digits) links.push({ label: "Text", href: `sms:${digits}?body=${body}` });
    if (c.email) links.push({ label: "Email", href: `mailto:${c.email}?subject=${encodeURIComponent("Checking in")}&body=${body}` });
    return links;
  }

  /* ── Grounding tool: 5-4-3-2-1 sensory technique ──
     A standard grounding exercise for anxiety, panic, or a craving
     spike — reorients attention to the present through the senses,
     one at a time. No text input required (nothing to type mid-spike),
     just a slow walk through five short steps. */
  function _groundingSteps() {
    return [
      { sense: "See",   count: 5, prompt: "Look around. Name 5 things you can see right now." },
      { sense: "Touch", count: 4, prompt: "Notice 4 things you can physically feel — the ground, your clothes, the air." },
      { sense: "Hear",  count: 3, prompt: "Listen. Name 3 things you can hear." },
      { sense: "Smell", count: 2, prompt: "Notice 2 things you can smell." },
      { sense: "Taste", count: 1, prompt: "Name 1 thing you can taste, or how your mouth feels right now." },
    ];
  }

  function showGroundingTool() {
    document.getElementById("zrGroundModal")?.remove();
    const wrap = document.createElement("div");
    wrap.id = "zrGroundModal";
    wrap.className = "celebrate-wrap";
    document.body.appendChild(wrap);
    const steps = _groundingSteps();
    const contacts = getContacts();
    let idx = 0;

    function renderStep() {
      const s = steps[idx];
      const isLast = idx === steps.length - 1;
      wrap.innerHTML = `
        <div class="celebrate-card ground-card">
          <div class="ground-progress" aria-hidden="true">${steps.map((_, i) => `<span class="ground-dot${i <= idx ? " on" : ""}"></span>`).join("")}</div>
          <span class="icon-chip lg" style="margin:0 auto 14px">${window.Icons?.svg("breath") || ""}</span>
          <div class="ground-count">${s.count}</div>
          <h3 role="heading" aria-level="2" style="margin-bottom:6px">Things you can ${s.sense.toLowerCase()}</h3>
          <p class="lock-sub">${s.prompt}</p>
          <div style="display:flex;gap:8px;margin-top:18px">
            ${idx > 0 ? `<button class="btn-ghost" id="groundBack">Back</button>` : `<button class="btn-ghost" id="groundClose">Close</button>`}
            <button class="btn-primary" style="flex:1" id="groundNext">${isLast ? "I feel steadier" : "Next"}</button>
          </div>
          ${isLast && contacts.length ? `
            <p class="fine-print" style="margin-top:16px">Still not steady? Reach out to someone.</p>
            <div class="contact-chip-row">${contacts.flatMap(c => reachOutLinks(c).map(l => `<a class="contact-chip" href="${l.href}">${ZG.esc(c.name)} · ${l.label}</a>`)).join("")}</div>` : ""}
        </div>`;
      wrap.querySelector("#groundNext").addEventListener("click", () => {
        if (isLast) { done(); return; }
        idx++; renderStep();
      });
      wrap.querySelector("#groundBack")?.addEventListener("click", () => { idx--; renderStep(); });
      wrap.querySelector("#groundClose")?.addEventListener("click", () => done());
    }
    const done = () => { document.removeEventListener("keydown", onKey); wrap.remove(); };
    const onKey = (e) => { if (e.key === "Escape") done(); };
    renderStep();
    wrap.addEventListener("click", e => { if (e.target === wrap) done(); });
    document.addEventListener("keydown", onKey);
  }

  /* ── Settings UI (rendered into the blocks added in index.html) ── */
  function renderSettingsBlock() {
    const s = loadSec();

    renderCrisisSettingsBlock();

    const secBody = document.getElementById("securitySettingsBody");
    if (secBody) {
      secBody.innerHTML = s.enabled
        ? `<p class="fine-print" style="margin-top:0">PIN lock is on for <b>${s.scope === "app" ? "the whole app" : "Recovery & Journal only"}</b>.</p>
           <div class="settings-actions">
             <button class="btn-secondary" id="secChangePin">Change PIN</button>
             <button class="btn-danger-ghost" id="secDisablePin">Turn off lock</button>
           </div>`
        : `<label class="field-label" style="margin-top:0" for="secScopeSelect">What should the PIN protect?</label>
           <select id="secScopeSelect">
             <option value="recovery">Recovery &amp; Journal section only</option>
             <option value="app">The whole app</option>
           </select>
           <button class="btn-primary" id="secSetPin" style="margin-top:10px;width:100%">Set a PIN</button>`;
      document.getElementById("secSetPin")?.addEventListener("click", async () => {
        const scopeVal = document.getElementById("secScopeSelect")?.value || "recovery";
        const p1 = await ZG.prompt({ title: "Choose a PIN", body: "4 or more digits.", type: "password", inputMode: "numeric", confirmLabel: "Continue" });
        if (!p1) return;
        const p2 = await ZG.prompt({ title: "Confirm your PIN", type: "password", inputMode: "numeric", confirmLabel: "Confirm" });
        if (p1 !== p2) { ZG.toast("Those didn't match — try again"); return; }
        await setPin(p1, scopeVal);
        ZG.toast("PIN lock is on", 2600, { icon: "lock" });
        renderSettingsBlock();
      });
      document.getElementById("secChangePin")?.addEventListener("click", async () => {
        const cur = await ZG.prompt({ title: "Current PIN", type: "password", inputMode: "numeric", confirmLabel: "Continue" });
        if (!(await verifyPin(cur))) { ZG.toast("Incorrect PIN"); return; }
        const p1 = await ZG.prompt({ title: "New PIN", type: "password", inputMode: "numeric", confirmLabel: "Save" });
        if (!p1) return;
        await setPin(p1, loadSec().scope);
        ZG.toast("PIN updated");
      });
      document.getElementById("secDisablePin")?.addEventListener("click", async () => {
        const cur = await ZG.prompt({ title: "Enter your PIN", body: "To turn off the lock.", type: "password", inputMode: "numeric", confirmLabel: "Turn off lock" });
        if (!(await verifyPin(cur))) { ZG.toast("Incorrect PIN"); return; }
        disable();
        ZG.toast("Lock turned off");
        renderSettingsBlock();
      });
    }

    const disguiseBody = document.getElementById("disguiseSettingsBody");
    if (disguiseBody) {
      disguiseBody.innerHTML = `
        <div class="toggle-row">
          <div>
            <div class="toggle-row-label">Disguise this app</div>
            <div class="toggle-row-sub">Swaps the tab title &amp; icon for something plain</div>
          </div>
          <button class="switch${s.disguise ? " on" : ""}" id="disguiseToggle" role="switch" aria-checked="${s.disguise}" aria-label="Disguise this app"></button>
        </div>
        ${s.disguise ? `<input type="text" id="disguiseNameInput" placeholder="e.g. Notes" maxlength="20" value="${ZG.esc(s.disguiseName || "")}" style="margin-top:2px"/>
        <p class="fine-print" style="margin-top:6px">This only changes what's visible before you open the app — everything inside still says what it is.</p>` : ""}`;
      document.getElementById("disguiseToggle")?.addEventListener("click", () => {
        setDisguise(!s.disguise, s.disguiseName || "Notes");
        renderSettingsBlock();
      });
      document.getElementById("disguiseNameInput")?.addEventListener("change", e => setDisguise(true, e.target.value));
    }

    const contactsBody = document.getElementById("contactsSettingsBody");
    if (contactsBody) {
      const list = getContacts();
      contactsBody.innerHTML = `
        ${list.length ? list.map(c => `
          <div class="contact-row">
            <span class="icon-chip sm" style="--chip-color:var(--clay);--chip-bg:rgba(var(--clay-rgb),.14)">${window.Icons?.svg("signal") || ""}</span>
            <span class="contact-name">${ZG.esc(c.name)}</span>
            <button class="habit-del" data-rm="${c.id}" aria-label="Remove contact">✕</button>
          </div>`).join("") : `<p class="fine-print" style="margin-top:0">No one added yet — one or two people you'd actually reach out to.</p>`}
        <div class="add-row" style="margin-top:10px">
          <input type="text" id="contactNameInput" placeholder="Name" maxlength="30"/>
        </div>
        <div class="add-row" style="margin-top:8px">
          <input type="text" id="contactPhoneInput" placeholder="Phone (optional)" maxlength="30"/>
          <input type="text" id="contactEmailInput" placeholder="Email (optional)" maxlength="60"/>
        </div>
        <div class="add-row" style="margin-top:8px">
          <input type="text" id="contactMessageInput" placeholder="What you'd want it to say (optional — has a sensible default)" maxlength="140"/>
          <button class="btn-secondary" id="contactAddBtn">Add</button>
        </div>`;
      contactsBody.querySelectorAll("[data-rm]").forEach(btn =>
        btn.addEventListener("click", () => { removeContact(btn.dataset.rm); renderSettingsBlock(); }));
      document.getElementById("contactAddBtn")?.addEventListener("click", () => {
        const name = document.getElementById("contactNameInput").value.trim();
        const phone = document.getElementById("contactPhoneInput").value.trim();
        const email = document.getElementById("contactEmailInput").value.trim();
        const message = document.getElementById("contactMessageInput").value.trim();
        if (!name) { ZG.toast("Add a name first"); return; }
        if (!phone && !email) { ZG.toast("Add a phone or an email so there's a way to actually reach them"); return; }
        addContact({ name, phone, email, message });
        renderSettingsBlock();
      });
    }
  }

  document.addEventListener("DOMContentLoaded", () => {
    applyDisguise();
    // renderSettingsBlock() is intentionally NOT called here — app.js's
    // openSettings() already calls it fresh every time the Settings drawer
    // is opened, so rendering it up front on every page load (crisis-line
    // country list, security block, contacts) was pure unused work for the
    // common case where Settings is never opened in that visit.
    document.getElementById("groundBtnDesktop")?.addEventListener("click", showGroundingTool);
    document.getElementById("groundBtnMobile")?.addEventListener("click", showGroundingTool);
  });

  return {
    isEnabled, needsLock, markUnlocked, showLockScreen, setPin, verifyPin, disable, scope,
    setDisguise, applyDisguise, getContacts, addContact, removeContact, reachOutLinks, renderSettingsBlock, showGroundingTool,
    getCountryPref, setCountryPref, resolvedCountry, countryName, crisisLines, renderCrisisNote, applyAskedCountry,
  };
})();
window.Safety = Safety;

/* ─────────────────────────────────────────────────────────────
   Guard navigation: intercept showSection so a locked Recovery
   (or a locked whole app) shows the PIN screen instead of content.
   Wrapping happens at script-load time, before DOMContentLoaded
   fires and the app performs its first showSection() call.
   ───────────────────────────────────────────────────────────── */
(function guardNavigation() {
  const _origShowSection = window.showSection;
  if (typeof _origShowSection !== "function") return;
  function guarded(id) {
    if (Safety.needsLock(id)) { Safety.showLockScreen(() => _origShowSection(id)); return; }
    _origShowSection(id);
  }
  window.showSection = guarded;
  if (window.ZG) ZG.showSection = guarded;
})();
