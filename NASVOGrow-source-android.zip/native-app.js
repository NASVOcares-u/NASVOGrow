"use strict";
/* ═══════════════════════════════════════════════════════════════
   NATIVE APP GLUE — everything that only makes sense inside the
   Capacitor Android app, kept out of app.js so the web/PWA build is
   untouched. Every entry point returns immediately when
   NativeBridge.isNative() is false.

   Responsibilities
   • Decide WHAT to remind and WHEN (the same rules app.js uses for the
     web reminders), then hand a concrete schedule to NativeBridge so
     Android's alarm system fires it even with the app closed.
     Re-planned whenever habits change, settings change, or the app
     comes back to the foreground.
   • Keep the home-screen widget's snapshot current (habits + streak only).
   • Re-lock on resume when a PIN lock is on.
   • "On this phone" settings (private notifications, screenshot block,
     biometric unlock, widget).
   • Open same-origin target=_blank links (privacy policy, schema doc)
     in an in-app viewer instead of navigating the WebView away.
═══════════════════════════════════════════════════════════════ */
const NativeApp = (() => {
  const nb = () => window.NativeBridge;
  const native = () => !!nb()?.isNative?.();

  const K = { discreet: "zg_native_discreet", privacy: "zg_native_privacy", bio: "zg_native_biometric", widget: "zg_native_widget" };
  const flag = (k, d) => Store.get(k, d);

  const RISK_PLAIN = "This has been a harder hour for you before — worth a quick check-in with yourself right now.";
  const RISK_DISCREET = "A quiet moment to check in with yourself.";

  /** Notification title. A disguised app never shows its real name; otherwise
   *  recovery notifications use a neutral title while "private notifications" is on. */
  function titleFor(kind) {
    const s = Store.get("zg_security", {}) || {};
    if (s.disguise && s.disguiseName) return s.disguiseName;
    return kind === "recovery" && flag(K.discreet, true) ? "Reminder" : "NASVOGrow";
  }

  /** The schedule for the next week, from the same rules as app.js's web reminders. */
  function buildPlan(now = new Date()) {
    const hour = ZG.reminderThresholdHour();
    const { done, total } = window.Habits?.todayCounts?.() || { done: 0, total: 0 };
    const activeToday = Store.get("zg_active_dates", []).includes(_today());

    const evening = [];
    for (let n = 0; n < 7; n++) {
      const at = new Date(now.getFullYear(), now.getMonth(), now.getDate() + n, hour, 0, 0, 0);
      if (at.getTime() <= now.getTime()) continue;                 // that hour already passed today
      if (n === 0) {
        if (total > 0 && done === total) continue;                // everything's done — nothing to nudge
        if (activeToday && total === 0) continue;
      }
      const left = total - done;
      evening.push({
        n, at: at.getTime(),
        body: n === 0 && total > 0 ? `${left} habit${left === 1 ? "" : "s"} left today.` : "A quiet reminder — today's still open.",
      });
    }

    const risk = [];
    if (ZG.riskRemindersEnabled()) {
      const windows = window.Insights?.compute?.()?.riskWindows?.windows || [];
      const body = flag(K.discreet, true) ? RISK_DISCREET : RISK_PLAIN;
      windows.slice(0, 20).forEach((w, i) => risk.push({ n: i, weekday: w.dow + 1, hour: w.hour, minute: 0, body }));
    }
    return { title: { habits: titleFor("habits"), recovery: titleFor("recovery") }, evening, risk };
  }

  let _syncT = null, _pushT = null;
  function scheduleSync(delay = 700) { if (native()) { clearTimeout(_syncT); _syncT = setTimeout(syncNow, delay); } }
  function schedulePush(delay = 700) { if (native()) { clearTimeout(_pushT); _pushT = setTimeout(pushWidgetNow, delay); } }

  async function syncNow() {
    if (!native()) return;
    try {
      if (!ZG.notificationsEnabled() || !(await nb().hasPermission())) { await nb().cancelReminders(); return; }
      await nb().syncReminders(buildPlan());
    } catch { /* best effort */ }
  }

  function _isoLocal(d = new Date()) {
    const p = (n) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
  }
  function pushWidgetNow() {
    if (!native()) return;
    const title = titleFor("habits");      // the disguise name, if Disguise is on
    if (!flag(K.widget, true)) { nb().pushWidget({ enabled: false, done: 0, total: 0, streak: 0, date: _isoLocal(), title }); return; }
    const { done, total } = window.Habits?.todayCounts?.() || { done: 0, total: 0 };
    nb().pushWidget({ enabled: true, done, total, streak: ZG.getStreak?.() || 0, date: _isoLocal(), title });
  }

  /** PIN lock: after the app was in the background, show the lock screen again
   *  instead of waiting for the next navigation. */
  function lockIfNeeded() {
    const sec = document.querySelector(".app-section.active")?.id.replace("Section", "");
    if (sec && window.Safety?.needsLock?.(sec) && !document.getElementById("zrLockModal")) Safety.showLockScreen();
  }

  /* ── in-app viewer for bundled documents ── */
  async function openDoc(path) {
    document.getElementById("nativeDocOverlay")?.remove();
    const wrap = document.createElement("div");
    wrap.id = "nativeDocOverlay";
    wrap.className = "celebrate-wrap";
    const isMd = /\.md$/i.test(path);
    wrap.innerHTML = `
      <div class="celebrate-card" style="width:min(720px,96vw);height:min(86vh,900px);display:flex;flex-direction:column;padding:12px;text-align:left">
        ${isMd ? `<pre id="nativeDocText" style="flex:1;margin:0;overflow:auto;white-space:pre-wrap;font-size:.8125rem"></pre>`
               : `<iframe title="Document" src="${ZG.esc(path)}" style="flex:1;border:0;width:100%;border-radius:8px;background:#fff"></iframe>`}
        <button class="btn-secondary" id="nativeDocClose" style="margin-top:10px;width:100%">Close</button>
      </div>`;
    document.body.appendChild(wrap);
    wrap.querySelector("#nativeDocClose").addEventListener("click", () => wrap.remove());
    if (isMd) {
      try { wrap.querySelector("#nativeDocText").textContent = await (await fetch(path)).text(); }
      catch { wrap.querySelector("#nativeDocText").textContent = "Couldn't load this document."; }
    }
  }

  document.addEventListener("click", (e) => {
    if (!native()) return;
    const a = e.target.closest?.("a[target=_blank]");
    if (!a) return;
    let u;
    try { u = new URL(a.href, location.href); } catch { return; }
    if (u.origin !== location.origin) return;       // outside links: Android hands them to the browser
    e.preventDefault();
    openDoc(u.pathname);
  }, true);

  /* ── Settings: "On this phone" ── */
  function _row(id, label, sub, on) {
    return `<div class="toggle-row">
      <div><div class="toggle-row-label">${label}</div><div class="toggle-row-sub">${sub}</div></div>
      <button class="switch${on ? " on" : ""}" id="${id}" role="switch" aria-checked="${on}" aria-label="${label}"></button>
    </div>`;
  }

  async function renderSettings() {
    if (!native()) return;

    const sub = document.querySelector("#notifyToggle")?.closest(".toggle-row")?.querySelector(".toggle-row-sub");
    if (sub) sub.textContent = "A gentle evening nudge if today's still open — scheduled on this phone so it arrives even when the app is closed. Nothing is sent from a server.";

    let host = document.getElementById("nativeSettingsSection");
    if (!host) {
      host = document.createElement("div");
      host.id = "nativeSettingsSection";
      (document.getElementById("disguiseSettingsBody") || document.getElementById("autoBackupSection"))?.insertAdjacentElement("afterend", host);
    }
    if (!host.isConnected) return;

    const hasBio = await nb().biometricAvailable();
    const hasPriv = nb().privacyScreenAvailable();
    host.innerHTML = `
      <label class="field-label">On this phone</label>
      ${_row("nativeDiscreetToggle", "Private notifications", "Check-in notifications use neutral wording and hide their contents while your phone is locked.", !!flag(K.discreet, true))}
      ${hasPriv ? _row("nativePrivacyToggle", "Hide in recent apps &amp; block screenshots", "Blanks NASVOGrow in the app switcher and stops screenshots and screen recording.", !!flag(K.privacy, false)) : ""}
      ${hasBio ? _row("nativeBioToggle", "Fingerprint / face unlock", "Use biometrics on the PIN screen. Your PIN always still works.", !!flag(K.bio, true)) : ""}
      ${_row("nativeWidgetToggle", "Home-screen widget data", "Lets the widget show today's habits and your streak. Nothing from Recovery or your journal is ever shown on it.", !!flag(K.widget, true))}`;

    const bind = (id, key, dflt, after) => {
      const el = document.getElementById(id);
      el?.addEventListener("click", () => {
        const next = !flag(key, dflt);
        Store.set(key, next);
        el.classList.toggle("on", next);
        el.setAttribute("aria-checked", String(next));
        after?.(next);
      });
    };
    bind("nativeDiscreetToggle", K.discreet, true, () => scheduleSync(100));
    bind("nativePrivacyToggle", K.privacy, false, (on) => nb().setPrivacyScreen(on));
    bind("nativeBioToggle", K.bio, true);
    bind("nativeWidgetToggle", K.widget, true, () => pushWidgetNow());
  }

  function init() {
    if (!native()) return;

    // Re-plan whenever the numbers on Home change, or a reminder setting flips.
    const origChrome = ZG.refreshChrome;
    if (typeof origChrome === "function" && !origChrome._nativeWrapped) {
      const wrapped = function () { const r = origChrome.apply(this, arguments); scheduleSync(); schedulePush(); return r; };
      wrapped._nativeWrapped = true;
      ZG.refreshChrome = wrapped;
    }
    ["setNotificationsEnabled", "setRiskRemindersEnabled"].forEach((k) => {
      const o = ZG[k];
      if (typeof o === "function") ZG[k] = function () { const r = o.apply(this, arguments); scheduleSync(150); return r; };
    });

    window.addEventListener("nasvo:resume", () => { scheduleSync(300); schedulePush(300); lockIfNeeded(); });
    window.addEventListener("nasvo:pause", () => { syncNow(); pushWidgetNow(); });

    if (nb().privacyScreenAvailable()) nb().setPrivacyScreen(!!flag(K.privacy, false));
    scheduleSync(2500);
    schedulePush(1500);
  }
  document.addEventListener("DOMContentLoaded", init);

  return { buildPlan, syncNow, pushWidgetNow, renderSettings, openDoc, lockIfNeeded };
})();
window.NativeApp = NativeApp;
