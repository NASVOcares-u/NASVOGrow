"use strict";
/* ═══════════════════════════════════════════════════════════════
   RECOVERY — private sobriety / habit-breaking counters.
   This is the quietest corner of the app, deliberately:
     • No literal depictions of any substance — a wine glass or a
       cigarette is a cue, and cues trigger cravings. Every icon
       here is abstract (a shield, a wave, an anchor…).
     • Card surfaces are neutral, same as everywhere else — the
       category color lives only in the small icon chip, not the
       whole card, so this section doesn't feel like a candy grid.
     • Button copy sounds like a person talking to you, not a game
       awarding points.
     • A privacy veil (Settings, or the eye on any card) blurs the
       numbers — for the moment someone's looking over your shoulder.

   RECOVERY SCIENCE, added on top of the original counter:
     • Urge-surfing timer — cravings genuinely peak and pass, often
       within 15–20 minutes. A guided breathing timer gives you
       somewhere to put that time instead of white-knuckling it.
     • HALT + intensity check-in — Hungry / Angry / Lonely / Tired
       is a standard relapse-prevention frame. Naming it, plus a
       1–10 intensity read, turns a vague "note" into real signal
       Insights can later read back to you.
     • A personal "why" — your own words, surfaced exactly when an
       urge modal opens, not buried in Settings somewhere.
     • Coping plans — "if [trigger], then [action]" written ahead of
       time and surfaced during urge-surfing, same principle as the
       why: easier to follow a plan made clear-headed than one
       improvised mid-craving.
═══════════════════════════════════════════════════════════════ */
const Recovery = (() => {
  const KEY = "zg_recovery";
  const _peeked = new Set(); // tracker ids temporarily revealed this session
  const HALT_LABELS = { H: "Hungry", A: "Angry", L: "Lonely", T: "Tired", O: "Other" };

  const TYPES = {
    pornography:  { id: "pornography",  label: "Pornography",       sub: "Compulsive sexual content",  icon: "shield",  colorVar: "--danger", needsNote: true,
      note: "Responds well to CBT/ACT therapy. A therapist who specialises in behavioural or sex addiction can help." },
    social_media: { id: "social_media", label: "Social Media",      sub: "Phones & endless scrolling",  icon: "wave",    colorVar: "--clay" },
    gaming:       { id: "gaming",       label: "Video Gaming",      sub: "Compulsive & escapist play",  icon: "facet",   colorVar: "--accent" },
    caffeine:     { id: "caffeine",     label: "Caffeine",          sub: "Coffee, tea, energy drinks",  icon: "droplet", colorVar: "--gold", needsNote: true,
      note: "Tapering gradually is usually easier than stopping abruptly — withdrawal peaks around day 2–3." },
    nicotine:     { id: "nicotine",     label: "Tobacco & Nicotine", sub: "Smoking, vaping, dipping",   icon: "wind",    colorVar: "--muted", needsNote: true,
      note: "NRT (patches, gum) and prescription options meaningfully improve quit rates — a GP can help." },
    alcohol:      { id: "alcohol",      label: "Alcohol",           sub: "Drinking & dependency",       icon: "anchor",  colorVar: "--accent", needsNote: true, urgent: true,
      note: "Important: if you drink heavily, talk to a doctor before stopping — withdrawal can be medically serious.",
      resource: "SAMHSA National Helpline (US, free, 24/7): 1-800-662-4357. In crisis right now, set your country in the note above your trackers (or in Settings) and it'll show the right line." },
    binge_eating: { id: "binge_eating", label: "Compulsive Eating", sub: "Binge & emotional eating",    icon: "scale",   colorVar: "--gold", needsNote: true, isEating: true,
      note: "Responds well to CBT. A registered dietitian can help build balance rather than restriction. This tracks episode frequency over time, not food intake — and deliberately isn't a streak to defend, since eating recovery doesn't work like abstinence.",
      resource: "National Alliance for Eating Disorders Helpline (US): 866-662-1235, Mon–Fri 9am–7pm ET — not a crisis line. In crisis right now, set your country in the note above your trackers (or in Settings) and it'll show the right line." },
    cannabis:     { id: "cannabis",     label: "Cannabis",          sub: "Marijuana & THC products",    icon: "haze",    colorVar: "--accent", needsNote: true,
      note: "Withdrawal is rarely dangerous but can be genuinely uncomfortable — a doctor or counselor experienced in substance use can help you taper or quit." },
    gambling:     { id: "gambling",     label: "Gambling",          sub: "Betting & online wagering",   icon: "orbit",   colorVar: "--gold", needsNote: true,
      note: "Gambling can escalate quickly, especially online — a counselor trained in behavioral addiction can help.",
      resource: "National Council on Problem Gambling (US, free, 24/7): call or text 1-800-522-4700. In crisis right now, set your country in the note above your trackers (or in Settings) and it'll show the right line." },
    shopping:     { id: "shopping",     label: "Compulsive Spending", sub: "Shopping & impulse buying", icon: "spiral",  colorVar: "--clay", needsNote: true,
      note: "Often tangled up with mood or stress — a financial counselor or therapist can help untangle the two." },
    sugar:        { id: "sugar",        label: "Sugar & Junk Food", sub: "Cravings & compulsive snacking", icon: "pulse", colorVar: "--gold" },
  };

  /* ── Replacement suggestions — fallback ideas for "something better to
     do right now," used only when a tracker has no coping plan of its own
     yet (a personal plan, written clear-headed, always outranks a generic
     one). Deliberately general, low-effort, doable in a minute or two —
     the point is redirecting attention, not assigning a project. */
  const REPLACEMENT_SUGGESTIONS = {
    pornography:  ["Step outside for a few minutes", "Do 20 pushups or a short stretch", "Text a friend something unrelated"],
    social_media: ["Go for a short walk, phone in another room", "Read a few pages of something", "Tidy one small area near you"],
    gaming:       ["Do a quick chore you've been putting off", "Stretch or do a short workout", "Reach out to someone you haven't talked to in a while"],
    caffeine:     ["Drink a full glass of water first", "Step outside for fresh air", "Try a short walk instead"],
    nicotine:     ["Chew gum or a mint", "Do 10 slow breaths — in for 4, out for 6", "Go for a short walk"],
    alcohol:      ["Make a non-alcoholic drink you actually like", "Call someone from your trusted contacts", "Do something with your hands for a few minutes"],
    binge_eating: ["Drink a glass of water and wait 10 minutes", "Step away from the kitchen for a bit", "Do something with your hands — a short walk, a small chore"],
    cannabis:     ["Step outside for fresh air", "Do a short stretch or breathing exercise", "Text a friend something unrelated"],
    gambling:     ["Close the tab or app and put your phone in another room", "Do a quick physical task — a walk, some pushups", "Call someone from your trusted contacts"],
    shopping:     ["Close the tab and wait 30 minutes before deciding", "Write it on a list instead — revisit tomorrow", "Do something with your hands instead"],
    sugar:        ["Drink a glass of water first", "Have a piece of fruit instead", "Step outside for a few minutes"],
  };

  const MILESTONES = [
    { id: "m1d", days: 1, label: "24 Hours", xp: 30, msg: "Your first 24 hours. Every journey starts exactly here." },
    { id: "m3d", days: 3, label: "3 Days", xp: 50, msg: "Three days in — one of the hardest stretches. You made it." },
    { id: "m7d", days: 7, label: "1 Week", xp: 100, msg: "One week clean. Your brain is already adapting." },
    { id: "m14d", days: 14, label: "2 Weeks", xp: 160, msg: "Two weeks. New pathways are forming." },
    { id: "m30d", days: 30, label: "1 Month", xp: 260, msg: "One month free. You broke the immediate cycle." },
    { id: "m60d", days: 60, label: "2 Months", xp: 360, msg: "Two months. The distance keeps growing." },
    { id: "m90d", days: 90, label: "90 Days", xp: 480, msg: "90 days. Real consolidation happens here." },
    { id: "m180d", days: 180, label: "6 Months", xp: 700, msg: "Half a year. What had power over you is losing its grip." },
    { id: "m365d", days: 365, label: "1 Year", xp: 1500, msg: "One full year. You've become someone different." },
  ];

  function load() { return Store.get(KEY, { trackers: {} }); }
  function save(s) { Store.set(KEY, s); }

  async function addTracker(id) {
    if (!TYPES[id]) return;
    const s = load();
    if (s.trackers[id]) return;
    const type = TYPES[id];
    let streakStart = Date.now();
    let toastMsg = "Tracking started — day one begins now";
    if (!type.isEating) {
      const raw = await ZG.prompt({ title: "Already have some time in on this?", body: "Enter days already clean/quit — 0 if starting today.", placeholder: "0", value: "0", inputMode: "numeric", confirmLabel: "Continue" });
      let backdateDays = 0;
      if (raw != null) {
        const n = parseInt(raw, 10);
        if (!isNaN(n) && n > 0) backdateDays = Math.min(n, 3650);
      }
      streakStart = Date.now() - backdateDays * 86400000;
      if (backdateDays > 0) toastMsg = `Tracking started — counting from ${backdateDays} day${backdateDays === 1 ? "" : "s"} already in`;
    } else {
      toastMsg = "Tracking started — this logs frequency, not a streak";
    }
    s.trackers[id] = { addedAt: Date.now(), streakStart, urges: [], relapses: [], milestones: [], copingPlans: [], why: "" };
    save(s);
    ZG.markActiveToday();
    ZG.toast(toastMsg, 2600, { icon: type.icon, color: `var(${type.colorVar})` });
    render();
  }

  async function removeTracker(id) {
    const s = load();
    const removed = s.trackers[id];
    if (!removed) return;
    const ok = await ZG.confirm({ title: `Remove ${TYPES[id]?.label} tracker?`, body: "This deletes its history — you'll get a chance to undo right after.", confirmLabel: "Remove", danger: true });
    if (!ok) return;
    delete s.trackers[id];
    _peeked.delete(id);
    save(s);
    render();
    // Same reasoning as journal.js's delete-undo: this is months of a
    // person's recovery history, not a quick toggle, so the confirm step
    // stays and an undo window sits on top of it rather than replacing it.
    ZG.toast(`${TYPES[id]?.label || "Tracker"} removed`, 6000, {
      icon: TYPES[id]?.icon, color: `var(${TYPES[id]?.colorVar || "--accent"})`,
      actionLabel: "Undo",
      onAction: () => _restoreTracker(id, removed),
    });
  }

  /** Puts a just-removed tracker back exactly as it was — the full object
   *  captured before deletion, not a recomputed approximation, so urges,
   *  relapses, milestones, coping plans, and why are all restored intact.
   *  A named function (mirroring _undoRelapse below) so it's independently
   *  callable/testable without needing to drive the confirm/toast UI. */
  function _restoreTracker(id, snapshot) {
    const s = load();
    if (s.trackers[id]) return; // already restored, or a new tracker of the same type was added since — don't clobber it
    s.trackers[id] = snapshot;
    save(s);
    render();
  }

  function togglePeek(id) {
    _peeked.has(id) ? _peeked.delete(id) : _peeked.add(id);
    render();
  }

  /* ── the personal "why" ── */
  function setWhy(id, text) {
    const s = load(); if (!s.trackers[id]) return;
    s.trackers[id].why = (text || "").trim();
    save(s);
    render();
  }
  async function promptWhy(id) {
    const cur = load().trackers[id]?.why || "";
    const val = await ZG.prompt({ title: "Your why", body: "Short and honest — this shows up right when it matters most.", placeholder: "e.g. I want to be present for my kids", value: cur, confirmLabel: "Save" });
    if (val != null) setWhy(id, val);
  }

  /* ── money / time saved ──────────────────────────────────────────
     Optional, opt-in, per-tracker. Two numbers a person types in once
     ("about how much did this cost you per day, on average, when you
     were doing it regularly") and the app multiplies by days clean —
     no new tracking burden, no daily logging, just arithmetic on data
     the tracker already has. Skipped entirely for eating (isEating
     trackers have no day-streak to multiply against — see
     _renderFrequencyBlock's own reasoning for why that tracker never
     defends a streak in the first place).

     Money fits substances/behaviors with a direct spend (alcohol,
     nicotine, gambling, shopping, caffeine, sugar, cannabis); time fits
     the ones whose real cost was hours, not dollars (pornography,
     social media, gaming). Both are offered regardless of type — this
     is a guess at which will feel more honest to *this* person, not a
     rule, since someone's gaming habit might have a real subscription/
     hardware cost too, or someone's drinking might have cost them
     evenings more than money. */
  const SAVINGS_DEFAULT_MODE = {
    pornography: "time", social_media: "time", gaming: "time",
    caffeine: "money", nicotine: "money", alcohol: "money",
    cannabis: "money", gambling: "money", shopping: "money", sugar: "money",
  };

  function _computeSavings(id) {
    const t = load().trackers[id];
    const sv = t?.savings;
    if (!sv || !(sv.amountPerDay > 0)) return null;
    const days = _daysInfo(id).days;
    if (sv.mode === "money") {
      return { mode: "money", text: `${_formatMoney(sv.amountPerDay * days, sv.currency)} saved` };
    }
    return { mode: "time", text: `${_formatMinutes(sv.amountPerDay * days)} reclaimed` };
  }

  /* [symbol shown next to the amount, name, ISO code]. The symbol is what gets stored
     (existing data used a free-typed symbol, so old values keep working). */
  const CURRENCIES = [
    ["$", "US dollar", "USD"], ["€", "Euro", "EUR"], ["£", "British pound", "GBP"], ["₹", "Indian rupee", "INR"],
    ["¥", "Japanese yen", "JPY"], ["CN¥", "Chinese yuan", "CNY"], ["₩", "South Korean won", "KRW"],
    ["A$", "Australian dollar", "AUD"], ["C$", "Canadian dollar", "CAD"], ["NZ$", "New Zealand dollar", "NZD"],
    ["S$", "Singapore dollar", "SGD"], ["HK$", "Hong Kong dollar", "HKD"], ["CHF", "Swiss franc", "CHF"],
    ["R$", "Brazilian real", "BRL"], ["MX$", "Mexican peso", "MXN"], ["R", "South African rand", "ZAR"],
    ["₦", "Nigerian naira", "NGN"], ["KSh", "Kenyan shilling", "KES"], ["E£", "Egyptian pound", "EGP"],
    ["AED", "UAE dirham", "AED"], ["SAR", "Saudi riyal", "SAR"], ["₺", "Turkish lira", "TRY"],
    ["₽", "Russian ruble", "RUB"], ["zł", "Polish złoty", "PLN"], ["kr", "Krona / krone", "SEK, NOK, DKK"],
    ["₱", "Philippine peso", "PHP"], ["฿", "Thai baht", "THB"], ["₫", "Vietnamese dong", "VND"],
    ["Rp", "Indonesian rupiah", "IDR"], ["Rs", "Pakistani rupee", "PKR"], ["৳", "Bangladeshi taka", "BDT"],
  ];
  /** Best-guess default from the browser locale (e.g. en-IN -> ₹); falls back to $. */
  function _defaultCurrency() {
    const region = ((navigator.language || "").split("-")[1] || "").toUpperCase();
    const bySymbol = { IN: "₹", GB: "£", JP: "¥", CN: "CN¥", KR: "₩", AU: "A$", CA: "C$", NZ: "NZ$", SG: "S$", HK: "HK$",
      CH: "CHF", BR: "R$", MX: "MX$", ZA: "R", NG: "₦", KE: "KSh", EG: "E£", AE: "AED", SA: "SAR", TR: "₺", RU: "₽",
      PL: "zł", SE: "kr", NO: "kr", DK: "kr", PH: "₱", TH: "฿", VN: "₫", ID: "Rp", PK: "Rs", BD: "৳",
      DE: "€", FR: "€", ES: "€", IT: "€", NL: "€", BE: "€", AT: "€", IE: "€", PT: "€", FI: "€", GR: "€" };
    return bySymbol[region] || "$";
  }
  function _formatMoney(amount, currency) {
    const rounded = Math.round(amount);
    const cur = currency || "$";
    // Letter-style symbols (CHF, kr, zł, Rs...) read better with a space: "CHF 1,200".
    return `${cur}${/[A-Za-z\u0142]$/.test(cur) ? " " : ""}${rounded.toLocaleString("en-US")}`;
  }

  function _formatMinutes(totalMinutes) {
    const mins = Math.round(totalMinutes);
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `${hours}h ${mins % 60}m`;
    const days = Math.floor(hours / 24);
    return `${days}d ${hours % 24}h`;
  }

  function openSavingsModal(id) {
    const type = TYPES[id];
    const s = load(); const t = s.trackers[id]; if (!t) return;
    const existing = t.savings || null;
    const mode = existing?.mode || SAVINGS_DEFAULT_MODE[id] || "money";
    const curSym = existing?.currency || _defaultCurrency();
    const isCustomCur = !CURRENCIES.some(([sym]) => sym === curSym);
    document.getElementById("zrSavingsModal")?.remove();
    const wrap = document.createElement("div");
    wrap.id = "zrSavingsModal";
    wrap.className = "celebrate-wrap";
    wrap.innerHTML = `
      <div class="celebrate-card" style="text-align:left">
        <span class="icon-chip lg" style="--chip-color:var(${type.colorVar});margin:0 auto 14px">${window.Icons?.svg(mode === "money" ? "money" : "clock") || ""}</span>
        <h3 role="heading" aria-level="2" style="text-align:center;margin-bottom:8px">${existing ? "Edit savings tracking" : "Track what this is costing you"}</h3>
        <p style="font-size:0.78125rem;color:var(--muted);line-height:1.6;text-align:center;margin-bottom:14px">One honest estimate, multiplied by days clean. Change it anytime — this is never exact, just a way to feel the scale of it.</p>
        <div style="display:flex;gap:8px;margin-bottom:14px">
          <button class="zr-mode-pill${mode === "money" ? " active" : ""}" id="svModeMoney" type="button">${window.Icons?.svg("money", 1.6) || ""}<span>Money</span></button>
          <button class="zr-mode-pill${mode === "time" ? " active" : ""}" id="svModeTime" type="button">${window.Icons?.svg("clock", 1.6) || ""}<span>Time</span></button>
        </div>
        <div id="svCurrencyRow"${mode === "time" ? " hidden" : ""}>
          <label class="field-label" for="svCurrency" style="margin-top:2px">Currency</label>
          <select id="svCurrency" class="field-select">
            ${CURRENCIES.map(([sym, name, code]) => `<option value="${ZG.esc(sym)}"${sym === curSym ? " selected" : ""}>${ZG.esc(sym)} \u00b7 ${ZG.esc(name)} (${ZG.esc(code)})</option>`).join("")}
            <option value="__other"${isCustomCur ? " selected" : ""}>Other\u2026</option>
          </select>
          <input type="text" id="svCurrencyCustom" maxlength="3" placeholder="Your symbol, e.g. Ft" value="${isCustomCur ? ZG.esc(curSym) : ""}" aria-label="Custom currency symbol" style="margin-top:8px"${isCustomCur ? "" : " hidden"}/>
        </div>
        <label class="field-label" for="svAmount" id="svAmountLabel">${mode === "money" ? "Amount per day" : "Minutes per day"}</label>
        <input type="number" id="svAmount" inputmode="decimal" min="0" step="any" placeholder="${mode === "money" ? "e.g. 12" : "e.g. 90"}" value="${existing?.amountPerDay || ""}"/>
        <p class="fine-print" style="margin:8px 2px 0">${type.isEating ? "" : `On average, per day, back when you were doing this regularly.`}</p>
        <div style="display:flex;gap:8px;margin-top:16px">
          <button class="btn-ghost" style="flex:1" id="svCancel">Cancel</button>
          <button class="btn-quiet" style="flex:1;border-color:var(${type.colorVar});color:var(${type.colorVar})" id="svSave">${existing ? "Save changes" : "Save"}</button>
        </div>
        ${existing ? `<button class="btn-ghost" style="width:100%;margin-top:8px;color:var(--danger)" id="svRemove">Stop tracking this</button>` : ""}
      </div>`;
    document.body.appendChild(wrap);
    let curMode = mode;
    const setMode = (m) => {
      curMode = m;
      wrap.querySelector("#svModeMoney").classList.toggle("active", m === "money");
      wrap.querySelector("#svModeTime").classList.toggle("active", m === "time");
      wrap.querySelector("#svCurrencyRow").hidden = m !== "money";
      const chip = wrap.querySelector(".icon-chip"); if (chip) chip.innerHTML = window.Icons?.svg(m === "money" ? "money" : "clock") || "";
      wrap.querySelector("#svAmountLabel").textContent = m === "money" ? "Amount per day" : "Minutes per day";
      wrap.querySelector("#svAmount").placeholder = m === "money" ? "e.g. 12" : "e.g. 90";
    };
    const curSel = wrap.querySelector("#svCurrency"), curCustom = wrap.querySelector("#svCurrencyCustom");
    curSel.addEventListener("change", () => { curCustom.hidden = curSel.value !== "__other"; if (!curCustom.hidden) curCustom.focus(); });
    wrap.querySelector("#svModeMoney").addEventListener("click", () => setMode("money"));
    wrap.querySelector("#svModeTime").addEventListener("click", () => setMode("time"));
    const cleanup = () => document.removeEventListener("keydown", onKey);
    const cancel = () => { cleanup(); wrap.remove(); };
    const onKey = (e) => { if (e.key === "Escape") cancel(); };
    wrap.querySelector("#svCancel").addEventListener("click", cancel);
    wrap.querySelector("#svRemove")?.addEventListener("click", () => {
      const s2 = load(); if (s2.trackers[id]) { delete s2.trackers[id].savings; save(s2); }
      cleanup(); wrap.remove(); render();
    });
    wrap.querySelector("#svSave").addEventListener("click", () => {
      const raw = wrap.querySelector("#svAmount").value;
      const amountPerDay = parseFloat(raw);
      if (!(amountPerDay > 0)) { ZG.toast("Enter a number greater than 0"); return; }
      const picked = curSel.value === "__other" ? curCustom.value : curSel.value;
      const currency = (picked || "$").trim().slice(0, 3) || "$";
      const s2 = load(); if (!s2.trackers[id]) { cleanup(); wrap.remove(); return; }
      s2.trackers[id].savings = { mode: curMode, amountPerDay, ...(curMode === "money" ? { currency } : {}) };
      save(s2);
      cleanup(); wrap.remove();
      ZG.toast("Savings tracking on — you'll see it add up from here");
      render();
    });
    wrap.addEventListener("click", e => { if (e.target === wrap) cancel(); });
    document.addEventListener("keydown", onKey);
    setTimeout(() => wrap.querySelector("#svAmount")?.focus(), 60);
  }

  /* ── coping plans: "if [trigger], then [action]" — written ahead of time,
     when you're thinking clearly, so there's something concrete to reach
     for mid-urge instead of improvising. Deliberately no XP here, same as
     the "why" field above — this is a planning tool, not an action to farm. */
  function addCopingPlan(id, trigger, action) {
    trigger = (trigger || "").trim(); action = (action || "").trim();
    if (!trigger || !action) return;
    const s = load(); const t = s.trackers[id]; if (!t) return;
    if (!t.copingPlans) t.copingPlans = [];
    t.copingPlans.push({ id: "cp" + Date.now(), trigger, action, updatedAt: Date.now() });
    save(s);
    window.Challenges?.notify?.("plan");
    ZG.toast("Plan saved — it'll show up next time you ride one out");
    render();
  }

  function updateCopingPlan(id, planId, trigger, action) {
    trigger = (trigger || "").trim(); action = (action || "").trim();
    if (!trigger || !action) return;
    const s = load(); const t = s.trackers[id]; if (!t) return;
    const p = (t.copingPlans || []).find(x => x.id === planId); if (!p) return;
    p.trigger = trigger; p.action = action; p.updatedAt = Date.now();
    save(s);
    ZG.toast("Plan updated");
    render();
  }

  async function removeCopingPlan(id, planId) {
    const ok = await ZG.confirm({ title: "Remove this plan?", confirmLabel: "Remove", danger: true });
    if (!ok) return;
    const s = load(); const t = s.trackers[id]; if (!t) return;
    t.copingPlans = (t.copingPlans || []).filter(p => p.id !== planId);
    save(s);
    render();
  }

  function openPlanModal(id, planId = null) {
    const type = TYPES[id];
    const s = load(); const t = s.trackers[id]; if (!t) return;
    const existing = planId ? (t.copingPlans || []).find(p => p.id === planId) : null;
    document.getElementById("zrPlanModal")?.remove();
    const wrap = document.createElement("div");
    wrap.id = "zrPlanModal";
    wrap.className = "celebrate-wrap";
    wrap.innerHTML = `
      <div class="celebrate-card" style="text-align:left">
        <span class="icon-chip lg" style="--chip-color:var(${type.colorVar});margin:0 auto 14px">${window.Icons?.svg("compass") || ""}</span>
        <h3 role="heading" aria-level="2" style="text-align:center;margin-bottom:8px">${existing ? "Edit your plan" : "Make a plan for next time"}</h3>
        <p style="font-size:0.78125rem;color:var(--muted);line-height:1.6;text-align:center;margin-bottom:14px">A plan you write now, thinking clearly, is easier to follow than one you invent mid-urge.</p>
        <label class="field-label" for="planTrigger" style="margin-top:2px">When this happens…</label>
        <input type="text" id="planTrigger" placeholder="e.g. it's late and I'm scrolling in bed" maxlength="120" value="${existing ? ZG.esc(existing.trigger) : ""}"/>
        <label class="field-label" for="planAction">…I will</label>
        <input type="text" id="planAction" placeholder="e.g. put my phone in the other room and read instead" maxlength="160" value="${existing ? ZG.esc(existing.action) : ""}"/>
        <div style="display:flex;gap:8px;margin-top:16px">
          <button class="btn-ghost" style="flex:1" id="planCancel">Cancel</button>
          <button class="btn-quiet" style="flex:1;border-color:var(${type.colorVar});color:var(${type.colorVar})" id="planSave">${existing ? "Save changes" : "Save plan"}</button>
        </div>
      </div>`;
    document.body.appendChild(wrap);
    const cleanup = () => document.removeEventListener("keydown", onKey);
    const cancel = () => { cleanup(); wrap.remove(); };
    const onKey = (e) => { if (e.key === "Escape") cancel(); };
    wrap.querySelector("#planCancel").addEventListener("click", cancel);
    wrap.querySelector("#planSave").addEventListener("click", () => {
      const trigger = wrap.querySelector("#planTrigger").value.trim();
      const action = wrap.querySelector("#planAction").value.trim();
      if (!trigger || !action) { ZG.toast("Fill in both parts first"); return; }
      cleanup();
      wrap.remove();
      if (existing) updateCopingPlan(id, existing.id, trigger, action);
      else addCopingPlan(id, trigger, action);
    });
    wrap.addEventListener("click", e => { if (e.target === wrap) cancel(); });
    document.addEventListener("keydown", onKey);
    setTimeout(() => wrap.querySelector("#planTrigger")?.focus(), 60);
  }

  function _renderCopingPlans(id) {
    const type = TYPES[id];
    const s = load(); const t = s.trackers[id]; if (!t) return "";
    const plans = t.copingPlans || [];
    return `
      <div class="cp-block">
        <div class="cp-head">
          <span class="cp-label">Coping plans</span>
          <button class="btn-quiet cp-add" onclick="Recovery.openPlanModal('${id}')">+ Add a plan</button>
        </div>
        ${plans.length ? plans.map(p => `
          <div class="cp-row">
            <span class="cp-text"><b>If</b> ${ZG.esc(p.trigger)} <b>→</b> ${ZG.esc(p.action)}</span>
            <div class="cp-row-actions">
              <button class="habit-del" onclick="Recovery.openPlanModal('${id}','${p.id}')" aria-label="Edit plan" title="Edit">✎</button>
              <button class="habit-del" onclick="Recovery.removeCopingPlan('${id}','${p.id}')" aria-label="Remove plan">✕</button>
            </div>
          </div>`).join("") : `<p class="fine-print" style="margin:0 0 2px">No plan yet — write one now, for the moment before it happens.</p>`}
      </div>`;
  }

  /* ── replacement suggestion — "something better to do right now."
     Priority order: the tracker's own coping plans (written clear-headed,
     so they beat a generic idea) → curated fallback ideas → a nudge
     toward one of today's not-yet-done habits. That last one is shown as
     encouragement only — there's no tap-to-complete shortcut here, since
     letting someone "finish" a walk they haven't taken would just be
     trading one hollow completion for another. If they actually go do
     it, checking it off happens through the normal Habits flow after. */
  function showReplacementSuggestion(id) {
    const type = TYPES[id];
    const t = load().trackers[id];
    const plans = t?.copingPlans || [];
    const curated = REPLACEMENT_SUGGESTIONS[id] || ["Step outside for a few minutes", "Do something with your hands for a bit", "Reach out to someone you trust"];
    const h = window.Habits?.load?.();
    const todayDone = h ? (h.log[new Date().toDateString()] || []) : [];
    const openHabit = h ? h.habits.find(x => !todayDone.includes(x.id)) : null;

    document.getElementById("zrSuggestModal")?.remove();
    const wrap = document.createElement("div");
    wrap.id = "zrSuggestModal";
    wrap.className = "celebrate-wrap";
    wrap.innerHTML = `
      <div class="celebrate-card" style="text-align:left">
        <span class="icon-chip lg" style="--chip-color:var(${type.colorVar});margin:0 auto 14px">${window.Icons?.svg("compass") || ""}</span>
        <h3 role="heading" aria-level="2" style="text-align:center;margin-bottom:12px">Something better, right now</h3>
        ${plans.length ? `
          <p class="cp-label" style="margin:0 0 8px">Your own plan</p>
          <div class="why-box" style="flex-direction:column;align-items:stretch;gap:6px;margin-bottom:14px">${plans.map(p => `<span><b>If</b> ${ZG.esc(p.trigger)} <b>→</b> ${ZG.esc(p.action)}</span>`).join("")}</div>
        ` : `
          <p class="cp-label" style="margin:0 0 8px">A few ideas</p>
          <ul style="margin:0 0 14px;padding-left:18px;font-size:0.78125rem;color:var(--text);line-height:1.85">${curated.slice(0, 3).map(sug => `<li>${ZG.esc(sug)}</li>`).join("")}</ul>
        `}
        ${openHabit ? `<div class="why-box"><span class="icon-chip sm" style="--chip-color:var(${type.colorVar})">${window.Icons?.svg("check") || ""}</span><span>You haven't done "<b>${ZG.esc(openHabit.name)}</b>" yet today — that counts too.</span></div>` : ""}
        <button class="btn-quiet" style="width:100%;margin-top:16px" id="zrSuggestClose">Close</button>
      </div>`;
    document.body.appendChild(wrap);
    const close = () => { document.removeEventListener("keydown", onKey); wrap.remove(); };
    const onKey = (e) => { if (e.key === "Escape") close(); };
    wrap.querySelector("#zrSuggestClose").addEventListener("click", close);
    wrap.addEventListener("click", e => { if (e.target === wrap) close(); });
    document.addEventListener("keydown", onKey);
  }

  /* ── logging (now structured: note + HALT tags + 1–10 intensity) ── */
  const URGE_XP_DAILY_CAP = 5; // per tracker, per day — logging keeps working past this, XP just stops piling up

  function _urgesLoggedToday(id) {
    const s = load(); const t = s.trackers[id]; if (!t) return 0;
    const todayStr = new Date().toDateString();
    return (t.urges || []).filter(u => new Date(u.ts).toDateString() === todayStr).length;
  }

  function logUrge(id, payload = {}) {
    const s = load(); const t = s.trackers[id]; if (!t) return;
    const countToday = _urgesLoggedToday(id) + 1;
    t.urges.push({ ts: Date.now(), note: payload.note || "", halt: payload.halt || [], intensity: payload.intensity ?? null, surfSeconds: payload.surfSeconds ?? null, satisfaction: payload.satisfaction ?? null });
    save(s);
    window.Challenges?.notify?.("recovery");

    const label = countToday > 1 ? `Urge resisted (${countToday} today)` : "Urge resisted";
    if (countToday <= URGE_XP_DAILY_CAP) {
      ZG.addXP(6, label);
    } else {
      // Past the cap: still counts as an active day, still fully logged for
      // Insights to read later — just no more compounding XP for one day.
      ZG.markActiveToday();
      ZG.toast(`Logged — ${countToday} today. That's a hard day, not a farming loop, so XP for this one pauses past ${URGE_XP_DAILY_CAP}/day.`, 4200, { icon: TYPES[id].icon, color: `var(${TYPES[id].colorVar})` });
      ZG.refreshChrome();
    }
    render();
  }

  function logRelapse(id, payload = {}) {
    const s = load(); const t = s.trackers[id]; if (!t) return;
    const type = TYPES[id];
    const entry = { ts: Date.now(), note: payload.note || "", halt: payload.halt || [], intensity: payload.intensity ?? null, satisfaction: payload.satisfaction ?? null, streakDays: _daysInfo(id).days };
    t.relapses.push(entry);

    // Substance-style trackers reset the streak clock, same as before. The
    // eating tracker deliberately does not — see the frequency-block note.
    let snapshot = null;
    if (!type.isEating) {
      snapshot = { streakStart: t.streakStart, milestones: [...(t.milestones || [])] };
      t.streakStart = Date.now();
      t.milestones = [];
    }
    save(s);
    window.Challenges?.notify?.("relapse");
    ZG.markActiveToday();
    render();
    ZG.toast(
      type.isEating ? "Episode logged — no shame, this is the data that helps." : "Recovery isn't linear. Starting again takes real courage.",
      8000,
      { icon: type.icon, color: `var(${type.colorVar})`, actionLabel: "Undo", onAction: () => _undoRelapse(id, entry.ts, snapshot) }
    );
  }

  /** Reverses a just-logged relapse/episode — for the accidental tap, not
   *  for talking yourself out of an honest entry after the fact (the window
   *  is short on purpose). Only touches this one log entry, and the streak
   *  clock if there was one to restore. */
  function _undoRelapse(id, ts, snapshot) {
    const s = load(); const t = s.trackers[id]; if (!t) return;
    t.relapses = (t.relapses || []).filter(r => r.ts !== ts);
    if (snapshot) { t.streakStart = snapshot.streakStart; t.milestones = snapshot.milestones; }
    save(s);
    ZG.toast("Undone");
    render();
  }

  /** Deletes a single logged entry. Deliberately does NOT touch the current
   *  streak clock or milestones — it only corrects the historical record
   *  (what Insights reads), so undoing a misclick can't accidentally hand
   *  back days that weren't actually clean. */
  async function deleteUrge(id, ts) {
    const ok = await ZG.confirm({ title: "Delete this logged urge?", body: "This can't be undone.", confirmLabel: "Delete", danger: true });
    if (!ok) return;
    const s = load(); const t = s.trackers[id]; if (!t) return;
    t.urges = (t.urges || []).filter(u => u.ts !== ts);
    save(s);
    render();
  }
  async function deleteRelapse(id, ts) {
    const isEating = TYPES[id]?.isEating;
    const ok = await ZG.confirm({
      title: isEating ? "Delete this logged episode?" : "Delete this logged entry?",
      body: isEating ? "This can't be undone." : "This won't change your current streak clock — only the historical record.",
      confirmLabel: "Delete", danger: true,
    });
    if (!ok) return;
    const s = load(); const t = s.trackers[id]; if (!t) return;
    t.relapses = (t.relapses || []).filter(r => r.ts !== ts);
    save(s);
    render();
  }

  function _daysInfo(id) {
    const s = load(); const t = s.trackers[id];
    if (!t) return { days: 0, hours: 0, minutes: 0 };
    const totalSec = Math.floor((Date.now() - t.streakStart) / 1000);
    return { days: Math.floor(totalSec / 86400), hours: Math.floor((totalSec % 86400) / 3600), minutes: Math.floor((totalSec % 3600) / 60) };
  }

  function longestStreak(id) {
    const s = load(); const t = s.trackers[id]; if (!t) return 0;
    const relapses = t.relapses || [];
    const periods = relapses.length === 0
      ? [{ start: t.addedAt, end: Date.now() }]
      : [{ start: t.addedAt, end: relapses[0].ts },
         ...relapses.slice(0, -1).map((r, i) => ({ start: r.ts, end: relapses[i + 1].ts })),
         { start: relapses[relapses.length - 1].ts, end: Date.now() }];
    return Math.max(...periods.map(p => Math.floor((p.end - p.start) / 86400000)));
  }

  function _milestoneProgress(id) {
    const { days } = _daysInfo(id);
    const s = load(); const reached = s.trackers[id]?.milestones || [];
    const reachedList = MILESTONES.filter(m => reached.includes(m.id));
    const current = reachedList[reachedList.length - 1] || null;
    const next = MILESTONES.find(m => !reached.includes(m.id)) || null;
    const prevDays = current ? current.days : 0;
    const pct = next ? Math.min(100, Math.round(((days - prevDays) / (next.days - prevDays)) * 100)) : 100;
    return { current, next, pct };
  }

  function _checkMilestones(id) {
    const type = TYPES[id];
    if (type?.isEating) return; // frequency-based tracking — no abstinence ladder to climb
    const { days } = _daysInfo(id);
    const s = load(); const t = s.trackers[id]; if (!t) return;
    MILESTONES.forEach(m => {
      if (days >= m.days && !(t.milestones || []).includes(m.id)) {
        t.milestones = [...(t.milestones || []), m.id];
        save(s);
        ZG.addXP(m.xp, `${type.label} — ${m.label}`);
        setTimeout(() => ZG.celebrate({ icon: type.icon, color: `var(${type.colorVar})`, title: m.label, sub: type.label, body: m.msg }), 500);
      }
    });
  }

  /* ── "What's common, roughly" — a short, honest timeline per category.
     Deliberately general ("some people notice"), never a prediction for
     the individual reading it, and never a substitute for the medical
     notes above (needsNote/resource) — this is about normalizing the
     discomfort of the first few weeks so it doesn't get mistaken for
     "this isn't working" and used as a reason to give up. Collapsed by
     default (see _renderExpectations) so it doesn't crowd an already
     dense card. */
  // Timelines now live in content/recovery-expectations.js — a small,
  // focused file with no application logic, so a community PR refining
  // one of these never needs to touch this file at all (see CONTRIBUTING.md).
  const EXPECTATIONS = window.RecoveryExpectations || {};

  function _renderExpectations(id) {
    const items = EXPECTATIONS[id];
    if (!items || !items.length) return "";
    const current = _pickCurrentExpectation(items, _daysInfo(id).days);
    return `
      ${current ? `
      <div class="exp-now">
        <span class="exp-when">${ZG.esc(current.when)}</span>
        <span class="exp-text">${ZG.esc(current.text)}</span>
      </div>` : ""}
      <details class="exp-block">
        <summary class="exp-summary">${current ? "See the full timeline" : "What's common, roughly"}</summary>
        <div class="exp-list">
          ${items.map(it => `<div class="exp-row"><span class="exp-when">${ZG.esc(it.when)}</span><span class="exp-text">${ZG.esc(it.text)}</span></div>`).join("")}
        </div>
        <p class="fine-print" style="margin:8px 2px 0">General patterns some people notice — not a prediction for you specifically, and not medical advice.</p>
      </details>`;
  }

  /** Best-effort day-threshold extracted from a "when" string like
   *  "1–2 weeks" or "Day 4–9" — always the *lower* bound of a range, so
   *  a phase is surfaced as soon as it plausibly starts rather than only
   *  once it's nearly over. Free text some entries deliberately can't be
   *  anchored to a day ("Ongoing") returns null — that's fine, it just
   *  means that entry is never picked as "right now," only ever seen in
   *  the full expandable list below. This only ever reads content, never
   *  writes it, so new entries added to recovery-expectations.js work
   *  automatically without touching this function. */
  function _parseWhenDays(when) {
    const s = when.toLowerCase();
    const mult = { hour: 1 / 24, day: 1, week: 7, month: 30 };
    let m = s.match(/(\d+)(?:\s*[\u2013\u2010-]\s*\d+)?\+?\s*(hour|day|week|month)/);
    if (m) return Math.round(parseFloat(m[1]) * mult[m[2]]);
    m = s.match(/(hour|day|week|month)s?\s*(\d+)/);
    if (m) return Math.round(parseFloat(m[2]) * mult[m[1]]);
    if (/^(first|early)/.test(s)) return 0;
    return null;
  }

  /** Picks whichever entry's threshold is the largest one <= currentDays
   *  (the most advanced milestone actually reached) so the line shown
   *  always reflects real progress, not a countdown to what's next. */
  function _pickCurrentExpectation(items, currentDays) {
    let best = null, bestDays = -1;
    for (const it of items) {
      const d = _parseWhenDays(it.when);
      if (d !== null && d <= currentDays && d >= bestDays) { best = it; bestDays = d; }
    }
    if (best) return best;
    const withDays = items.filter(it => _parseWhenDays(it.when) !== null);
    if (withDays.length) return withDays.reduce((a, b) => _parseWhenDays(a.when) <= _parseWhenDays(b.when) ? a : b);
    return null; // nothing in this category could be anchored to a day at all
  }

  /* ── Learn panel — the mechanism behind all of the above, shared once
     across every active tracker rather than repeated per card (most of
     this is the same science regardless of category). Kept to a handful
     of short, plain-language ideas rather than a full course — enough to
     make the "why" legible without turning Recovery into a reading app. */
  // Topics now live in content/recovery-learn-topics.js — same reasoning
  // as EXPECTATIONS above.
  const LEARN_TOPICS = window.RecoveryLearnTopics || [];

  function _renderLearnPanel() {
    return `
      <details class="learn-block">
        <summary class="exp-summary">How dopamine &amp; habit change actually work</summary>
        <div class="learn-list">
          ${LEARN_TOPICS.map(t => `<div class="learn-row"><div class="learn-title">${ZG.esc(t.title)}</div><p class="learn-text">${ZG.esc(t.text)}</p></div>`).join("")}
        </div>
      </details>`;
  }

  function trackerCount() { return Object.keys(load().trackers).length; }
  function bestCurrentDays() {
    const ids = Object.keys(load().trackers).filter(id => !TYPES[id]?.isEating);
    if (!ids.length) return null;
    return Math.max(...ids.map(id => _daysInfo(id).days));
  }

  /** The binding constraint across every abstinence-style tracker at
   *  once — a reset on any one of them brings this back to 0, same as
   *  the "clean_streak_5" challenge's logic but as an always-visible
   *  Home number instead of a one-shot challenge. Eating is excluded,
   *  same reasoning as bestCurrentDays: it isn't a streak to defend. */
  function daysCleanAcrossAll() {
    const ids = Object.keys(load().trackers).filter(id => !TYPES[id]?.isEating);
    if (!ids.length) return null;
    return Math.min(...ids.map(id => _daysInfo(id).days));
  }
  function totalUrgesResisted() {
    return Object.values(load().trackers).reduce((s, t) => s + (t.urges?.length || 0), 0);
  }

  function _topHalt(id) {
    const s = load(); const t = s.trackers[id]; if (!t) return null;
    const counts = {};
    [...(t.urges || []), ...(t.relapses || [])].forEach(e => (e.halt || []).forEach(h => { counts[h] = (counts[h] || 0) + 1; }));
    const sorted = Object.entries(counts).sort((a, b) => b[1] - a[1]);
    return sorted.length ? sorted[0][0] : null;
  }

  /* ── structured check-in modal: HALT chips + intensity + optional note,
     used for a quick resist/relapse log AND as step one of urge-surfing ── */
  function _openCheckinModal({ icon, color, title, body, confirmLabel, showWhy, withDuration = false, onConfirm }) {
    document.getElementById("zrCheckinModal")?.remove();
    const wrap = document.createElement("div");
    wrap.id = "zrCheckinModal";
    wrap.className = "celebrate-wrap";
    const haltDefs = [["H", "Hungry"], ["A", "Angry"], ["L", "Lonely"], ["T", "Tired"], ["O", "Other"]];
    wrap.innerHTML = `
      <div class="celebrate-card" style="text-align:left">
        <span class="icon-chip lg" style="--chip-color:${color};margin:0 auto 14px">${window.Icons?.svg(icon) || ""}</span>
        <h3 role="heading" aria-level="2" style="text-align:center;margin-bottom:8px">${ZG.esc(title)}</h3>
        <p style="font-size:0.78125rem;color:var(--muted);line-height:1.6;text-align:center;margin-bottom:14px">${body}</p>
        ${showWhy ? `<div class="why-box"><span class="icon-chip sm" style="--chip-color:${color}">${window.Icons?.svg("compass") || ""}</span><span>${ZG.esc(showWhy)}</span></div>` : ""}
        <div class="field-label" id="haltTagsLabel" style="margin-top:${showWhy ? "14px" : "2px"}">What's going on right now? (optional)</div>
        <div class="halt-row" role="group" aria-labelledby="haltTagsLabel">${haltDefs.map(([k, l]) => `<button type="button" class="halt-chip" data-halt="${k}">${l}</button>`).join("")}</div>
        <label class="field-label" for="checkinIntensity">How intense does it feel? <span id="intensityReadout">5</span>/10</label>
        <input type="range" id="checkinIntensity" min="1" max="10" value="5"/>
        <textarea id="checkinNote" rows="2" placeholder="Anything else? (optional)" style="margin-top:10px"></textarea>
        ${withDuration ? `
        <div class="field-label" id="durationLabel">How long do you want to ride it out?</div>
        <div class="halt-row" id="durationRow" role="group" aria-labelledby="durationLabel">${[5, 10, 15, 20].map(m => `<button type="button" class="halt-chip${m === 10 ? " on" : ""}" data-dur="${m}">${m} min</button>`).join("")}</div>` : ""}
        <div style="display:flex;gap:8px;margin-top:16px">
          <button class="btn-ghost" style="flex:1" id="checkinCancel">Cancel</button>
          <button class="btn-quiet" style="flex:1;border-color:${color};color:${color}" id="checkinConfirm">${ZG.esc(confirmLabel)}</button>
        </div>
      </div>`;
    document.body.appendChild(wrap);
    const haltBtns = wrap.querySelectorAll('.halt-row:not(#durationRow) .halt-chip');
    haltBtns.forEach(b => b.addEventListener("click", () => b.classList.toggle("on")));
    const durBtns = wrap.querySelectorAll("#durationRow .halt-chip");
    durBtns.forEach(b => b.addEventListener("click", () => { durBtns.forEach(x => x.classList.remove("on")); b.classList.add("on"); }));
    const intensityInput = wrap.querySelector("#checkinIntensity");
    intensityInput.addEventListener("input", () => { wrap.querySelector("#intensityReadout").textContent = intensityInput.value; });
    wrap.querySelector("#checkinCancel").addEventListener("click", () => cancel());
    wrap.querySelector("#checkinConfirm").addEventListener("click", () => {
      const halt = [...haltBtns].filter(b => b.classList.contains("on")).map(b => b.dataset.halt);
      const intensity = parseInt(intensityInput.value, 10);
      const note = wrap.querySelector("#checkinNote").value.trim();
      const duration = withDuration ? parseInt(wrap.querySelector("#durationRow .halt-chip.on")?.dataset.dur || "10", 10) : null;
      cleanup();
      wrap.remove();
      onConfirm({ note, halt, intensity, ...(withDuration ? { duration } : {}) });
    });
    const cleanup = () => document.removeEventListener("keydown", onKey);
    const cancel = () => { cleanup(); wrap.remove(); };
    const onKey = (e) => { if (e.key === "Escape") cancel(); };
    wrap.addEventListener("click", e => { if (e.target === wrap) cancel(); });
    document.addEventListener("keydown", onKey);
    setTimeout(() => wrap.querySelector("#checkinNote")?.focus(), 60);
  }

  function showUrgeModal(id) {
    const type = TYPES[id];
    const why = load().trackers[id]?.why || "";
    _openCheckinModal({
      icon: type.icon, color: `var(${type.colorVar})`, title: "You stayed with it",
      body: `You felt the pull of <b>${ZG.esc(type.label)}</b> and chose not to act. What was going on?`,
      confirmLabel: "I resisted", showWhy: why,
      onConfirm: payload => logUrge(id, payload),
    });
  }

  function showRelapseModal(id) {
    const type = TYPES[id];
    const proceed = () => _showRelapseModalNow(id);
    const surfInstead = () => startUrgeSurf(id);
    if (window.Focus?.maybeShowRelapsePause) Focus.maybeShowRelapsePause(id, type, proceed, surfInstead);
    else proceed();
  }

  function _showRelapseModalNow(id) {
    const type = TYPES[id];
    let body;
    if (type.isEating) {
      const s = load(); const t = s.trackers[id];
      const recentCount = (t?.relapses || []).filter(r => Date.now() - r.ts <= 30 * 86400000).length;
      body = recentCount > 0
        ? `That'll be ${recentCount + 1} logged episode${recentCount + 1 === 1 ? "" : "s"} in the last 30 days. Each one is information, not a reset. What happened?`
        : `Episodes are part of recovery, not the end of it. What happened?`;
    } else {
      const { days } = _daysInfo(id);
      const streakText = days > 0 ? `${days} day${days !== 1 ? "s" : ""}` : null;
      body = streakText
        ? `You were free for <b>${streakText}</b>. That progress was real, even as you reset the clock. What happened?`
        : `Every attempt matters. Starting again takes the same courage as the first time. What happened?`;
    }
    _openCheckinModal({
      icon: type.icon, color: "var(--danger)", title: type.isEating ? "Log an episode" : "Start over",
      body, confirmLabel: type.isEating ? "Log episode" : "Start over — day 1",
      onConfirm: payload => logRelapse(id, payload),
    });
  }

  /* ── urge-surfing: check in, then ride out a breathing timer ── */
  function startUrgeSurf(id) {
    const type = TYPES[id];
    const t = load().trackers[id];
    const why = t?.why || "";
    const plans = t?.copingPlans || [];
    _openCheckinModal({
      icon: "breath", color: `var(${type.colorVar})`,
      title: "Before you decide anything",
      body: "Name what's going on, then ride out the wave. Cravings peak and pass — most fade within 15–20 minutes, whether or not you act on them.",
      confirmLabel: "Begin", showWhy: why, withDuration: true,
      onConfirm: ({ note, halt, intensity, duration }) => {
        _openSurfTimer({
          type, seconds: duration * 60, why, plans,
          onFinish: elapsed => _resolveSurf(id, type, { note, halt, intensity, surfSeconds: elapsed }),
          onStop: elapsed => _resolveSurf(id, type, { note, halt, intensity, surfSeconds: elapsed }),
        });
      },
    });
  }

  function _fmtMMSS(s) { const m = Math.floor(s / 60), sec = s % 60; return `${m}:${String(sec).padStart(2, "0")}`; }

  function _openSurfTimer({ type, seconds, why, plans = [], onFinish, onStop }) {
    document.getElementById("zrSurfModal")?.remove();
    const wrap = document.createElement("div");
    wrap.id = "zrSurfModal";
    wrap.className = "celebrate-wrap";
    const contacts = window.Safety?.getContacts?.() || [];
    const color = `var(${type.colorVar})`;
    wrap.innerHTML = `
      <div class="celebrate-card surf-card">
        ${why ? `<div class="why-box" style="margin-bottom:14px"><span class="icon-chip sm" style="--chip-color:${color}">${window.Icons?.svg("compass") || ""}</span><span>${ZG.esc(why)}</span></div>` : ""}
        ${plans.length ? `<div class="why-box" style="margin-bottom:14px;flex-direction:column;align-items:stretch;gap:6px">
            ${plans.map(p => `<span><b>If</b> ${ZG.esc(p.trigger)} <b>→</b> ${ZG.esc(p.action)}</span>`).join("")}
          </div>` : ""}
        <div class="breath-wrap">
          <div class="breath-circle" style="--breath-color:${color}"></div>
          <div class="breath-phase" id="breathPhase">Breathe in…</div>
        </div>
        <div class="surf-timer" id="surfTimer">${_fmtMMSS(seconds)}</div>
        <div class="surf-sub">This usually passes before the timer runs out.</div>
        ${contacts.length ? `<div class="contact-chip-row">${contacts.flatMap(c => (window.Safety.reachOutLinks(c) || []).map(l => `<a class="contact-chip" href="${l.href}">${ZG.esc(c.name)} · ${l.label}</a>`)).join("")}</div>` : ""}
        <div style="display:flex;gap:8px;margin-top:16px">
          <button class="btn-ghost" style="flex:1" id="surfPastIt">I'm past it</button>
          <button class="btn-quiet" style="flex:1" id="surfNeedStop">I need to stop</button>
        </div>
      </div>`;
    document.body.appendChild(wrap);

    let remaining = seconds, elapsed = 0, phaseIdx = 0;
    const phases = ["Breathe in…", "Hold…", "Breathe out…", "Hold…"];
    const phaseEl = wrap.querySelector("#breathPhase");
    const timerEl = wrap.querySelector("#surfTimer");
    const phaseTimer = setInterval(() => { phaseIdx = (phaseIdx + 1) % 4; phaseEl.textContent = phases[phaseIdx]; }, 4000);
    const countTimer = setInterval(() => {
      remaining--; elapsed++;
      timerEl.textContent = _fmtMMSS(Math.max(0, remaining));
      if (remaining <= 0) { cleanup(); onFinish(elapsed); }
    }, 1000);
    function cleanup() { clearInterval(phaseTimer); clearInterval(countTimer); wrap.remove(); }
    wrap.querySelector("#surfPastIt").addEventListener("click", () => { cleanup(); onFinish(elapsed); });
    wrap.querySelector("#surfNeedStop").addEventListener("click", () => { cleanup(); onStop(elapsed); });
  }

  function _resolveSurf(id, type, payload) {
    // Riding out the timer is the thing being rewarded here — count it the
    // moment the session ends, before the person even says how it went.
    window.Challenges?.notify?.("surf");
    document.getElementById("zrOutcomeModal")?.remove();
    const wrap = document.createElement("div");
    wrap.id = "zrOutcomeModal";
    wrap.className = "celebrate-wrap";
    wrap.innerHTML = `
      <div class="celebrate-card">
        <span class="icon-chip lg" style="--chip-color:var(${type.colorVar});margin:0 auto 14px">${window.Icons?.svg(type.icon) || ""}</span>
        <h3 role="heading" aria-level="2" style="text-align:center;margin-bottom:8px">How did that go?</h3>
        <p style="font-size:0.78125rem;color:var(--muted);text-align:center;margin-bottom:16px">Either answer is honest. Both count as real information.</p>
        <div style="display:flex;flex-direction:column;gap:8px">
          <button class="btn-primary" id="surfOutcomeResist">I rode it out</button>
          <button class="btn-ghost" id="surfOutcomeRelapse">${type.isEating ? "I had an episode" : "I gave in"}</button>
        </div>
      </div>`;
    document.body.appendChild(wrap);
    wrap.querySelector("#surfOutcomeResist").addEventListener("click", () => { wrap.remove(); _askSurfSatisfaction(type, payload, p => logUrge(id, p)); });
    wrap.querySelector("#surfOutcomeRelapse").addEventListener("click", () => { wrap.remove(); _askSurfSatisfaction(type, payload, p => logRelapse(id, p)); });
  }

  /** A quick, entirely skippable 1–10 "how did that actually feel" rating,
   *  asked only after an urge-surf session — a genuinely effortful few
   *  minutes, worth a moment of reflection. Deliberately NOT added to the
   *  plain "I resisted" quick-tap or a no-surf reset, since that's the
   *  app's fastest, most-used logging path and adding a second modal
   *  there would just be friction on the thing that should stay easy. */
  function _askSurfSatisfaction(type, payload, onDone) {
    document.getElementById("zrSatisfyModal")?.remove();
    const wrap = document.createElement("div");
    wrap.id = "zrSatisfyModal";
    wrap.className = "celebrate-wrap";
    wrap.innerHTML = `
      <div class="celebrate-card" style="text-align:left">
        <h3 role="heading" aria-level="2" style="text-align:center;margin-bottom:6px">One more thing (optional)</h3>
        <p style="font-size:0.78125rem;color:var(--muted);text-align:center;margin-bottom:14px">How satisfying did that actually feel? <span id="zrSatisfyReadout">5</span>/10</p>
        <input type="range" id="zrSatisfyInput" min="1" max="10" value="5"/>
        <div style="display:flex;gap:8px;margin-top:16px">
          <button class="btn-ghost" style="flex:1" id="zrSatisfySkip">Skip</button>
          <button class="btn-quiet" style="flex:1;border-color:var(${type.colorVar});color:var(${type.colorVar})" id="zrSatisfySave">Save</button>
        </div>
      </div>`;
    document.body.appendChild(wrap);
    const input = wrap.querySelector("#zrSatisfyInput");
    const readout = wrap.querySelector("#zrSatisfyReadout");
    input.addEventListener("input", () => { readout.textContent = input.value; });
    const finish = satisfaction => { document.removeEventListener("keydown", onKey); wrap.remove(); onDone({ ...payload, satisfaction }); };
    const onKey = (e) => { if (e.key === "Escape") finish(null); };
    wrap.querySelector("#zrSatisfySkip").addEventListener("click", () => finish(null));
    wrap.querySelector("#zrSatisfySave").addEventListener("click", () => finish(parseInt(input.value, 10)));
    wrap.addEventListener("click", e => { if (e.target === wrap) finish(null); });
    document.addEventListener("keydown", onKey);
  }

  /* ── rendering ── */
  function _chip(icon, colorVar, size = 38) {
    return `<span class="icon-chip" style="--chip-size:${size}px;--chip-color:var(${colorVar});--chip-bg:rgba(var(${colorVar}-rgb),.13)">${window.Icons?.svg(icon) || ""}</span>`;
  }

  function _renderGrid(activeIds) {
    return `
      <div class="card">
        <p style="font-size:0.78125rem;color:var(--muted);margin-bottom:12px">Choose what you're working on. This stays on your device only — see the icon-shaped lock note below.</p>
        <div class="zr-grid">
          ${Object.values(TYPES).map(t => `
            <button class="zr-type-btn ${activeIds.includes(t.id) ? "on" : ""}" style="--zt-c:var(${t.colorVar});--zt-r:var(${t.colorVar}-rgb)"
                    onclick="Recovery.toggleType('${t.id}')">
              ${_chip(t.icon, t.colorVar, 34)}
              <span class="zr-type-text">
                <span class="zr-type-label">${t.label}</span>
                <span class="zr-type-sub">${t.sub}</span>
              </span>
              <span class="zr-type-state">${activeIds.includes(t.id) ? "Tracking" : ""}</span>
            </button>`).join("")}
        </div>
        <div class="zr-disclaimer">
          <span class="icon-chip sm" style="flex-shrink:0"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg></span>
          <span>Not medical care. For alcohol or nicotine, involve a doctor — withdrawal can need supervision. For eating, work with a therapist and dietitian. If you're in crisis right now, you'll be asked to set your country once you add a tracker — after that, your line shows above the list, editable anytime in Settings.</span>
        </div>
      </div>`;
  }

  /** A single, quiet crisis line shown above the active-tracker list whenever
   *  at least one tracker exists — regardless of which type(s). This used to
   *  be a single hardcoded "call or text 988" line, which is only actually
   *  true for people in the US/Canada — everyone else got a US number and a
   *  bare "findahelpline.com" mention. Safety.renderCrisisNote() now matches
   *  this to a country guessed locally from the browser's own language
   *  setting (no IP lookup, no geolocation prompt, no network call), against
   *  a small curated table of real national lines, with a direct
   *  findahelpline.com link either way — see safety.js for the full
   *  reasoning and the table itself. This doesn't replace the
   *  substance-specific resource lines (SAMHSA, the eating-disorder
   *  helpline) — those stay where they are, since they're genuinely more
   *  specific and useful for those cases. */
  function _renderCrisisNote() {
    return window.Safety?.renderCrisisNote?.("recoveryPanel") || `
      <div class="zr-disclaimer" style="margin-bottom:12px">
        <span class="icon-chip sm" style="flex-shrink:0"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8z"/></svg></span>
        <span>In crisis right now? Find a local crisis line at findahelpline.com.</span>
      </div>`;
  }

  function _renderRecentLog(id) {
    const type = TYPES[id];
    const s = load(); const t = s.trackers[id]; if (!t) return "";
    const events = [
      ...(t.urges || []).map(u => ({ ...u, kind: "urge" })),
      ...(t.relapses || []).map(r => ({ ...r, kind: "relapse" })),
    ].sort((a, b) => b.ts - a.ts).slice(0, 6);
    if (!events.length) return "";
    return `
      <div class="zr-log-label">Recent activity</div>
      <div class="zr-log-list veil-target">
        ${events.map(e => {
          const d = new Date(e.ts).toLocaleDateString("en", { month: "short", day: "numeric" });
          const tags = (e.halt || []).map(h => HALT_LABELS[h] || h).join(", ");
          const fn = e.kind === "urge" ? "deleteUrge" : "deleteRelapse";
          const kindLabel = e.kind === "urge" ? "Resisted" : (type?.isEating ? "Episode" : "Reset");
          return `<div class="zr-log-row">
            <span class="zr-log-kind ${e.kind}">${kindLabel}</span>
            <span class="zr-log-meta">${d}${tags ? ` · ${tags}` : ""}${e.intensity != null ? ` · ${e.intensity}/10` : ""}</span>
            <button class="habit-del" onclick="Recovery.${fn}('${id}', ${e.ts})" aria-label="Delete entry">✕</button>
          </div>`;
        }).join("")}
      </div>`;
  }

  /** Streak + milestone ladder — used for every tracker except eating. */
  function _renderAbstinenceBlock(id) {
    const type = TYPES[id];
    const info = _daysInfo(id);
    const ms = _milestoneProgress(id);
    const curLabel = ms.current ? ms.current.label : "Day one";
    const nextText = ms.next ? `${ms.next.label} in ${Math.max(0, ms.next.days - info.days)}d` : "All milestones reached";
    return `
      <div class="zr-counter">
        <div class="veil-target">
          <div class="zr-counter-days">${info.days}</div>
          <div class="zr-counter-unit">day${info.days === 1 ? "" : "s"}</div>
          <div class="zr-counter-sub">${String(info.hours).padStart(2, "0")}h ${String(info.minutes).padStart(2, "0")}m into this one</div>
        </div>
      </div>
      <div class="zr-ms-row"><span class="zr-ms-cur">${curLabel}</span><span class="zr-ms-next">${nextText}</span></div>
      ${ms.next ? `<div class="zr-ms-bar"><div class="zr-ms-fill" style="width:${ms.pct}%;background:var(${type.colorVar})"></div></div>` : ""}`;
  }

  /** Frequency counter — used only for eating. No "day one," no milestone
   *  ladder: abstinence framing doesn't fit a behavior recovery doesn't
   *  mean stopping entirely, and a defended streak here can itself push
   *  toward restriction. An episode is a data point, not a reset. */
  function _renderFrequencyBlock(id) {
    const s = load(); const t = s.trackers[id];
    const relapses = (t?.relapses || []).slice().sort((a, b) => a.ts - b.ts);
    const now = Date.now();
    const last30 = relapses.filter(r => now - r.ts <= 30 * 86400000).length;
    const lastEpisode = relapses.length ? relapses[relapses.length - 1] : null;
    const daysSince = lastEpisode ? Math.floor((now - lastEpisode.ts) / 86400000) : Math.floor((now - (t?.addedAt || now)) / 86400000);
    const longest = longestStreak(id);
    return `
      <div class="zr-freq-grid veil-target">
        <div class="zr-freq-cell"><span class="zr-freq-val">${last30}</span><span class="zr-freq-lbl">Episodes, last 30 days</span></div>
        <div class="zr-freq-cell"><span class="zr-freq-val">${daysSince}</span><span class="zr-freq-lbl">${lastEpisode ? "Days since last episode" : "Days tracking, none logged"}</span></div>
        <div class="zr-freq-cell"><span class="zr-freq-val">${longest}</span><span class="zr-freq-lbl">Longest stretch so far</span></div>
      </div>
      <p class="fine-print" style="margin:10px 2px 0">A frequency count, not a streak to defend — an episode here is a data point, not a reset.</p>`;
  }

  /* Which cards have their "Plan, history & details" section open — kept so the 60-second
     refresh and every log action re-render without collapsing what you were reading. */
  const _moreOpen = new Set();
  function setMore(id, open) { if (open) _moreOpen.add(id); else _moreOpen.delete(id); }

  function _renderCard(id) {
    const type = TYPES[id];
    const s = load(); const t = s.trackers[id];
    const urges = t?.urges?.length || 0, relapses = t?.relapses?.length || 0;
    const peeked = _peeked.has(id);
    const topHalt = _topHalt(id);
    const counterBlock = type.isEating ? _renderFrequencyBlock(id) : _renderAbstinenceBlock(id);
    const urgeTxt = `${urges} urge${urges === 1 ? "" : "s"} resisted`;
    const moreMeta = type.isEating ? urgeTxt : `Longest ${longestStreak(id)}d \u00b7 ${urgeTxt}`;
    const urgesToday = _urgesLoggedToday(id);
    const savings = type.isEating ? null : _computeSavings(id);
    const savingsSpan = savings ? `<span>${savings.text}<button class="veil-toggle" style="display:inline-flex;vertical-align:-3px;padding:2px 0 2px 4px" onclick="Recovery.openSavingsModal('${id}')" aria-label="Edit savings tracking">✎</button></span>` : "";
    const statsLine = type.isEating
      ? `<div class="zr-stats veil-target">
           <span>Urges resisted: <b>${urges}</b></span>
           ${urgesToday > 1 ? `<span>Today: <b>${urgesToday}</b></span>` : ""}
           ${topHalt ? `<span>Common trigger: <b>${(HALT_LABELS[topHalt] || topHalt)}</b></span>` : ""}
         </div>`
      : `<div class="zr-stats veil-target">
           <span>Longest: <b>${longestStreak(id)}d</b></span>
           ${savingsSpan}
           <span>Urges resisted: <b>${urges}</b></span>
           ${urgesToday > 1 ? `<span>Today: <b>${urgesToday}</b></span>` : ""}
           ${relapses > 0 ? `<span>Fresh starts: <b>${relapses}</b></span>` : ""}
           ${topHalt ? `<span>Common trigger: <b>${(HALT_LABELS[topHalt] || topHalt)}</b></span>` : ""}
         </div>`;

    return `
      <div class="zr-card${peeked ? " peek" : ""}" style="--zt-c:var(${type.colorVar});--zt-r:var(${type.colorVar}-rgb)">
        <div class="zr-card-head">
          ${_chip(type.icon, type.colorVar)}
          <div class="zr-card-meta"><div class="zr-card-name">${type.label}</div><div class="zr-card-sub">${type.sub}</div></div>
          <div class="zr-card-tools">
            <button class="veil-toggle" onclick="Recovery.togglePeek('${id}')" aria-label="${peeked ? "Hide numbers" : "Reveal numbers"}" title="${peeked ? "Hide numbers" : "Reveal numbers"}">${window.Icons?.svg(peeked ? "eyeOff" : "eye") || ""}</button>
            <button class="zr-card-rm" onclick="Recovery.removeTracker('${id}')" aria-label="Remove tracker">✕</button>
          </div>
        </div>

        ${counterBlock}

        <button class="zr-surf-btn" style="--zt-c:var(${type.colorVar});--zt-r:var(${type.colorVar}-rgb)" onclick="Recovery.startUrgeSurf('${id}')">
          ${window.Icons?.svg("breath") || ""}<span>Feeling it right now? Ride it out</span>
        </button>
        <div class="zr-actions">
          <button class="zr-btn-u" onclick="Recovery.showUrgeModal('${id}')">I resisted an urge</button>
          <button class="zr-btn-r" onclick="Recovery.showRelapseModal('${id}')">${type.isEating ? "Log an episode" : "Start over"}</button>
        </div>

        <button class="zr-swap-btn" onclick="Recovery.showReplacementSuggestion('${id}')">
          ${window.Icons?.svg("compass") || ""}<span>Something better to do right now</span>
        </button>

        ${type.needsNote ? `<div class="zr-pro${type.urgent ? " urgent" : ""}">${_chip(type.urgent ? "shield" : "shield", type.colorVar, 26)}<span>${type.note}</span></div>` : ""}
        ${type.resource ? `<div class="zr-pro urgent">${_chip("shield", "--danger", 26)}<span>${type.resource}</span></div>` : ""}

        <details class="zr-more"${_moreOpen.has(id) ? " open" : ""} ontoggle="Recovery.setMore('${id}', this.open)">
          <summary><span class="zr-more-label">Details &amp; history</span><span class="zr-more-meta veil-target">${moreMeta}</span></summary>
          <div class="zr-more-body">
        ${t.why
          ? `<div class="why-box why-box-card"><span class="icon-chip sm" style="--chip-color:var(${type.colorVar})">${window.Icons?.svg("compass") || ""}</span><span>${ZG.esc(t.why)}</span><button class="veil-toggle" onclick="Recovery.promptWhy('${id}')" aria-label="Edit your why">✎</button></div>`
          : `<button class="btn-quiet zr-why-btn" onclick="Recovery.promptWhy('${id}')"><span class="icon-chip sm" style="--chip-size:22px;--chip-color:var(${type.colorVar})">${window.Icons?.svg("compass") || ""}</span>Set your why — shown right when it matters</button>`}

        ${type.isEating || savings ? "" : `<button class="btn-quiet zr-why-btn" onclick="Recovery.openSavingsModal('${id}')"><span class="icon-chip sm" style="--chip-size:22px;--chip-color:var(${type.colorVar})">${window.Icons?.svg(SAVINGS_DEFAULT_MODE[id] === "time" ? "clock" : "money") || ""}</span>Track ${SAVINGS_DEFAULT_MODE[id] === "time" ? "time" : "money"} this is costing you</button>`}

        ${_renderCopingPlans(id)}

        ${_renderExpectations(id)}

        ${statsLine}

        ${_renderRecentLog(id)}
          </div>
        </details>
      </div>`;
  }

  function renderSummary() {
    const card = document.getElementById("recoverySummary");
    if (!card) return;
    const s = load();
    const ids = Object.keys(s.trackers);
    ids.forEach(_checkMilestones);
    const count = ids.length;
    const best = bestCurrentDays();
    const urges = totalUrgesResisted();
    const bigLbl = best != null ? "best current streak (days)" : (count ? "no day-count trackers yet" : "nothing tracked yet");
    card.innerHTML = `
      <div class="summary-head">
        <div class="summary-big"><span class="summary-num">${best != null ? best : "—"}</span><span class="summary-lbl">${bigLbl}</span></div>
        <div class="summary-chips">
          <span class="summary-chip">${count} tracker${count === 1 ? "" : "s"}</span>
          ${count ? `<span class="summary-chip">${urges} urge${urges === 1 ? "" : "s"} resisted</span>` : ""}
        </div>
      </div>
      <button class="btn-secondary rec-add" onclick="Recovery.openOptions()">+ Add tracker</button>`;
    card.classList.add("rec-summary");
  }

  function renderOptions() {
    const body = document.getElementById("recoveryOptionsBody");
    if (!body) return;
    const ids = Object.keys(load().trackers);
    body.innerHTML = _renderGrid(ids);
  }

  function renderActive() {
    const body = document.getElementById("recoveryActiveBody");
    if (!body) return;
    const ids = Object.keys(load().trackers);
    body.innerHTML = ids.length
      ? _renderCrisisNote() + ids.map(_renderCard).join("") + _renderLearnPanel()
      : `<div class="empty-note">No active trackers yet. Add one above to start.</div>`;
  }

function openOptions() { renderOptions(); ZG.openModal("recoveryOptionsModal"); }

  function render() {
    renderSummary();
    renderOptions();
    renderActive();
  }

  function toggleType(id) {
    const s = load();
    if (s.trackers[id]) removeTracker(id); else addTracker(id);
  }

  ZG.sectionRenderers.recovery = (() => {
    const prev = ZG.sectionRenderers.recovery; // journal + challenges, already composed
    return () => { prev?.(); render(); };
  })();
  // Rendered on demand the first time Recovery is opened, not on every page
  // load — see the matching note in journal.js.
  setInterval(() => { if (document.getElementById("recoverySection")?.classList.contains("active")) render(); }, 60000);

  /* Trackers / Journal / Challenges: one short screen each instead of one 5,000 px scroll. */
  const REC_TABS = ["trackers", "journal", "challenges"];
  function showTab(name) {
    if (!REC_TABS.includes(name)) name = "trackers";
    Store.set("zg_rec_tab", name);
    REC_TABS.forEach((n) => {
      const on = n === name, tab = document.getElementById("recTab-" + n), panel = document.getElementById("recPanel-" + n);
      if (tab) { tab.setAttribute("aria-selected", String(on)); tab.tabIndex = on ? 0 : -1; }
      if (panel) panel.hidden = !on;
    });
  }
  document.addEventListener("DOMContentLoaded", () => {
    const bar = document.getElementById("recTabs");
    if (!bar) return;
    showTab(Store.get("zg_rec_tab", "trackers"));
    bar.addEventListener("click", (e) => { const t = e.target.closest("[data-rtab]"); if (t) showTab(t.dataset.rtab); });
    bar.addEventListener("keydown", (e) => {                       // arrow keys move between tabs (WAI-ARIA tabs pattern)
      const i = REC_TABS.findIndex((n) => document.getElementById("recTab-" + n) === document.activeElement);
      if (i < 0 || !["ArrowLeft", "ArrowRight", "Home", "End"].includes(e.key)) return;
      e.preventDefault();
      const j = e.key === "Home" ? 0 : e.key === "End" ? REC_TABS.length - 1 : (i + (e.key === "ArrowRight" ? 1 : REC_TABS.length - 1)) % REC_TABS.length;
      showTab(REC_TABS[j]); document.getElementById("recTab-" + REC_TABS[j])?.focus();
    });
  });

  return {
    addTracker, removeTracker, toggleType, togglePeek, logUrge, logRelapse, deleteUrge, deleteRelapse, showUrgeModal, showRelapseModal,
    startUrgeSurf, setWhy, promptWhy, addCopingPlan, updateCopingPlan, removeCopingPlan, openPlanModal, showReplacementSuggestion, openSavingsModal,
    render, renderSummary, openOptions, showTab, setMore, trackerCount, bestCurrentDays, daysCleanAcrossAll, longestStreak, load, TYPES, MILESTONES, HALT_LABELS,
  };
})();
window.Recovery = Recovery;
