"use strict";
/* ═══════════════════════════════════════════════════════════════
   STREAK CARD — a downloadable PNG, client-rendered entirely on-
   device (same spirit as export.js's print summary: nothing here is
   sent anywhere, and this needs no new dependency — canvas is a
   built-in browser API). For anyone who wants to post progress
   somewhere public, on their own terms and their own timing, rather
   than the app doing any sharing on their behalf.

   What it shows, deliberately narrow: the streak number, the
   identity tier (unchanged by Calm Mode — see app.js's own comment on
   why tiers/streaks stay visible under Calm Mode while XP/levels
   don't), and — only if the person has already set them in their own
   profile — their name and motto. Nothing from Recovery ever appears
   here; a resisted-urge count or a tracker label is exactly the kind
   of thing that shouldn't end up in a screenshot heading for a public
   feed. If Calm Mode is on, the tier/streak framing stays but the
   card drops the "Level"-flavored XP line, matching how Calm Mode
   already treats the Home stat row.
═══════════════════════════════════════════════════════════════ */
const StreakCard = (() => {
  const SIZE = 1080; // square, friendly to most social platforms

  /** Pure data prep, deliberately separated from the actual drawing
   *  below so what goes ON the card can be reasoned about (and tested)
   *  without needing a real canvas. */
  function buildCardData() {
    const streak = ZG.getStreak();
    const total = ZG.getTotalActions();
    const tier = ZG.getTier(total);
    const calm = ZG.getCalmMode();
    const name = window.Profile?.getName?.() || "";
    const motto = window.Profile?.getMotto?.() || "";
    return {
      streak,
      tierName: tier.name,
      xp: calm ? null : ZG.getXP(),
      level: calm ? null : ZG.getLevel(),
      name, motto,
      generatedOn: new Date().toLocaleDateString("en", { month: "long", day: "numeric", year: "numeric" }),
    };
  }

  function _themeColors() {
    const cs = (typeof getComputedStyle === "function") ? getComputedStyle(document.body) : null;
    const get = (name, fallback) => {
      const v = cs?.getPropertyValue?.(name);
      return (v && v.trim()) || fallback;
    };
    return {
      bg: get("--bg", "#15120d"),
      card: get("--card", "#1d1811"),
      text: get("--text", "#f4ecdd"),
      muted: get("--muted", "#ad9d84"),
      accent: get("--accent", "#8fae6b"),
      gold: get("--gold", "#d9a441"),
    };
  }

  function _draw(ctx, data) {
    const c = _themeColors();
    const S = SIZE;

    ctx.fillStyle = c.bg;
    ctx.fillRect(0, 0, S, S);

    const grad = ctx.createRadialGradient(S / 2, S * 0.32, 0, S / 2, S * 0.32, S * 0.6);
    grad.addColorStop(0, c.accent + "33");
    grad.addColorStop(1, "transparent");
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, S, S);

    ctx.textAlign = "center";

    ctx.fillStyle = c.muted;
    ctx.font = "600 28px sans-serif";
    ctx.fillText("NASVOGROW", S / 2, S * 0.14);

    ctx.fillStyle = c.text;
    ctx.font = "700 340px sans-serif";
    ctx.fillText(String(data.streak), S / 2, S * 0.52);

    ctx.fillStyle = c.gold;
    ctx.font = "600 40px sans-serif";
    ctx.fillText(data.streak === 1 ? "DAY STREAK" : "DAY STREAK", S / 2, S * 0.585);

    ctx.fillStyle = c.accent;
    ctx.font = "600 34px serif";
    ctx.fillText(data.tierName, S / 2, S * 0.67);

    if (data.level != null) {
      ctx.fillStyle = c.muted;
      ctx.font = "500 26px sans-serif";
      ctx.fillText(`Level ${data.level} · ${data.xp} XP`, S / 2, S * 0.72);
    }

    if (data.motto) {
      ctx.fillStyle = c.text;
      ctx.font = "italic 32px serif";
      _wrapText(ctx, `"${data.motto}"`, S / 2, S * 0.82, S * 0.78, 40);
    }

    ctx.fillStyle = c.muted;
    ctx.font = "500 22px sans-serif";
    ctx.fillText(data.name ? `${data.name} · ${data.generatedOn}` : data.generatedOn, S / 2, S * 0.93);
  }

  function _wrapText(ctx, text, cx, y, maxWidth, lineHeight) {
    const words = text.split(" ");
    let line = "";
    const lines = [];
    words.forEach(word => {
      const test = line ? line + " " + word : word;
      if (ctx.measureText(test).width > maxWidth && line) { lines.push(line); line = word; }
      else line = test;
    });
    if (line) lines.push(line);
    const startY = y - ((lines.length - 1) * lineHeight) / 2;
    lines.forEach((l, i) => ctx.fillText(l, cx, startY + i * lineHeight));
  }

  /** Renders and triggers a PNG download. Not meaningfully unit-testable
   *  (real canvas 2D rendering needs a real browser) — buildCardData()
   *  above is the part worth testing directly; this is thin glue on top
   *  of it plus the drawing calls. */
  function download() {
    const canvas = document.createElement("canvas");
    canvas.width = SIZE; canvas.height = SIZE;
    const ctx = canvas.getContext("2d");
    if (!ctx) { ZG.toast("Couldn't create the image on this device"); return; }
    _draw(ctx, buildCardData());
    const stamp = new Date().toISOString().slice(0, 10);
    canvas.toBlob(blob => {
      if (!blob) { ZG.toast("Couldn't generate the image"); return; }
      if (window.NativeBridge?.isNative?.()) {          // Android shell: share sheet instead of a download link
        const fr = new FileReader();
        fr.onload = () => NativeBridge.saveFile({ filename: `nasvo-grow-streak-${stamp}.png`, mime: "image/png", base64: String(fr.result).split(",")[1], title: "My NASVOGrow streak" })
          .then((r) => { if (r.ok) ZG.toast("Streak card ready to share"); else if (r.reason !== "cancelled") ZG.toast("Couldn't share the image"); });
        fr.readAsDataURL(blob);
        return;
      }
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = `nasvo-grow-streak-${stamp}.png`;
      a.click();
      ZG.toast("Streak card saved");
    }, "image/png");
  }

  return { buildCardData, download };
})();
window.StreakCard = StreakCard;
