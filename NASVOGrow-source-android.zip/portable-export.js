"use strict";
/* ═══════════════════════════════════════════════════════════════
   PORTABLE EXPORT — a stable, versioned, documented JSON schema for
   backing up and restoring NASVOGrow data, decoupled from raw
   localStorage key names. See portable-schema.md for the full field
   reference.

   Why this exists alongside the existing "Full backup (.json)"
   export: that format is a byte-for-byte localStorage dump — every
   internal zg_* key, verbatim. It works today, but it's
   implementation-coupled: renaming an internal key, or reshaping how
   one module stores its data, silently breaks every backup anyone
   ever took. Given this app's entire pitch is "your data, portable,
   forever" (see privacy.html), that coupling is a real risk, not a
   theoretical one.

   This is additive, not a replacement — the raw dump stays as an
   export option (see export.js's "Full backup (.json)"; nothing about
   it changes here) so nothing existing breaks. This is a second,
   forward-compatible option a person can start relying on instead.

   Single source of truth: FIELD_MAP below is the ONLY place that
   knows both a field's portable-schema name and its current internal
   zg_* key. Renaming an internal key in the future means updating one
   line here — every old exported file keeps importing correctly,
   since old files still carry the OLD schema field names, and this
   file's job is exactly translating those against whatever the
   current internal shape is.

   Deliberately excluded from the schema (device-local bookkeeping,
   not data worth restoring onto a different device):
     zg_schema_version   — this device's OWN migration state; importing
                           a foreign value here could make the migration
                           runner skip steps this device still needs
     zg_last_section, zg_last_export_ts, zg_last_notify_date,
     zg_last_risk_notify_date, zg_last_digest_week, zg_daily_line_*,
     zg_hero_cache
                         — one-shot/daily UI bookkeeping, regenerates
                           on its own
     zg_ai_key, zg_ai_insight_cache
                         — deprecated; migrations.js already removes
                           these outright
═══════════════════════════════════════════════════════════════ */
const PortableExport = (() => {
  const SCHEMA_ID = "nasvogrow.portable";
  const SCHEMA_VERSION = 1;

  /** [namespace, field, rawKey, opts?]. opts.json=true means the raw
   *  localStorage value is JSON (written via Store.set) and should be
   *  parsed/stringified going in and out of the portable file; omitted
   *  means the raw value is a plain string (written via
   *  localStorage.setItem directly) and passes through as-is. This flag
   *  was verified against every actual write call in the codebase, not
   *  assumed — getting it wrong in either direction would silently
   *  corrupt that field on import. */
  const FIELD_MAP = [
    ["profile", "name", "zg_name", { json: true }],
    ["profile", "username", "zg_username", { json: true }],
    ["profile", "motto", "zg_motto", { json: true }],
    ["profile", "bio", "zg_bio", { json: true }],
    ["profile", "avatarDataUrl", "zg_avatar", { json: true }],
    ["profile", "joinedDate", "zg_joined_date", { json: true }],

    ["settings", "theme", "zg_theme"],
    ["settings", "language", "zg_lang", { json: true }],
    ["settings", "canvasTheme", "zg_canvas_theme"],
    ["settings", "weeklyGoal", "zg_weekly_goal", { json: true }],
    ["settings", "privacyVeil", "zg_privacy_veil", { json: true }],
    ["settings", "calmMode", "zg_calm_mode", { json: true }],
    ["settings", "notificationsEnabled", "zg_notify_enabled", { json: true }],
    ["settings", "riskNotifyEnabled", "zg_risk_notify_enabled", { json: true }],
    ["settings", "mindfulCheckins", "zg_focus_mindful_checkins", { json: true }],
    ["settings", "mindfulPause", "zg_focus_mindful_relapse_pause", { json: true }],
    ["settings", "crisisCountry", "zg_country", { json: true }],
    ["settings", "onboarded", "zg_onboarded"],
    ["settings", "security", "zg_security", { json: true }],
    ["settings", "trustedContacts", "zg_trusted_contacts", { json: true }],

    ["progress", "xp", "zg_xp", { json: true }],
    ["progress", "totalActions", "zg_total_actions", { json: true }],
    ["progress", "streak", "zg_streak", { json: true }],
    ["progress", "longestStreak", "zg_longest_streak", { json: true }],
    ["progress", "lastActiveDate", "zg_last_active_date"],
    ["progress", "activeDates", "zg_active_dates", { json: true }],
    ["progress", "unlockedSkills", "zg_unlocked_skills", { json: true }],
    ["progress", "achievements", "zg_achievements", { json: true }],

    ["habits", "data", "zg_habits", { json: true }],
    ["habits", "completionHours", "zg_habit_completion_hours", { json: true }],

    ["journal", "entries", "zg_journal", { json: true }],
    ["journal", "reflections", "zg_reflections", { json: true }],

    ["recovery", "data", "zg_recovery", { json: true }],

    ["challenges", "data", "zg_challenges", { json: true }],

    ["vitals", "entries", "zg_vitals", { json: true }],

    ["context", "data", "zg_context", { json: true }],
  ];

  function _readRaw(key) {
    try { return localStorage.getItem(key); } catch { return null; }
  }

  function _get(entry) {
    const [, , rawKey, opts] = entry;
    const raw = _readRaw(rawKey);
    if (raw == null) return undefined;
    if (opts?.json) { try { return JSON.parse(raw); } catch { return undefined; } }
    return raw;
  }

  /** Builds the portable, human-inspectable export object — real nested
   *  JSON values, not a bag of double-encoded strings, so someone (or
   *  some other tool) can actually read the file. */
  function build() {
    const out = { schema: SCHEMA_ID, schemaVersion: SCHEMA_VERSION, exportedAt: new Date().toISOString() };
    FIELD_MAP.forEach(entry => {
      const [ns, field] = entry;
      const value = _get(entry);
      if (value === undefined) return;
      if (!out[ns]) out[ns] = {};
      out[ns][field] = value;
    });
    return out;
  }

  /** Converts a portable object back into the raw {zg_key: rawStringValue}
   *  shape every internal consumer (Store, Sync) already expects — the
   *  exact inverse of build()'s per-field json handling. */
  function _toRawMap(portable) {
    const raw = {};
    FIELD_MAP.forEach(entry => {
      const [ns, field, rawKey, opts] = entry;
      if (!portable[ns] || !(field in portable[ns])) return;
      const value = portable[ns][field];
      raw[rawKey] = opts?.json ? JSON.stringify(value) : String(value);
    });
    return raw;
  }

  function validate(portable) {
    const errors = [];
    if (!portable || typeof portable !== "object") return ["not a valid export object"];
    if (portable.schema !== SCHEMA_ID) errors.push(`unrecognized schema id "${portable.schema}" — this doesn't look like a NASVOGrow portable export`);
    if (typeof portable.schemaVersion !== "number") errors.push("missing schemaVersion");
    else if (portable.schemaVersion > SCHEMA_VERSION) errors.push(`exported by a newer app version (schema v${portable.schemaVersion}) than this one understands (v${SCHEMA_VERSION}) — update the app first`);
    return errors;
  }

  /** mode "replace" (default): wipes every zg_* key this device has
   *  (except zg_schema_version, which is this device's own migration
   *  state, never a foreign one) and writes the imported fields fresh —
   *  same behavior as the existing full-JSON-backup import.
   *  mode "merge": routes the same raw {zg_key: value} map through
   *  Sync's existing per-domain merge rules (see sync.js) instead of
   *  overwriting — additive across two devices' histories rather than
   *  one replacing the other. */
  function apply(portable, { mode = "replace" } = {}) {
    const errors = validate(portable);
    if (errors.length) throw new Error(errors.join("; "));

    const rawMap = _toRawMap(portable);

    if (mode === "merge") {
      if (!window.Sync?.merge) throw new Error("merge mode requires sync.js to be loaded");
      return { mode: "merge", ...window.Sync.merge(rawMap) };
    }

    Object.keys(localStorage).filter(k => k.startsWith("zg_") && k !== "zg_schema_version").forEach(k => localStorage.removeItem(k));
    Object.entries(rawMap).forEach(([k, v]) => localStorage.setItem(k, v));
    return { mode: "replace", fieldsWritten: Object.keys(rawMap).length };
  }

  return { SCHEMA_ID, SCHEMA_VERSION, FIELD_MAP, build, apply, validate };
})();
window.PortableExport = PortableExport;
