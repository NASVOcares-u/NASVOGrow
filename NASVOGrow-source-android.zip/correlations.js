"use strict";
/* ═══════════════════════════════════════════════════════════════
   CORRELATIONS — the plugin registry for Insights' "What the data
   says" rows. This is the plugin interface flagged as still-open
   after Phase 0 (see insights.js's own header) — built now because
   Phase 2's new correlation types need it, so this delivers both in
   one pass instead of asking Phase 2 to assume infrastructure that
   didn't exist yet.

   Each plugin is { id, compute(r), row(result) }:
     • compute(r) receives the same context object insights.js's own
       compute() already builds (events, habitCorr, journalCorr, …).
       A plugin can also read window.Habits/Journal/Recovery/Vitals/
       Context directly for anything not already in r — exactly the
       same pattern insights.js's own private correlation functions
       already use internally, so this isn't a new access rule, just
       a new place for it to live. Returns null the moment there
       isn't enough data to say something honestly; never guesses.
     • row(result) turns a non-null result into the {type, text}
       shape already rendered as an .ins-row-* line — type is one of
       positive / caution / pattern / neutral, matching the existing
       color coding.
   insights.js still does all the raw data-gathering (habit logs,
   recovery events, journal entries, radar/DNA/heatmap) — this file
   only computes FROM that shared context and decides how to phrase
   what it finds. New correlations belong here, not bolted onto
   insights.js itself, so that file doesn't grow without bound every
   time a new pattern gets added — the exact problem this exists to
   solve.
═══════════════════════════════════════════════════════════════ */
const CorrelationPlugins = (() => {
  const registry = [];

  function register(plugin) {
    if (!plugin?.id || typeof plugin.compute !== "function" || typeof plugin.row !== "function") {
      console.error("[CorrelationPlugins] invalid plugin skipped", plugin?.id);
      return;
    }
    if (registry.some(p => p.id === plugin.id)) {
      console.error(`[CorrelationPlugins] duplicate id "${plugin.id}" skipped`);
      return;
    }
    registry.push(plugin);
  }

  /** Runs every registered plugin against the shared context, in
   *  registration order, returning display rows only for the ones
   *  that had enough data to say something. One plugin throwing
   *  can't take the rest down with it — same fault-isolation spirit
   *  as the Migrations runner. */
  function evaluate(r) {
    const rows = [];
    for (const plugin of registry) {
      try {
        const result = plugin.compute(r);
        if (result) rows.push(plugin.row(result));
      } catch (err) {
        console.error(`[CorrelationPlugins] "${plugin.id}" failed`, err);
      }
    }
    return rows;
  }

  function list() { return registry.map(p => p.id); }

  return { register, evaluate, list };
})();
window.CorrelationPlugins = CorrelationPlugins;

const _MOOD_LABELS = { good: "Good", okay: "Okay", heavy: "Heavy", rough: "Rough" };
const _HALT_LABELS = { H: "Hungry", A: "Angry", L: "Lonely", T: "Tired", O: "Other" };

/* ═══════════════════════ ported from insights.js's old _insightRows
   if-chain — same thresholds, same copy, now independently
   registered instead of one growing function. ═══════════════════ */

CorrelationPlugins.register({
  id: "habit_completion_vs_resist",
  compute(r) {
    if (!(r.habitCorr.resistDays >= 2 && r.habitCorr.relapseDays >= 1 && r.habitCorr.resistAvg != null && r.habitCorr.relapseAvg != null)) return null;
    const diff = r.habitCorr.resistAvg - r.habitCorr.relapseAvg;
    if (Math.abs(diff) < 8) return null;
    return { diff, resistAvg: r.habitCorr.resistAvg, relapseAvg: r.habitCorr.relapseAvg, totalDays: r.habitCorr.resistDays + r.habitCorr.relapseDays };
  },
  row(res) {
    const lowConfidence = res.totalDays < 6;
    return {
      type: res.diff > 0 ? "positive" : "neutral",
      text: `On days you rode out an urge, habit completion averaged ${res.resistAvg}% — on days that ended in a reset, it averaged ${res.relapseAvg}%.${lowConfidence ? ` (Based on ${res.totalDays} logged days so far — take it loosely until there's more history.)` : ""}`,
    };
  },
});

CorrelationPlugins.register({
  id: "journal_on_reset_days",
  compute(r) {
    if (!(r.journalCorr && r.journalCorr.relapseDays >= 2)) return null;
    return r.journalCorr;
  },
  row(res) {
    return { type: "pattern", text: `${res.relapsePct}% of reset days had a journal entry, versus ${res.basePct}% of days overall — worth noticing either way.` };
  },
});

CorrelationPlugins.register({
  id: "mood_vs_habits_same_day",
  compute(r) {
    if (!(r.moodHabitCorr && (r.moodHabitCorr.best.avg - r.moodHabitCorr.worst.avg) >= 10)) return null;
    return r.moodHabitCorr;
  },
  row(m) {
    return { type: "pattern", text: `Journal entries tagged "${_MOOD_LABELS[m.best.mood]}" line up with ${m.best.avg}% habit completion that day, versus ${m.worst.avg}% on "${_MOOD_LABELS[m.worst.mood]}" days. (${m.best.n} and ${m.worst.n} tagged days respectively.)` };
  },
});

CorrelationPlugins.register({
  id: "mood_vs_recovery",
  compute(r) {
    if (!(r.moodRecoveryCorr && (r.moodRecoveryCorr.best.resistRate - r.moodRecoveryCorr.worst.resistRate) >= 0.15)) return null;
    return r.moodRecoveryCorr;
  },
  row(m) {
    return { type: "pattern", text: `Urges on days you tagged "${_MOOD_LABELS[m.best.mood]}" were resisted ${Math.round(m.best.resistRate * 100)}% of the time — on "${_MOOD_LABELS[m.worst.mood]}" days, ${Math.round(m.worst.resistRate * 100)}%.` };
  },
});

CorrelationPlugins.register({
  id: "sleep_vs_habits",
  compute(r) {
    if (!(r.sleepHabitCorr && Math.abs(r.sleepHabitCorr.restedAvg - r.sleepHabitCorr.shortAvg) >= 8)) return null;
    return r.sleepHabitCorr;
  },
  row(s) {
    return { type: "pattern", text: `On nights you logged 7+ hours of sleep, habit completion averaged ${s.restedAvg}% the next day — after shorter nights, ${s.shortAvg}%. (${s.restedN} and ${s.shortN} logged days.)` };
  },
});

CorrelationPlugins.register({
  id: "sleep_vs_recovery",
  compute(r) {
    if (!(r.sleepRecoveryCorr && Math.abs(r.sleepRecoveryCorr.restedResist - r.sleepRecoveryCorr.shortResist) >= 15)) return null;
    return r.sleepRecoveryCorr;
  },
  row(s) {
    return { type: "pattern", text: `Urges after 7+ hours of sleep were resisted ${s.restedResist}% of the time — after shorter nights, ${s.shortResist}%.` };
  },
});

CorrelationPlugins.register({
  id: "weather_vs_recovery",
  compute(r) {
    if (!(r.weatherRecoveryCorr && (r.weatherRecoveryCorr.best.resistRate - r.weatherRecoveryCorr.worst.resistRate) >= 0.15)) return null;
    return r.weatherRecoveryCorr;
  },
  row(w) {
    const label = tag => window.Context?.WEATHER?.[tag] || tag;
    return { type: "pattern", text: `Logged moments on "${label(w.best.weather)}" days were resisted ${Math.round(w.best.resistRate * 100)}% of the time — on "${label(w.worst.weather)}" days, ${Math.round(w.worst.resistRate * 100)}%.` };
  },
});

CorrelationPlugins.register({
  id: "top_halt_trigger",
  compute(r) {
    if (!(r.halt && r.halt.count >= 2)) return null;
    return r.halt;
  },
  row(halt) {
    return { type: "pattern", text: `"${_HALT_LABELS[halt.tag] || halt.tag}" is the most-logged trigger so far — ${halt.count} time${halt.count === 1 ? "" : "s"}.` };
  },
});

CorrelationPlugins.register({
  id: "intensity_compare",
  compute(r) {
    if (!(r.intensity.resistedAvg != null && r.intensity.relapsedAvg != null)) return null;
    return r.intensity;
  },
  row(i) {
    return { type: "neutral", text: `Average craving intensity: ${i.resistedAvg}/10 on urges you rode out, ${i.relapsedAvg}/10 on the ones that became a reset.` };
  },
});

CorrelationPlugins.register({
  id: "satisfaction_compare",
  compute(r) {
    if (!r.satisfaction) return null;
    const s = r.satisfaction;
    if (s.resistedAvg == null) return null;
    return s;
  },
  row(s) {
    return s.relapsedAvg != null
      ? { type: "positive", text: `Self-rated satisfaction after riding it out: ${s.resistedAvg}/10, versus ${s.relapsedAvg}/10 on the ones that became a reset — your own numbers, not a guess.` }
      : { type: "positive", text: `Riding it out has averaged ${s.resistedAvg}/10 on your own satisfaction rating so far.` };
  },
});

CorrelationPlugins.register({
  id: "hardest_day_of_week",
  compute(r) {
    const worstDay = r.dayOfWeek.filter(d => d.total >= 2).sort((a, b) => (a.resistRate ?? 1) - (b.resistRate ?? 1))[0];
    if (!(worstDay && worstDay.resistRate != null && worstDay.resistRate < 0.6)) return null;
    return worstDay;
  },
  row(w) {
    return { type: "caution", text: `${w.day} has been the hardest day so far — ${w.relapse} reset${w.relapse === 1 ? "" : "s"} out of ${w.total} logged moments.` };
  },
});

/* ═══════════════════════ new for Phase 2 ═══════════════════════ */

/** Day-of-week × habit-category cross-tab. Surfaces at most ONE row —
 *  the category with the single most pronounced weekday swing — rather
 *  than a row per category, matching the existing restraint on how many
 *  lines "What the data says" shows at once. Uses zg_active_dates (the
 *  same day-level activity log _consistencyScore already reads) as the
 *  denominator, since habit-completion logs alone don't carry enough
 *  history-of-habit-existence to cleanly attribute every prior day to
 *  a category — an honest approximation, not a claim of precision. */
CorrelationPlugins.register({
  id: "category_day_of_week",
  compute() {
    const h = window.Habits?.load?.();
    if (!h || !h.habits.length) return null;
    const activeDates = Store.get("zg_active_dates", []);
    if (activeDates.length < 14) return null; // need a couple of real weeks before slicing by weekday

    const byCat = {};
    h.habits.forEach(habit => {
      const cat = window.Habits.CATEGORIES?.[habit.category] ? habit.category : "general";
      (byCat[cat] || (byCat[cat] = [])).push(habit.id);
    });

    const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    let best = null;
    Object.entries(byCat).forEach(([cat, ids]) => {
      const activeByDow = Array(7).fill(0);
      const hitByDow = Array(7).fill(0);
      activeDates.forEach(dateStr => {
        const dow = new Date(dateStr).getDay();
        activeByDow[dow]++;
        const doneIds = h.log[dateStr] || [];
        if (ids.some(id => doneIds.includes(id))) hitByDow[dow]++;
      });
      const rates = activeByDow.map((n, i) => (n >= 3 ? { i, r: hitByDow[i] / n } : null)).filter(Boolean);
      if (rates.length < 2) return;
      rates.sort((a, b) => b.r - a.r);
      const top = rates[0], bottom = rates[rates.length - 1];
      const spread = top.r - bottom.r;
      if (spread < 0.3) return; // must clearly stand out, same bar used everywhere else in Insights
      if (!best || spread > best.spread) {
        best = { cat, bestDay: DAYS[top.i], worstDay: DAYS[bottom.i], bestRate: top.r, worstRate: bottom.r, spread };
      }
    });
    return best;
  },
  row(res) {
    const label = window.Habits?.categoryLabel?.(res.cat) || res.cat;
    return { type: "pattern", text: `${label} habits get done ${Math.round(res.bestRate * 100)}% of the ${res.bestDay}s you're active, but only ${Math.round(res.worstRate * 100)}% of the ${res.worstDay}s.` };
  },
});

/** Coping-plan "before vs. after" effectiveness. Grow doesn't record
 *  WHICH plan (if any) a person actually leaned on during a specific
 *  urge — only that plans exist and when they were written — so this
 *  compares outcomes before vs. after a tracker's FIRST coping plan was
 *  written, as an honest proxy rather than a literal per-use claim.
 *  Deliberately one-directional: it only ever reports an IMPROVEMENT,
 *  never "your plan didn't help" — recovery is multi-causal, and a
 *  correlation implying a written plan failed someone reads as blame
 *  for something with far more going on than one factor, matching this
 *  app's non-judgmental framing everywhere else (see recovery.js's own
 *  "recovery isn't linear" / "starting over takes courage" copy). */
CorrelationPlugins.register({
  id: "coping_plan_effectiveness",
  compute() {
    const rec = window.Recovery?.load?.() || { trackers: {} };
    let best = null;
    Object.entries(rec.trackers).forEach(([id, t]) => {
      const plans = t.copingPlans || [];
      if (!plans.length) return;
      const firstPlanTs = Math.min(...plans.map(p => p.updatedAt).filter(ts => typeof ts === "number"));
      if (!isFinite(firstPlanTs)) return;

      const events = [...(t.urges || []).map(u => ({ ts: u.ts, isUrge: true })), ...(t.relapses || []).map(x => ({ ts: x.ts, isUrge: false }))];
      const before = events.filter(e => e.ts < firstPlanTs);
      const after = events.filter(e => e.ts >= firstPlanTs);
      if (before.length < 3 || after.length < 3) return; // need a real sample on both sides of the line

      const resistRate = arr => arr.filter(e => e.isUrge).length / arr.length;
      const beforeRate = resistRate(before), afterRate = resistRate(after);
      const diff = afterRate - beforeRate;
      if (diff < 0.15) return; // improvement-only, and must clearly stand out

      if (!best || diff > best.diff) {
        best = { id, label: window.Recovery?.TYPES?.[id]?.label || id, beforeRate, afterRate, diff, sample: before.length + after.length };
      }
    });
    return best;
  },
  row(res) {
    return {
      type: "positive",
      text: `Since your first coping plan for ${res.label}, urges have been resisted ${Math.round(res.afterRate * 100)}% of the time — ${Math.round(res.beforeRate * 100)}% before that. (${res.sample} logged moments split across both periods — a plan is one factor among several, not the only one.)`,
    };
  },
});

/** Mood tagged on day N vs. habit completion on day N+1 — a genuinely
 *  different angle from the existing same-day mood/habit correlation
 *  above: does yesterday's mood carry forward into today's follow-
 *  through, not just correlate with itself. */
CorrelationPlugins.register({
  id: "mood_next_day_habits",
  compute() {
    const entries = window.Journal?.load?.() || [];
    const h = window.Habits?.load?.();
    if (!entries.length || !h || !h.habits.length) return null;

    const byMood = {};
    entries.forEach(e => {
      if (!e.mood) return;
      const next = new Date(e.date);
      next.setDate(next.getDate() + 1);
      const doneNext = (h.log[next.toDateString()] || []).length;
      (byMood[e.mood] || (byMood[e.mood] = [])).push(doneNext / h.habits.length);
    });

    const avg = arr => Math.round((arr.reduce((s, v) => s + v, 0) / arr.length) * 100);
    const summary = Object.entries(byMood).filter(([, arr]) => arr.length >= 3).map(([mood, arr]) => ({ mood, avg: avg(arr), n: arr.length }));
    if (summary.length < 2) return null;
    summary.sort((a, b) => b.avg - a.avg);
    const best = summary[0], worst = summary[summary.length - 1];
    if (best.avg - worst.avg < 12) return null;
    return { best, worst };
  },
  row(res) {
    return {
      type: "pattern",
      text: `The day after a "${_MOOD_LABELS[res.best.mood] || res.best.mood}"-tagged entry, habit completion averaged ${res.best.avg}% — after a "${_MOOD_LABELS[res.worst.mood] || res.worst.mood}" entry, ${res.worst.avg}%. (${res.best.n} and ${res.worst.n} tagged days.)`,
    };
  },
});

/** Weekly check-in (Vitals) energy rating vs. that same week's habit
 *  completion. Vitals already renders its own trend chart in Insights;
 *  this is the first thing that actually LINKS it to another signal
 *  instead of leaving it a standalone number. */
CorrelationPlugins.register({
  id: "vitals_energy_vs_habits",
  compute() {
    const vitals = window.Vitals?.load?.() || [];
    const h = window.Habits?.load?.();
    if (vitals.length < 4 || !h || !h.habits.length) return null;

    function weekCompletionRatio(weekKeyDateStr) {
      const start = new Date(weekKeyDateStr);
      let done = 0;
      for (let i = 0; i < 7; i++) {
        const d = new Date(start); d.setDate(d.getDate() + i);
        done += (h.log[d.toDateString()] || []).length;
      }
      const possible = h.habits.length * 7;
      return possible ? done / possible : null;
    }

    const points = vitals.map(v => ({ energy: v.energy, ratio: weekCompletionRatio(v.weekKey) })).filter(p => p.ratio != null);
    const high = points.filter(p => p.energy >= 7).map(p => p.ratio);
    const low = points.filter(p => p.energy <= 4).map(p => p.ratio);
    if (high.length < 2 || low.length < 2) return null;

    const avg = arr => Math.round((arr.reduce((s, v) => s + v, 0) / arr.length) * 100);
    const highAvg = avg(high), lowAvg = avg(low);
    if (Math.abs(highAvg - lowAvg) < 10) return null;
    return { highAvg, lowAvg, highN: high.length, lowN: low.length };
  },
  row(res) {
    return { type: "pattern", text: `In weeks you rated your energy 7+/10, habit completion averaged ${res.highAvg}% — in weeks you rated it 4 or under, ${res.lowAvg}%. (${res.highN} and ${res.lowN} check-ins.)` };
  },
});
