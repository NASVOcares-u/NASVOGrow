"use strict";
/* ═══════════════════════════════════════════════════════════════
   MIGRATIONS — a tiny, ordered schema-version runner for localStorage.

   Why this exists: NASVOGrow has no server and no backend to backfill
   a bad shape after the fact (see netlify.toml, privacy.html) — every
   future change to what a zg_* key looks like needs its own one-time,
   idempotent upgrade step that runs locally, before any other module
   reads that key. Before this file, that kind of upgrade logic was
   scattered ad hoc across modules (profile.js's joinedDate() back-fill,
   habits.js's toggle() guarding for a possibly-missing `awarded` field,
   sync.js's SKIP_KEYS list quietly excluding a retired feature's keys
   from sync forever instead of ever cleaning them up) — fine for small
   defensive one-offs, but not a place to hang anything more structural
   (renaming a key, splitting one key into two, deleting a retired one
   outright). This file is that single registration point instead.

   Contract every step must honor:
     • Idempotent. Running a step twice must be a no-op the second
       time — "did we already run this" is itself state that could be
       lost (localStorage cleared by hand, a half-written previous run).
     • Ordered and additive. Add new steps to the END of STEPS with the
       next integer version; never renumber or rewrite an old one.
     • Individually fault-isolated. One step throwing must not corrupt
       the version marker or block the app — it stops the run right
       there, logs it, and leaves the marker at the last step that
       actually finished, so the same step is retried next load instead
       of being silently skipped or crashing the page.
     • Fast in the common case. A fully up-to-date install (by far the
       most common load) costs exactly one localStorage read.

   A brand-new install (no zg_ keys of any kind yet) is stamped straight
   to CURRENT_VERSION without walking through history — there is nothing
   on a fresh install for an old migration to fix, and running one
   anyway could do the wrong thing to data that was never in the old
   shape to begin with.

   Load order: this script must run before every other zg_* module so
   nothing downstream ever reads a pre-migration shape (see index.html —
   this tag sits first, and every module here still only reads its own
   keys lazily inside functions, never at top-level IIFE-eval time, so
   "first script tag" is early enough with no further wiring needed).
═══════════════════════════════════════════════════════════════ */
const Migrations = (() => {
  const VERSION_KEY = "zg_schema_version";

  /** Ordered by version. Each step's `migrate()` runs with real
   *  localStorage access and must be safe to run more than once. Keep
   *  each step small and single-purpose — one structural change per
   *  version, not a grab-bag, so a failure is easy to isolate and the
   *  history stays legible. */
  const STEPS = [
    {
      version: 1,
      label: "Remove deprecated AI-insight keys",
      migrate() {
        // zg_ai_key / zg_ai_insight_cache backed the BYO-key Anthropic call
        // that used to live in insights.js, replaced by the fully local
        // weekly read (see netlify.toml's CSP note on connect-src, and
        // sync.js's SKIP_KEYS, which already excludes these from sync but
        // never actually cleaned up anyone who still has them sitting in
        // localStorage from before). Idempotent: removeItem on an absent
        // key is already a no-op.
        ["zg_ai_key", "zg_ai_insight_cache"].forEach(k => localStorage.removeItem(k));
      },
    },
    // Next migration goes here, e.g.:
    // { version: 2, label: "…", migrate() { /* idempotent upgrade */ } },
  ];

  const CURRENT_VERSION = STEPS.length ? STEPS[STEPS.length - 1].version : 0;

  function _hasAnyData() {
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith("zg_") && k !== VERSION_KEY) return true;
    }
    return false;
  }

  function currentVersion() {
    const raw = localStorage.getItem(VERSION_KEY);
    return raw != null ? (parseInt(raw, 10) || 0) : 0;
  }

  function _setVersion(v) { localStorage.setItem(VERSION_KEY, String(v)); }

  /** Runs every not-yet-applied step in order, advancing the stored
   *  version one step at a time so a mid-run crash (full disk, tab
   *  closed mid-write) leaves the marker at the last step that actually
   *  finished rather than skipping ahead or silently repeating work. */
  function run() {
    let stored;
    try { stored = localStorage.getItem(VERSION_KEY); }
    catch { return; } // storage unavailable (private browsing, quota) — nothing safe to do here

    if (stored == null && !_hasAnyData()) {
      _setVersion(CURRENT_VERSION); // fresh install — nothing to upgrade
      return;
    }

    let version = currentVersion();
    for (const step of STEPS) {
      if (step.version <= version) continue;
      try {
        step.migrate();
        version = step.version;
        _setVersion(version);
      } catch (err) {
        console.error(`[Migrations] step ${step.version} ("${step.label}") failed — stopping here, will retry next load.`, err);
        break;
      }
    }
  }

  return { run, currentVersion, CURRENT_VERSION, STEPS, VERSION_KEY };
})();
window.Migrations = Migrations;

Migrations.run();
