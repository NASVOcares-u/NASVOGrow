"use strict";
/* ═══════════════════════════════════════════════════════════════
   HABITS — small repeated choices, tracked with per-habit streaks.
   No per-habit emoji — a quiet colored dot plus clean type does more
   for scannability than a shelf of little pictures.

   HABIT STACKING — "after I [anchor], I will [this]" is one of the
   better-evidenced ways to make a new habit stick, so a habit can
   optionally point at another as its anchor (set from the edit modal).
   On top of that, the list quietly watches for pairs you're ALREADY
   doing together most days and offers to link them — never forced,
   one dismissible suggestion at a time, never re-shown once dismissed.

   STREAK FREEZES — earned, not bought: every 7-day run on a habit
   banks one freeze (cap 2), which can retroactively cover a single
   missed yesterday so one off day doesn't erase a real streak. A
   frozen day is NOT written into the completion log — Insights and
   the weekly-target count still see the honest, un-covered history;
   only the STREAK NUMBER treats that day as continuing.
═══════════════════════════════════════════════════════════════ */
const Habits = (() => {
  const KEY = "zg_habits";
  const DOT_COLORS = ["var(--accent)", "var(--gold)", "var(--clay)", "var(--accent-strong)"];

  /* ── categories — grouping, not tagging: every habit belongs to exactly
     one, so the list reads as a few short sections instead of one long
     scroll. Reuses icons/colors already meaningful elsewhere in the app
     rather than inventing a new visual language just for this. Habits
     created before this existed simply have no `category` field — _catOf()
     below is the single place that resolves that to "general", so nothing
     else in this file needs to know the field might be missing. */
  const CATEGORIES = {
    health:       { id: "health",       label: "Health",       icon: "growth", colorVar: "--accent" },
    mind:         { id: "mind",         label: "Mind",         icon: "book",   colorVar: "--gold" },
    productivity: { id: "productivity", label: "Productivity", icon: "check",  colorVar: "--clay" },
    social:       { id: "social",       label: "Social",       icon: "signal", colorVar: "--accent-strong" },
    boost:        { id: "boost",        label: "Dopamine boosts", icon: "sunrise", colorVar: "--gold" },
    general:      { id: "general",      label: "General",      icon: "star",  colorVar: "--muted-dim" },
  };

  /* ── Dopamine-positive activity suggestions — the "add" side of a reset,
     not just the "resist" side Recovery covers. Deliberately a small,
     varied, low-effort set (light exposure, movement, cold exposure,
     real social contact, a flow-state task, something creative, a bit
     of mastery) rather than an exhaustive list — the point is a fast,
     one-tap way to put something real in the gap a compulsive habit
     used to fill, not a curated wellness program. Each becomes a normal
     habit once added (same streaks/freezes/stacking as anything else) —
     this is a starting-point suggestion, not a separate system. */
  const BOOST_SUGGESTIONS = [
    "Get sunlight outside",
    "Move your body for 10 minutes",
    "Take a cold shower",
    "Call or see someone in person",
    "20 minutes of focused work, phone in another room",
    "Make or listen to music, fully present",
    "Cook a real meal from scratch",
  ];
  function _catOf(h) { return CATEGORIES[h?.category] ? h.category : "general"; }

  const DEFAULTS = () => ({
    habits: [
      { id: "h_water", name: "Drink water first thing", weeklyTarget: 7, category: "health" },
      { id: "h_move",  name: "Move your body", weeklyTarget: 7, category: "health" },
      { id: "h_read",  name: "Read a few pages", weeklyTarget: 7, category: "mind" },
    ],
    log: {}, // dateString -> [habitId, ...]
    awarded: {}, // dateString -> [habitId,...] — habits already credited with XP/challenge progress today, so unchecking and rechecking can't farm repeat rewards for one real action
  });

  function load() { return Store.get(KEY, DEFAULTS()); }
  function save(d) { Store.set(KEY, d); }
  function today() { return new Date().toDateString(); }

  function _dotColor(id) {
    let hash = 0;
    for (const ch of id) hash = (hash * 31 + ch.charCodeAt(0)) >>> 0;
    return DOT_COLORS[hash % DOT_COLORS.length];
  }

  /* ── adaptive reminder timing — a lightweight, additive-only signal ──
     `d.log[date]` only ever recorded WHICH habits were done on WHICH day,
     never what time — restructuring that shape to carry timestamps would
     ripple through insights.js, export.js, and sync.js's merge rules for
     a single reminder feature, which is a bigger and riskier change than
     this earns on its own. Instead: a small separate rolling log of just
     the hour-of-day a genuine (XP-granting) completion happened, capped
     so it can't grow unbounded, feeding one honest question — "by what
     hour does this person usually finish?" — used to time the evening
     habit reminder (see app.js) instead of one fixed hour for everyone.
     Same honesty rule as Insights' risk window: says nothing until there's
     a real sample. */
  const COMPLETION_HOURS_KEY = "zg_habit_completion_hours";
  const COMPLETION_HOURS_CAP = 200;
  const COMPLETION_HOURS_MIN_SAMPLE = 10;

  function _recordCompletionHour() {
    const hours = Store.get(COMPLETION_HOURS_KEY, []);
    hours.push(new Date().getHours());
    Store.set(COMPLETION_HOURS_KEY, hours.slice(-COMPLETION_HOURS_CAP));
  }

  /** The hour by which this person has typically finished a habit for the
   *  day, going by their own history. Median rather than mean on purpose —
   *  one very-late catch-up session shouldn't drag the typical hour later
   *  than where most days actually land. Returns null under the minimum
   *  sample size rather than guess from too little data. */
  function typicalCompletionHour() {
    const hours = Store.get(COMPLETION_HOURS_KEY, []);
    if (hours.length < COMPLETION_HOURS_MIN_SAMPLE) return null;
    const sorted = [...hours].sort((a, b) => a - b);
    return sorted[Math.floor(sorted.length / 2)];
  }

  function toggle(id) {
    const d = load();
    const t = today();
    if (!d.log[t]) d.log[t] = [];
    if (!d.awarded) d.awarded = {};
    if (!d.awarded[t]) d.awarded[t] = [];
    const idx = d.log[t].indexOf(id);
    const wasOff = idx < 0;
    if (idx >= 0) d.log[t].splice(idx, 1);
    else d.log[t].push(id);
    if (wasOff) { ZG._justDone = id; clearTimeout(ZG._justDoneT); ZG._justDoneT = setTimeout(() => { ZG._justDone = null; }, 900); }

    // Only the first completion of a habit on a given day earns XP/challenge
    // credit — unchecking and rechecking the same box can't farm rewards.
    const alreadyAwarded = d.awarded[t].includes(id);
    const grantReward = wasOff && !alreadyAwarded;
    if (grantReward) d.awarded[t].push(id);

    // "Every habit checked off today" is its own one-time-per-day signal,
    // separate from the per-habit reward above — used only to advance a
    // challenge like Perfect Days. "__all__" is a sentinel, never a real
    // habit id, so it can't collide with anything in d.awarded[t].
    const dayComplete = d.habits.length > 0 && d.log[t].length === d.habits.length;
    const notifyAllDone = dayComplete && !d.awarded[t].includes("__all__");
    if (notifyAllDone) d.awarded[t].push("__all__");

    const days = Object.keys(d.awarded).sort();
    if (days.length > 60) days.slice(0, days.length - 60).forEach(k => delete d.awarded[k]);

    save(d);
    if (wasOff) ZG.celebrateCheck?.(notifyAllDone);

    const h = d.habits.find(x => x.id === id);
    if (grantReward) {
      const bonus = ZG.habitXpBonus();
      // Undo here just re-invokes toggle() — identical to tapping the
      // checkbox again by hand, so it needs no special-case bookkeeping:
      // the existing `alreadyAwarded` guard already prevents a second XP
      // grant on the way back down, exactly as if the person had simply
      // unchecked it themselves.
      ZG.addXP(5 + bonus, h?.name || "Habit", {
        icon: "check", color: "var(--accent)", toastDuration: 4000,
        actionLabel: "Undo", onAction: () => toggle(id),
      });
      window.Challenges?.notify?.("habit");
      _maybeAwardFreeze(id);
      _recordCompletionHour();
    } else if (!wasOff) {
      // The one toggle direction that used to give no feedback at all —
      // genuinely unchecking something that was on. Same undo shape as
      // above: re-running toggle() is exactly what a second real tap
      // would do.
      ZG.toast(`${h?.name || "Habit"} unmarked`, 4000, {
        icon: "check", color: "var(--muted-dim)",
        actionLabel: "Undo", onAction: () => toggle(id),
      });
      ZG.refreshChrome();
    } else {
      ZG.refreshChrome();
    }
    if (notifyAllDone) window.Challenges?.notify?.("all_habits");
    render();
  }

  function add(name, category) {
    name = name.trim();
    if (!name) return;
    const d = load();
    const isFirst = d.habits.length === 0;
    const cat = CATEGORIES[category] ? category : "general";
    d.habits.push({ id: "h" + Date.now(), name, weeklyTarget: 7, category: cat });
    save(d);
    if (isFirst) ZG.markActiveToday();
    render();
  }

  /** One-tap add from the curated boost list — same XP/streak/category
   *  machinery as any other habit, just pre-labeled "boost" so it groups
   *  with other dopamine-positive activities on the list. */
  function addBoost(name) {
    if (!BOOST_SUGGESTIONS.includes(name)) return;
    add(name, "boost");
    ZG.toast("Added — small, real, and worth doing");
  }

  /** Shows whichever curated suggestions haven't been added yet (matched
   *  case-insensitively against existing habit names, so renaming one back
   *  to the suggested wording doesn't re-offer it as a duplicate). Hides
   *  itself entirely once every suggestion has been added — this is a
   *  starting nudge, not a permanent fixture. */
  function _remainingBoosts() {
    const d = load();
    const existing = new Set(d.habits.map(h => h.name.trim().toLowerCase()));
    return BOOST_SUGGESTIONS.filter(name => !existing.has(name.toLowerCase()));
  }

  function _renderBoostSuggestions() {
    const card = document.getElementById("boostSuggestCard");
    const wrap = document.getElementById("boostChipRow");
    if (!card || !wrap) return;
    const remaining = _remainingBoosts();
    if (!remaining.length) { card.hidden = true; return; }
    card.hidden = false;
    wrap.innerHTML = remaining.map(name =>
      `<button type="button" class="onb-chip boost-chip" onclick="Habits.addBoost('${name.replace(/'/g, "\\'")}')">${ZG.esc(name)}</button>`
    ).join("");
  }

  function _doRemoveHabit(id) {
    const d = load();
    d.habits = d.habits.filter(x => x.id !== id);
    save(d);
    render();
  }

  async function remove(id) {
    const d = load();
    const h = d.habits.find(x => x.id === id);
    const ok = await ZG.confirm({ title: "Remove this habit?", body: `"${h?.name || "This habit"}" and its history will be deleted — this can't be undone.`, confirmLabel: "Remove", danger: true });
    if (!ok) return;
    _doRemoveHabit(id);
  }

  function setWhy(id, text) {
    const d = load();
    const h = d.habits.find(x => x.id === id);
    if (!h) return;
    h.why = (text || "").trim();
    save(d);
  }

  function rename(id, newName) {
    newName = (newName || "").trim();
    if (!newName) return;
    const d = load();
    const h = d.habits.find(x => x.id === id);
    if (!h) return;
    h.name = newName;
    save(d);
  }

  function setFrequency(id, n) {
    const d = load();
    const h = d.habits.find(x => x.id === id);
    if (!h) return;
    h.weeklyTarget = Math.max(1, Math.min(7, Number(n) || 7));
    save(d);
  }

  function setCategory(id, cat) {
    const d = load();
    const h = d.habits.find(x => x.id === id);
    if (!h) return;
    h.category = CATEGORIES[cat] ? cat : "general";
    save(d);
  }

  function categoryLabel(catId) {
    const id = CATEGORIES[catId] ? catId : "general";
    return window.ZG?.t ? ZG.t("cat_" + id) : CATEGORIES[id].label;
  }

  /* ── habit stacking ── */
  function setAnchor(id, anchorId) {
    const d = load();
    const h = d.habits.find(x => x.id === id);
    if (!h) return;
    h.anchorId = anchorId || null;
    save(d);
  }

  function anchorFor(id) {
    const d = load();
    const h = d.habits.find(x => x.id === id);
    const anchor = h?.anchorId ? d.habits.find(x => x.id === h.anchorId) : null;
    return anchor || null;
  }

  /** Same-day co-occurrence rate between two habits, last 30 days. */
  function _coOccurrence(idA, idB) {
    const d = load();
    const last30 = new Set();
    for (let i = 0; i < 30; i++) { const dt = new Date(); dt.setDate(dt.getDate() - i); last30.add(dt.toDateString()); }
    let both = 0, either = 0;
    Object.entries(d.log).forEach(([day, arr]) => {
      if (!last30.has(day)) return;
      const hasA = arr.includes(idA), hasB = arr.includes(idB);
      if (hasA || hasB) either++;
      if (hasA && hasB) both++;
    });
    return { both, either, rate: either ? both / either : 0 };
  }

  /** Finds the strongest un-stacked, un-dismissed pair that's already
   *  happening together most days — the suggestion is descriptive
   *  ("you already do these together"), not prescriptive. */
  function suggestStack() {
    const d = load();
    if (d.habits.length < 2) return null;
    const dismissed = new Set(d.dismissedStackSuggestions || []);
    let best = null;
    for (const a of d.habits) {
      for (const b of d.habits) {
        if (a.id === b.id || b.anchorId || a.anchorId === b.id) continue;
        const key = `${a.id}>${b.id}`;
        if (dismissed.has(key)) continue;
        const { both, rate } = _coOccurrence(a.id, b.id);
        if (both >= 8 && rate >= 0.7 && (!best || rate > best.rate)) {
          best = { anchorId: a.id, habitId: b.id, anchorName: a.name, habitName: b.name, rate, both, key };
        }
      }
    }
    return best;
  }

  function acceptStack(habitId, anchorId) {
    setAnchor(habitId, anchorId);
    ZG.toast("Stacked — you'll see them linked from now on");
    render();
  }

  function dismissStackSuggestion(key) {
    const d = load();
    d.dismissedStackSuggestions = [...new Set([...(d.dismissedStackSuggestions || []), key])];
    save(d);
    render();
  }

  /* ── progressive difficulty — a one-time, dismissible nudge once a
     habit's streak crosses 7 days: turn it from a plain checkbox into a
     timed "deep work" habit with a focus-minutes goal. Purely optional,
     one suggestion at a time, never re-shown once dismissed for that
     habit — same restraint as the stacking suggestion above. Minutes are
     self-reported at check-off time, not device-timed — no fake
     precision, just a target and an honest tally. */
  function suggestLevelUp() {
    const d = load();
    const dismissed = new Set(d.dismissedLevelUps || []);
    return d.habits.find(h => !h.focusMinutes && !dismissed.has(h.id) && streakFor(h.id) >= 7) || null;
  }

  function setFocusMinutes(id, minutes) {
    const d = load();
    const h = d.habits.find(x => x.id === id);
    if (!h) return;
    const n = Number(minutes);
    h.focusMinutes = (n && n > 0) ? Math.max(5, Math.min(180, Math.round(n))) : null;
    save(d);
  }

  function acceptLevelUp(habitId, minutes = 15) {
    setFocusMinutes(habitId, minutes);
    ZG.toast(`Focus-time goal set — ${minutes} min`);
    render();
  }

  function dismissLevelUp(habitId) {
    const d = load();
    d.dismissedLevelUps = [...new Set([...(d.dismissedLevelUps || []), habitId])];
    save(d);
    render();
  }

  /** Sum of focus-minutes goals credited this week — only habits that
   *  have a goal set contribute, and only on days they were actually
   *  checked off. A "Growth-oriented" stat that isn't just a raw
   *  completion count (see Home's stat row). */
  function deepWorkMinutesThisWeek() {
    const d = load();
    const start = _weekStart();
    let total = 0;
    Object.entries(d.log || {}).forEach(([dateStr, ids]) => {
      if (new Date(dateStr) < start) return;
      (ids || []).forEach(id => {
        const h = d.habits.find(x => x.id === id);
        if (h?.focusMinutes) total += h.focusMinutes;
      });
    });
    return total;
  }

  /* ── streak freezes ── */
  const FREEZE_CAP = 2;
  const FREEZE_EARN_INTERVAL = 7;

  function _yesterdayKey() { const dt = new Date(); dt.setDate(dt.getDate() - 1); return dt.toDateString(); }
  function _dayBeforeYesterdayKey() { const dt = new Date(); dt.setDate(dt.getDate() - 2); return dt.toDateString(); }

  /** Called right after a genuine completion — every 7-day run banks one
   *  freeze, up to a small cap. No purchasing, no ads: earned the same way
   *  everything else here is earned. */
  function _maybeAwardFreeze(id) {
    const d = load();
    const h = d.habits.find(x => x.id === id);
    if (!h) return;
    const streak = streakFor(id);
    if (streak > 0 && streak % FREEZE_EARN_INTERVAL === 0) {
      const cur = h.freezesAvailable || 0;
      if (cur < FREEZE_CAP) {
        h.freezesAvailable = cur + 1;
        save(d);
        ZG.toast(`${streak}-day streak — you've earned a streak freeze`, 3600, { icon: "lock", color: "var(--gold)" });
      }
    }
  }

  function freezesFor(id) {
    const h = load().habits.find(x => x.id === id);
    return h?.freezesAvailable || 0;
  }

  /** True only when there's an actual streak worth protecting: yesterday
   *  was missed, the day before it wasn't (so a real run is at risk), a
   *  freeze is banked, and yesterday hasn't already been covered. */
  function canUseFreezeForYesterday(id) {
    const d = load();
    const h = d.habits.find(x => x.id === id);
    if (!h || !(h.freezesAvailable > 0)) return false;
    const yKey = _yesterdayKey();
    const frozen = new Set(h.frozenDays || []);
    if (frozen.has(yKey)) return false;
    const yDone = (d.log[yKey] || []).includes(id);
    if (yDone) return false;
    const dbyKey = _dayBeforeYesterdayKey();
    return (d.log[dbyKey] || []).includes(id) || frozen.has(dbyKey);
  }

  function useFreezeForYesterday(id) {
    if (!canUseFreezeForYesterday(id)) return;
    const d = load();
    const h = d.habits.find(x => x.id === id);
    h.freezesAvailable = Math.max(0, (h.freezesAvailable || 0) - 1);
    h.frozenDays = [...(h.frozenDays || []), _yesterdayKey()];
    save(d);
    ZG.toast(`Streak protected — yesterday's covered, ${h.freezesAvailable} freeze${h.freezesAvailable === 1 ? "" : "s"} left`, 3400, { icon: "lock", color: "var(--gold)" });
    render();
  }

  /* ── weekly-target progress (Monday-start week, matches ZG's own rhythm ring) ── */
  function _weekStart(d = new Date()) {
    const dt = new Date(d); const day = (dt.getDay() + 6) % 7; // Monday=0
    dt.setHours(0, 0, 0, 0); dt.setDate(dt.getDate() - day);
    return dt;
  }
  function weekCountFor(id) {
    const d = load();
    const start = _weekStart();
    let count = 0;
    Object.keys(d.log).forEach(dateStr => {
      if (new Date(dateStr) >= start && (d.log[dateStr] || []).includes(id)) count++;
    });
    return count;
  }

  /* ── edit modal ── */
  let _editingHabitId = null;

  function _syncFreqReadout() {
    const freqInput = document.getElementById("habitEditFreq");
    const readout = document.getElementById("habitEditFreqReadout");
    const label = document.getElementById("habitEditFreqLabel");
    if (!freqInput) return;
    const n = Number(freqInput.value);
    if (readout) readout.textContent = n;
    if (label) label.textContent = n >= 7 ? "Every day" : `${n}× a week`;
  }

  function openEditModal(id) {
    const d = load();
    const h = d.habits.find(x => x.id === id);
    if (!h) return;
    _editingHabitId = id;
    const nameInput = document.getElementById("habitEditName");
    const whyInput = document.getElementById("habitEditWhy");
    const freqInput = document.getElementById("habitEditFreq");
    const anchorSelect = document.getElementById("habitEditAnchor");
    const catSelect = document.getElementById("habitEditCategory");
    const focusSelect = document.getElementById("habitEditFocus");
    if (nameInput) nameInput.value = h.name;
    if (whyInput) whyInput.value = h.why || "";
    if (freqInput) freqInput.value = h.weeklyTarget || 7;
    if (focusSelect) focusSelect.value = h.focusMinutes ? String(h.focusMinutes) : "";
    if (catSelect) {
      catSelect.innerHTML = Object.values(CATEGORIES).map(c => `<option value="${c.id}">${ZG.esc(categoryLabel(c.id))}</option>`).join("");
      catSelect.value = _catOf(h);
    }
    if (anchorSelect) {
      const others = d.habits.filter(x => x.id !== id);
      anchorSelect.innerHTML = `<option value="">${ZG.esc(ZG.t ? ZG.t("no_anchor_option") : "No anchor — stands on its own")}</option>`
        + others.map(o => `<option value="${o.id}">After "${ZG.esc(o.name)}"</option>`).join("");
      anchorSelect.value = h.anchorId || "";
    }
    _syncFreqReadout();
    ZG.openModal("habitEditModal");
  }

  function saveEditModal() {
    if (!_editingHabitId) return;
    const name = document.getElementById("habitEditName")?.value.trim();
    const why = document.getElementById("habitEditWhy")?.value.trim();
    const freq = document.getElementById("habitEditFreq")?.value;
    const anchor = document.getElementById("habitEditAnchor")?.value;
    const category = document.getElementById("habitEditCategory")?.value;
    const focus = document.getElementById("habitEditFocus")?.value;
    if (!name) { ZG.toast("Give this habit a name first"); return; }
    rename(_editingHabitId, name);
    setWhy(_editingHabitId, why);
    setFrequency(_editingHabitId, freq);
    setAnchor(_editingHabitId, anchor);
    setCategory(_editingHabitId, category);
    setFocusMinutes(_editingHabitId, focus);
    _editingHabitId = null;
    ZG.closeModal("habitEditModal");
    ZG.toast("Habit updated");
    render();
  }

  function cancelEditModal() { _editingHabitId = null; ZG.closeModal("habitEditModal"); }

  async function deleteFromEditModal() {
    if (!_editingHabitId) return;
    const d = load();
    const h = d.habits.find(x => x.id === _editingHabitId);
    const ok = await ZG.confirm({ title: "Remove this habit?", body: `"${h?.name || "This habit"}" and its history will be deleted — this can't be undone.`, confirmLabel: "Remove", danger: true });
    if (!ok) return;
    const id = _editingHabitId;
    _editingHabitId = null;
    ZG.closeModal("habitEditModal");
    _doRemoveHabit(id);
  }

  function streakFor(id) {
    const d = load();
    const h = d.habits.find(x => x.id === id);
    const frozen = new Set(h?.frozenDays || []);
    let streak = 0;
    for (let i = 0; i < 365; i++) {
      const dt = new Date(); dt.setDate(dt.getDate() - i);
      const key = dt.toDateString();
      const done = (d.log[key] || []).includes(id);
      if (!done && !frozen.has(key)) break;
      streak++;
    }
    return streak;
  }

  function _historyStrip(id) {
    const d = load();
    const h = d.habits.find(x => x.id === id);
    const frozen = new Set(h?.frozenDays || []);
    const days = 21;
    let dots = "";
    for (let i = days - 1; i >= 0; i--) {
      const dt = new Date(); dt.setDate(dt.getDate() - i);
      const key = dt.toDateString();
      const done = (d.log[key] || []).includes(id);
      const isFrozen = !done && frozen.has(key);
      const label = dt.toLocaleDateString("en", { month: "short", day: "numeric" });
      const cls = done ? " on" : (isFrozen ? " frozen" : "");
      const style = done ? `background:${_dotColor(id)}` : "";
      const title = done ? " · done" : (isFrozen ? " · streak freeze used" : "");
      dots += `<span class="habit-hist-dot${cls}" style="${style}" title="${label}${title}"></span>`;
    }
    return `<div class="habit-hist-strip">${dots}</div>`;
  }

  function todayCounts() {
    const d = load();
    const t = today();
    const done = (d.log[t] || []).length;
    return { done, total: d.habits.length };
  }

  function totalCompletions() {
    const d = load();
    return Object.values(d.log).reduce((s, arr) => s + arr.length, 0);
  }

  function _bestStreak() {
    const d = load();
    return d.habits.reduce((max, h) => Math.max(max, streakFor(h.id)), 0);
  }

  function renderSummary() {
    const card = document.getElementById("habitsSummary");
    if (!card) return;
    const { done, total } = todayCounts();
    card.hidden = !total;
    if (!total) { card.innerHTML = ""; return; }
    const best = _bestStreak();
    const deepMin = deepWorkMinutesThisWeek();
    card.innerHTML = `
      <div class="summary-head">
        <div class="summary-big"><span class="summary-num">${done}/${total}</span><span class="summary-lbl">done today</span></div>
        <div class="summary-bar" role="progressbar" aria-label="Habits done today" aria-valuemin="0" aria-valuemax="${total}" aria-valuenow="${done}"><span style="width:${Math.round((done / total) * 100)}%"></span></div>
        <div class="summary-chips">
          <span class="summary-chip">${total} habit${total === 1 ? "" : "s"}</span>
          <span class="summary-chip">${best > 0 ? `${best}-day best streak` : "No streak yet"}</span>
          ${deepMin > 0 ? `<span class="summary-chip">${deepMin} min deep work this week</span>` : ""}
        </div>
      </div>`;
  }

  /* 16-week consistency calendar: one cell per day, shaded by the share of today's
     habit list that was done. Pure SVG, built from the same log the rest of the app uses. */
  function _renderHeatmap() {
    const el = document.getElementById("habitHeatmap");
    if (!el) return;
    const d = load(), n = d.habits.length, WEEKS = 16, cell = 13, gap = 3, step = cell + gap;
    const now = new Date(), start = new Date(now);
    start.setDate(now.getDate() - now.getDay() - (WEEKS - 1) * 7);          // Sunday of the first column
    let cells = "", active = 0, perfect = 0;
    for (let w = 0; w < WEEKS; w++) for (let r = 0; r < 7; r++) {
      const day = new Date(start); day.setDate(start.getDate() + w * 7 + r);
      if (day > now) continue;
      const key = day.toDateString(), c = (d.log[key] || []).length, ratio = n ? Math.min(1, c / n) : 0;
      const lvl = c === 0 ? 0 : ratio >= 1 ? 4 : ratio > 0.66 ? 3 : ratio > 0.33 ? 2 : 1;
      if (c) active++;
      if (lvl === 4) perfect++;
      const label = `${day.toLocaleDateString(undefined, { month: "short", day: "numeric" })}: ${c}/${n}`;
      cells += `<rect class="hm hm-${lvl}${key === today() ? " hm-today" : ""}" x="${w * step}" y="${r * step}" width="${cell}" height="${cell}" rx="3"><title>${label}</title></rect>`;
    }
    el.innerHTML = `
      <div class="hm-head"><div class="card-eyebrow" style="margin:0">Last ${WEEKS} weeks</div><div class="hm-stats"><b>${active}</b> active days \u00b7 <b>${perfect}</b> perfect</div></div>
      <svg class="hm-svg" viewBox="0 0 ${WEEKS * step - gap} ${7 * step - gap}" role="img" aria-label="Habit calendar for the last ${WEEKS} weeks: ${active} active days, ${perfect} days with every habit done">${cells}</svg>
      <div class="hm-legend" aria-hidden="true">Less <i class="hm-0"></i><i class="hm-1"></i><i class="hm-2"></i><i class="hm-3"></i><i class="hm-4"></i> More</div>`;
  }

  /* The add-habit form lives in a bottom sheet (habitAddModal); the + button, the floating
     button and Home's Today card all open it. */
  function openAddSheet() {
    ZG.openModal("habitAddModal");
    setTimeout(() => document.getElementById("habitInput")?.focus(), 360);
  }

  function render() {
    _renderBoostSuggestions();
    const list = document.getElementById("habitsList");
    if (!list) return;
    const d = load();
    const t = today();
    const doneToday = d.log[t] || [];

    _renderHeatmap();
    if (!d.habits.length) {
      list.innerHTML = `<div class="empty-state">
        <span class="icon-chip lg">${window.Icons?.svg("growth", 1.7) || ""}</span>
        <h3>Plant your first habit</h3>
        <p>Start smaller than feels necessary — two minutes counts. Your streaks, rings and calendar grow from here.</p>
        <button type="button" class="btn-primary" onclick="Habits.openAddSheet()">Add a habit</button>
      </div>`;
      renderSummary();
      return;
    }

    let html = "";
    const suggestion = suggestStack();
    if (suggestion) {
      html += `
        <div class="stack-suggestion">
          <span class="icon-chip sm" style="--chip-color:var(--gold)">${window.Icons?.svg("compass") || ""}</span>
          <span class="stack-suggestion-text">You already do "${ZG.esc(suggestion.habitName)}" alongside "${ZG.esc(suggestion.anchorName)}" most days — want to stack them?</span>
          <div class="stack-suggestion-actions">
            <button class="btn-quiet" onclick="Habits.acceptStack('${suggestion.habitId}','${suggestion.anchorId}')">Stack them</button>
            <button class="habit-del" onclick="Habits.dismissStackSuggestion('${suggestion.key}')" aria-label="Dismiss suggestion">✕</button>
          </div>
        </div>`;
    } else {
      // Only one suggestion card at a time, same restraint as the stack
      // suggestion above — this one just fills the slot when that one's empty.
      const levelUp = suggestLevelUp();
      if (levelUp) {
        html += `
          <div class="stack-suggestion">
            <span class="icon-chip sm" style="--chip-color:var(--clay)">${window.Icons?.svg("flag") || ""}</span>
            <span class="stack-suggestion-text">"${ZG.esc(levelUp.name)}" is becoming routine — a ${streakFor(levelUp.id)}-day streak. Add a focus-time goal to make it count for more?</span>
            <div class="stack-suggestion-actions">
              <button class="btn-quiet" onclick="Habits.acceptLevelUp('${levelUp.id}',15)">Add 15 min goal</button>
              <button class="habit-del" onclick="Habits.dismissLevelUp('${levelUp.id}')" aria-label="Dismiss suggestion">✕</button>
            </div>
          </div>`;
      }
    }

    // Grouped by category rather than one flat list — a habit with no (or an
    // unrecognized) category quietly falls back to "General" via _catOf(),
    // so nothing here needs a migration step for habits added before
    // categories existed. Only categories that actually have a habit in
    // them get a header, in CATEGORIES' own definition order.
    const grouped = {};
    d.habits.forEach(h => { const cat = _catOf(h); (grouped[cat] || (grouped[cat] = [])).push(h); });
    html += Object.keys(CATEGORIES).filter(c => grouped[c]?.length).map(catId => {
      const cat = CATEGORIES[catId];
      const rows = grouped[catId].map(h => _renderHabitRow(h, doneToday)).join("");
      return `
        <div class="habit-cat-group">
          <div class="habit-cat-header">
            <span class="icon-chip sm" style="--chip-color:var(${cat.colorVar})">${window.Icons?.svg(cat.icon) || ""}</span>
            <span class="habit-cat-label">${ZG.esc(categoryLabel(catId))}</span>
            <span class="habit-cat-count">${grouped[catId].length}</span>
          </div>
          ${rows}
        </div>`;
    }).join("");
    list.innerHTML = html;
    renderSummary();
  }

  function _renderHabitRow(h, doneToday) {
    const isDone = doneToday.includes(h.id);
    const streak = streakFor(h.id);
    const target = h.weeklyTarget || 7;
    const isDaily = target >= 7;
    const metaPrimary = isDaily
      ? (streak > 0 ? `${streak}-day streak` : "Not yet today")
      : `${weekCountFor(h.id)}/${target} this week`;
    const whyHtml = h.why
      ? `<span class="habit-why" onclick="Habits.openEditModal('${h.id}')" title="Edit">${ZG.esc(h.why)}</span>`
      : `<span class="habit-why habit-why-add" onclick="Habits.openEditModal('${h.id}')">add a why</span>`;
    const anchor = anchorFor(h.id);
    const anchorChip = anchor ? `<span class="habit-anchor-chip" title="Stacked after ${ZG.esc(anchor.name)}">after ${ZG.esc(anchor.name)}</span>` : "";
    const focusChip = h.focusMinutes ? `<span class="habit-focus-chip" title="Focus-time goal">${window.Icons?.svg("breath", 1.8) || ""}${h.focusMinutes} min</span>` : "";
    const freezes = h.freezesAvailable || 0;
    const freezeChip = freezes > 0 ? `<span class="habit-freeze-chip" title="${freezes} streak freeze${freezes === 1 ? "" : "s"} banked">${window.Icons?.svg("lock", 1.8) || ""}${freezes}</span>` : "";
    const freezeOffer = canUseFreezeForYesterday(h.id)
      ? `<button class="habit-freeze-offer" onclick="Habits.useFreezeForYesterday('${h.id}')">Missed yesterday — use a freeze to keep the streak</button>`
      : "";
    return `
      <div class="habit-row-wrap">
        <div class="habit-row${isDone ? " done" : ""}${ZG._justDone === h.id ? " just-done" : ""}">
          <div class="habit-check${isDone ? " on" : ""}" role="checkbox" aria-checked="${isDone}" aria-label="${ZG.esc(h.name)}" tabindex="0"
               onclick="Habits.toggle('${h.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();Habits.toggle('${h.id}')}">
            ${isDone ? (window.Icons?.svg("check", 2.2) || "") : ""}
          </div>
          <div class="habit-info">
            <span class="habit-dot" style="background:${_dotColor(h.id)}"></span>
            <div>
              <div class="habit-name">${ZG.esc(h.name)}${isDaily ? "" : `<span class="habit-freq-chip">${target}×/wk</span>`}${anchorChip}${focusChip}${freezeChip}</div>
              <div class="habit-meta">${metaPrimary} · ${whyHtml}</div>
              ${freezeOffer}
            </div>
          </div>
          <button class="habit-del" onclick="Habits.openEditModal('${h.id}')" aria-label="Edit habit" title="Edit">✎</button>
          <button class="habit-del" onclick="Habits.remove('${h.id}')" aria-label="Remove habit">✕</button>
        </div>
        ${_historyStrip(h.id)}
      </div>`;
  }

  document.addEventListener("DOMContentLoaded", () => {
    const addCatSelect = document.getElementById("habitCategorySelect");
    if (addCatSelect) addCatSelect.innerHTML = Object.values(CATEGORIES).map(c => `<option value="${c.id}">${ZG.esc(categoryLabel(c.id))}</option>`).join("");

    document.getElementById("habitAddForm")?.addEventListener("submit", e => {
      e.preventDefault();
      const input = document.getElementById("habitInput");
      const catSelect = document.getElementById("habitCategorySelect");
      if (!input.value.trim()) { input.focus(); return; }
      add(input.value, catSelect?.value);
      input.value = "";
      ZG.closeModal("habitAddModal");
    });
    document.getElementById("habitAddBtn")?.addEventListener("click", openAddSheet);
    document.getElementById("habitFab")?.addEventListener("click", openAddSheet);
    document.getElementById("habitAddCancel")?.addEventListener("click", () => ZG.closeModal("habitAddModal"));
    document.getElementById("habitEditFreq")?.addEventListener("input", _syncFreqReadout);
    document.getElementById("habitEditSaveBtn")?.addEventListener("click", saveEditModal);
    document.getElementById("habitEditDeleteBtn")?.addEventListener("click", deleteFromEditModal);
    // Habits isn't necessarily the visible section on load (Home is the default
    // landing screen) — build it on demand the first time it's actually shown,
    // via ZG.sectionRenderers.habits below, rather than paying for a full render
    // (habit rows, history strips, boost suggestions) on every single page load.
  });

  ZG.sectionRenderers.habits = render;

  return { toggle, openAddSheet, add, addBoost, remove, setWhy, rename, setFrequency, setAnchor, anchorFor, setCategory, categoryLabel, CATEGORIES, suggestStack, acceptStack, dismissStackSuggestion, suggestLevelUp, acceptLevelUp, dismissLevelUp, setFocusMinutes, deepWorkMinutesThisWeek, freezesFor, canUseFreezeForYesterday, useFreezeForYesterday, openEditModal, saveEditModal, cancelEditModal, deleteFromEditModal, render, renderSummary, todayCounts, streakFor, weekCountFor, totalCompletions, typicalCompletionHour, load };
})();
window.Habits = Habits;
